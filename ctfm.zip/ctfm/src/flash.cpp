/******************************
  Program "flash.m" compiled by "Caching Murphi Release 5.4.9"

  Murphi Last Compiled date: "Apr 29 2017"
 ******************************/

/********************
  Parameter
 ********************/
#define MURPHI_VERSION "Caching Murphi Release 5.4.9"
#define MURPHI_DATE "Apr 29 2017"
#define PROTOCOL_NAME "flash"
#define BITS_IN_WORLD 552
#define ALIGN

/********************
  Include
 ********************/
#include "mu_prolog.hpp"

/********************
  Decl declaration
 ********************/

enum "NODE" (int_consts [0;1;2;3]);
enum "DATA" (int_consts [1;2]);
let _CACHE_I = strc "CACHE_I"
let _CACHE_S = strc "CACHE_S"
let _CACHE_E = strc "CACHE_E"
enum "CACHE_STATE" [_CACHE_I;_CACHE_S;_CACHE_E];
let _NODE_None = strc "NODE_None"
let _NODE_Get = strc "NODE_Get"
let _NODE_GetX = strc "NODE_GetX"
enum "NODE_CMD" [_NODE_None;_NODE_Get;_NODE_GetX];
let _NODE_STATE = List concat  [
  [arrdef [("ProcCmd",[])] "NODE_CMD"];
  [arrdef [("InvMarked",[])] "boolean"];
  [arrdef [("CacheState",[])] "CACHE_STATE"];
  [arrdef [("CacheData",[])] "DATA"]
]
class mu_1__type_0
{
 public:
  boolean array[ 4 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_0 (const char *n, int os) { set_self(n, os); };
  mu_1__type_0 ( void ) {};
  virtual ~mu_1__type_0 ();
  boolean& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 0 ) && ( index <= 3 ) )
      return array[ index - 0 ];
    else {
      if (index==UNDEFVAL) 
	Error.Error("Indexing to %s using an undefined value.", name);
      else
	Error.Error("%d not in index range of %s.", index, name);
      return array[0];
    }
#else
    return array[ index - 0 ];
#endif
  };
  mu_1__type_0& operator= (const mu_1__type_0& from)
  {
    for (int i = 0; i < 4; i++)
      array[i].value(from.array[i].value());
    return *this;
  }

friend int CompareWeight(mu_1__type_0& a, mu_1__type_0& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = CompareWeight(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
friend int Compare(mu_1__type_0& a, mu_1__type_0& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);
  virtual void MultisetSort()
  {
    for (int i=0; i<4; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<4; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 4; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 4; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 4; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 4; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 4; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 4; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_0::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_0::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_0::set_self( const char *n, int os)
{
  char* s;
  name = (char *)n;
  for(int i = 0; i < 4; i++) {
    array[i].set_self_ar(n, s=tsprintf("%d",i + 0), i * 8 + os);
    delete[] s;
  }
};
mu_1__type_0::~mu_1__type_0()
{
}
/*** end array declaration ***/
mu_1__type_0 mu_1__type_0_undefined_var;

class mu_1__type_1
{
 public:
  boolean array[ 4 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_1 (const char *n, int os) { set_self(n, os); };
  mu_1__type_1 ( void ) {};
  virtual ~mu_1__type_1 ();
  boolean& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 0 ) && ( index <= 3 ) )
      return array[ index - 0 ];
    else {
      if (index==UNDEFVAL) 
	Error.Error("Indexing to %s using an undefined value.", name);
      else
	Error.Error("%d not in index range of %s.", index, name);
      return array[0];
    }
#else
    return array[ index - 0 ];
#endif
  };
  mu_1__type_1& operator= (const mu_1__type_1& from)
  {
    for (int i = 0; i < 4; i++)
      array[i].value(from.array[i].value());
    return *this;
  }

friend int CompareWeight(mu_1__type_1& a, mu_1__type_1& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = CompareWeight(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
friend int Compare(mu_1__type_1& a, mu_1__type_1& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);
  virtual void MultisetSort()
  {
    for (int i=0; i<4; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<4; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 4; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 4; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 4; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 4; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 4; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 4; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_1::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_1::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_1::set_self( const char *n, int os)
{
  char* s;
  name = (char *)n;
  for(int i = 0; i < 4; i++) {
    array[i].set_self_ar(n, s=tsprintf("%d",i + 0), i * 8 + os);
    delete[] s;
  }
};
mu_1__type_1::~mu_1__type_1()
{
}
/*** end array declaration ***/
mu_1__type_1 mu_1__type_1_undefined_var;

let _DIR_STATE = List concat  [
  [arrdef [("Pending",[])] "boolean"];
  [arrdef [("Local",[])] "boolean"];
  [arrdef [("Dirty",[])] "boolean"];
  [arrdef [("HeadVld",[])] "boolean"];
  [arrdef [("HeadPtr",[])] "NODE"];
  [arrdef [("ShrVld",[])] "boolean"];
  [arrdef [("ShrSet", [paramdef "i0" "NODE"])] "boolean"];
  [arrdef [("InvSet", [paramdef "i1" "NODE"])] "boolean"]
]
let _UNI_None = strc "UNI_None"
let _UNI_Get = strc "UNI_Get"
let _UNI_GetX = strc "UNI_GetX"
let _UNI_Put = strc "UNI_Put"
let _UNI_PutX = strc "UNI_PutX"
let _UNI_Nak = strc "UNI_Nak"
enum "UNI_CMD" [_UNI_None;_UNI_Get;_UNI_GetX;_UNI_Put;_UNI_PutX;_UNI_Nak];
let _UNI_MSG = List concat  [
  [arrdef [("Cmd",[])] "UNI_CMD"];
  [arrdef [("Proc",[])] "NODE"];
  [arrdef [("Data",[])] "DATA"]
]
let _INV_None = strc "INV_None"
let _INV_Inv = strc "INV_Inv"
let _INV_InvAck = strc "INV_InvAck"
enum "INV_CMD" [_INV_None;_INV_Inv;_INV_InvAck];
let _INV_MSG = List concat  [
  [arrdef [("Cmd",[])] "INV_CMD"]
]
let _RP_None = strc "RP_None"
let _RP_Replace = strc "RP_Replace"
enum "RP_CMD" [_RP_None;_RP_Replace];
let _RP_MSG = List concat  [
  [arrdef [("Cmd",[])] "RP_CMD"]
]
let _WB_None = strc "WB_None"
let _WB_Wb = strc "WB_Wb"
enum "WB_CMD" [_WB_None;_WB_Wb];
let _WB_MSG = List concat  [
  [arrdef [("Cmd",[])] "WB_CMD"];
  [arrdef [("Proc",[])] "NODE"];
  [arrdef [("Data",[])] "DATA"]
]
let _SHWB_None = strc "SHWB_None"
let _SHWB_ShWb = strc "SHWB_ShWb"
let _SHWB_FAck = strc "SHWB_FAck"
enum "SHWB_CMD" [_SHWB_None;_SHWB_ShWb;_SHWB_FAck];
let _SHWB_MSG = List concat  [
  [arrdef [("Cmd",[])] "SHWB_CMD"];
  [arrdef [("Proc",[])] "NODE"];
  [arrdef [("Data",[])] "DATA"]
]
let _NAKC_None = strc "NAKC_None"
let _NAKC_Nakc = strc "NAKC_Nakc"
enum "NAKC_CMD" [_NAKC_None;_NAKC_Nakc];
let _NAKC_MSG = List concat  [
  [arrdef [("Cmd",[])] "NAKC_CMD"]
]
class mu_1__type_2
{
 public:
  NODE_STATE array[ 4 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_2 (const char *n, int os) { set_self(n, os); };
  mu_1__type_2 ( void ) {};
  virtual ~mu_1__type_2 ();
  NODE_STATE& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 0 ) && ( index <= 3 ) )
      return array[ index - 0 ];
    else {
      if (index==UNDEFVAL) 
	Error.Error("Indexing to %s using an undefined value.", name);
      else
	Error.Error("%d not in index range of %s.", index, name);
      return array[0];
    }
#else
    return array[ index - 0 ];
#endif
  };
  mu_1__type_2& operator= (const mu_1__type_2& from)
  {
    for (int i = 0; i < 4; i++)
      array[i] = from.array[i];
    return *this;
  }

friend int CompareWeight(mu_1__type_2& a, mu_1__type_2& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = CompareWeight(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
friend int Compare(mu_1__type_2& a, mu_1__type_2& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);
  virtual void MultisetSort()
  {
    for (int i=0; i<4; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<4; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 4; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 4; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 4; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 4; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 4; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 4; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_2::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_2::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_2::set_self( const char *n, int os)
{
  char* s;
  name = (char *)n;
  for(int i = 0; i < 4; i++) {
    array[i].set_self_ar(n, s=tsprintf("%d",i + 0), i * 32 + os);
    delete[] s;
  }
};
mu_1__type_2::~mu_1__type_2()
{
}
/*** end array declaration ***/
mu_1__type_2 mu_1__type_2_undefined_var;

class mu_1__type_3
{
 public:
  UNI_MSG array[ 4 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_3 (const char *n, int os) { set_self(n, os); };
  mu_1__type_3 ( void ) {};
  virtual ~mu_1__type_3 ();
  UNI_MSG& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 0 ) && ( index <= 3 ) )
      return array[ index - 0 ];
    else {
      if (index==UNDEFVAL) 
	Error.Error("Indexing to %s using an undefined value.", name);
      else
	Error.Error("%d not in index range of %s.", index, name);
      return array[0];
    }
#else
    return array[ index - 0 ];
#endif
  };
  mu_1__type_3& operator= (const mu_1__type_3& from)
  {
    for (int i = 0; i < 4; i++)
      array[i] = from.array[i];
    return *this;
  }

friend int CompareWeight(mu_1__type_3& a, mu_1__type_3& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = CompareWeight(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
friend int Compare(mu_1__type_3& a, mu_1__type_3& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);
  virtual void MultisetSort()
  {
    for (int i=0; i<4; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<4; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 4; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 4; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 4; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 4; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 4; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 4; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_3::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_3::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_3::set_self( const char *n, int os)
{
  char* s;
  name = (char *)n;
  for(int i = 0; i < 4; i++) {
    array[i].set_self_ar(n, s=tsprintf("%d",i + 0), i * 24 + os);
    delete[] s;
  }
};
mu_1__type_3::~mu_1__type_3()
{
}
/*** end array declaration ***/
mu_1__type_3 mu_1__type_3_undefined_var;

class mu_1__type_4
{
 public:
  INV_MSG array[ 4 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_4 (const char *n, int os) { set_self(n, os); };
  mu_1__type_4 ( void ) {};
  virtual ~mu_1__type_4 ();
  INV_MSG& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 0 ) && ( index <= 3 ) )
      return array[ index - 0 ];
    else {
      if (index==UNDEFVAL) 
	Error.Error("Indexing to %s using an undefined value.", name);
      else
	Error.Error("%d not in index range of %s.", index, name);
      return array[0];
    }
#else
    return array[ index - 0 ];
#endif
  };
  mu_1__type_4& operator= (const mu_1__type_4& from)
  {
    for (int i = 0; i < 4; i++)
      array[i] = from.array[i];
    return *this;
  }

friend int CompareWeight(mu_1__type_4& a, mu_1__type_4& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = CompareWeight(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
friend int Compare(mu_1__type_4& a, mu_1__type_4& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);
  virtual void MultisetSort()
  {
    for (int i=0; i<4; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<4; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 4; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 4; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 4; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 4; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 4; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 4; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_4::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_4::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_4::set_self( const char *n, int os)
{
  char* s;
  name = (char *)n;
  for(int i = 0; i < 4; i++) {
    array[i].set_self_ar(n, s=tsprintf("%d",i + 0), i * 8 + os);
    delete[] s;
  }
};
mu_1__type_4::~mu_1__type_4()
{
}
/*** end array declaration ***/
mu_1__type_4 mu_1__type_4_undefined_var;

class mu_1__type_5
{
 public:
  RP_MSG array[ 4 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_5 (const char *n, int os) { set_self(n, os); };
  mu_1__type_5 ( void ) {};
  virtual ~mu_1__type_5 ();
  RP_MSG& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 0 ) && ( index <= 3 ) )
      return array[ index - 0 ];
    else {
      if (index==UNDEFVAL) 
	Error.Error("Indexing to %s using an undefined value.", name);
      else
	Error.Error("%d not in index range of %s.", index, name);
      return array[0];
    }
#else
    return array[ index - 0 ];
#endif
  };
  mu_1__type_5& operator= (const mu_1__type_5& from)
  {
    for (int i = 0; i < 4; i++)
      array[i] = from.array[i];
    return *this;
  }

friend int CompareWeight(mu_1__type_5& a, mu_1__type_5& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = CompareWeight(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
friend int Compare(mu_1__type_5& a, mu_1__type_5& b)
  {
    int w;
    for (int i=0; i<4; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);
  virtual void MultisetSort()
  {
    for (int i=0; i<4; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<4; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 4; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 4; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 4; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 4; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 4; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 4; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_5::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_5::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_5::set_self( const char *n, int os)
{
  char* s;
  name = (char *)n;
  for(int i = 0; i < 4; i++) {
    array[i].set_self_ar(n, s=tsprintf("%d",i + 0), i * 8 + os);
    delete[] s;
  }
};
mu_1__type_5::~mu_1__type_5()
{
}
/*** end array declaration ***/
mu_1__type_5 mu_1__type_5_undefined_var;

let _STATE = List concat  [
  record_def "Proc" [paramdef "2" "NODE"] _NODE_STATE;
  record_def "Dir" []  DIR_STATE;
  [arrdef [("MemData",[])] "DATA"];
  record_def "UniMsg" [paramdef "3" "NODE"] _UNI_MSG;
  record_def "InvMsg" [paramdef "4" "NODE"] _INV_MSG;
  record_def "RpMsg" [paramdef "5" "NODE"] _RP_MSG;
  record_def "WbMsg" []  WB_MSG;
  record_def "ShWbMsg" []  SHWB_MSG;
  record_def "NakcMsg" []  NAKC_MSG;
  [arrdef [("CurrData",[])] "DATA"];
  [arrdef [("PrevData",[])] "DATA"];
  [arrdef [("LastWrVld",[])] "boolean"];
  [arrdef [("LastWrPtr",[])] "NODE"];
  [arrdef [("Requester",[])] "NODE"];
  [arrdef [("Collecting",[])] "boolean"];
  [arrdef [("FwdCmd",[])] "UNI_CMD"];
  [arrdef [("FwdSrc",[])] "NODE"];
  [arrdef [("LastInvAck",[])] "NODE"];
  [arrdef [("LastOtherInvAck",[])] "NODE"]
]
/*** Variable declaration ***/
NODE mu_Home("Home",0);

/*** Variable declaration ***/
STATE mu_Sta("Sta",8);





/********************
  The world
 ********************/
void world_class::clear()
{
  Home.clear();
  Sta.clear();
}
void world_class::undefine()
{
  Home.undefine();
  Sta.undefine();
}
void world_class::reset()
{
  Home.reset();
  Sta.reset();
}
void world_class::print()
{
  static int num_calls = 0; /* to ward off recursive calls. */
  if ( num_calls == 0 ) {
    num_calls++;
  Home.print();
  Sta.print();
    num_calls--;
}
}
void world_class::print_statistic()
{
  static int num_calls = 0; /* to ward off recursive calls. */
  if ( num_calls == 0 ) {
    num_calls++;
  Home.print_statistic();
  Sta.print_statistic();
    num_calls--;
}
}
void world_class::print_diff( state *prevstate )
{
  if ( prevstate != NULL )
  {
    Home.print_diff(prevstate);
    Sta.print_diff(prevstate);
  }
  else
print();
}
void world_class::to_state(state *newstate)
{
  Home.to_state( newstate );
  Sta.to_state( newstate );
}
void world_class::setstate(state *thestate)
{
}


/********************
  Rule declarations
 ********************/
/******************** RuleBase0 ********************/
class RuleBase0
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Replace, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return (Sta.mu_RpMsg[src].mu_Cmd) == (RP_Replace);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 0;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 4 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_RpMsg[src].mu_Cmd) == (RP_Replace)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 0;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_RpMsg[src].mu_Cmd = RP_None;
if ( Sta.mu_Dir.mu_ShrVld )
{
Sta.mu_Dir.mu_ShrSet[src] = false;
Sta.mu_Dir.mu_InvSet[src] = false;
}
  };

};
/******************** RuleBase1 ********************/
class RuleBase1
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("NI_ShWb");
  }
  bool Condition(unsigned r)
  {
    return (Sta.mu_ShWbMsg.mu_Cmd) == (SHWB_ShWb);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 4;
    while (what_rule < 5 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_ShWbMsg.mu_Cmd) == (SHWB_ShWb)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 4;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_ShWbMsg.mu_Cmd = SHWB_None;
Sta.mu_Dir.mu_Pending = false;
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_Dir.mu_ShrVld = true;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr6;
  if ((p) == (Sta.mu_ShWbMsg.mu_Proc)) mu__boolexpr6 = TRUE ;
  else {
  mu__boolexpr6 = (Sta.mu_Dir.mu_ShrSet[p]) ; 
}
Sta.mu_Dir.mu_ShrSet[p] = mu__boolexpr6;
bool mu__boolexpr7;
  if ((p) == (Sta.mu_ShWbMsg.mu_Proc)) mu__boolexpr7 = TRUE ;
  else {
  mu__boolexpr7 = (Sta.mu_Dir.mu_ShrSet[p]) ; 
}
Sta.mu_Dir.mu_InvSet[p] = mu__boolexpr7;
};
};
Sta.mu_MemData = Sta.mu_ShWbMsg.mu_Data;
  };

};
/******************** RuleBase2 ********************/
class RuleBase2
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("NI_FAck");
  }
  bool Condition(unsigned r)
  {
    return (Sta.mu_ShWbMsg.mu_Cmd) == (SHWB_FAck);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 5;
    while (what_rule < 6 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_ShWbMsg.mu_Cmd) == (SHWB_FAck)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 5;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_ShWbMsg.mu_Cmd = SHWB_None;
Sta.mu_Dir.mu_Pending = false;
if ( Sta.mu_Dir.mu_Dirty )
{
Sta.mu_Dir.mu_HeadPtr = Sta.mu_ShWbMsg.mu_Proc;
}
  };

};
/******************** RuleBase3 ********************/
class RuleBase3
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("NI_Wb");
  }
  bool Condition(unsigned r)
  {
    return (Sta.mu_WbMsg.mu_Cmd) == (WB_Wb);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 6;
    while (what_rule < 7 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_WbMsg.mu_Cmd) == (WB_Wb)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 6;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_WbMsg.mu_Cmd = WB_None;
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_Dir.mu_HeadVld = false;
Sta.mu_MemData = Sta.mu_WbMsg.mu_Data;
  };

};
/******************** RuleBase4 ********************/
class RuleBase4
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_InvAck, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr8;
bool mu__boolexpr9;
bool mu__boolexpr10;
  if (!((src) != (Home))) mu__boolexpr10 = FALSE ;
  else {
  mu__boolexpr10 = ((Sta.mu_InvMsg[src].mu_Cmd) == (INV_InvAck)) ; 
}
  if (!(mu__boolexpr10)) mu__boolexpr9 = FALSE ;
  else {
  mu__boolexpr9 = (Sta.mu_Dir.mu_Pending) ; 
}
  if (!(mu__boolexpr9)) mu__boolexpr8 = FALSE ;
  else {
  mu__boolexpr8 = (Sta.mu_Dir.mu_InvSet[src]) ; 
}
    return mu__boolexpr8;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 7;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 11 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr11;
bool mu__boolexpr12;
bool mu__boolexpr13;
  if (!((src) != (Home))) mu__boolexpr13 = FALSE ;
  else {
  mu__boolexpr13 = ((Sta.mu_InvMsg[src].mu_Cmd) == (INV_InvAck)) ; 
}
  if (!(mu__boolexpr13)) mu__boolexpr12 = FALSE ;
  else {
  mu__boolexpr12 = (Sta.mu_Dir.mu_Pending) ; 
}
  if (!(mu__boolexpr12)) mu__boolexpr11 = FALSE ;
  else {
  mu__boolexpr11 = (Sta.mu_Dir.mu_InvSet[src]) ; 
}
	      if (mu__boolexpr11) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 7;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_InvMsg[src].mu_Cmd = INV_None;
Sta.mu_Dir.mu_InvSet[src] = false;
bool mu__quant14; 
mu__quant14 = FALSE;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr15;
  if (!((p) != (src))) mu__boolexpr15 = FALSE ;
  else {
  mu__boolexpr15 = (Sta.mu_Dir.mu_InvSet[p]) ; 
}
if ( (mu__boolexpr15) )
  { mu__quant14 = TRUE; break; }
};
};
if ( mu__quant14 )
{
Sta.mu_LastInvAck = src;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr16;
  if (!((p) != (src))) mu__boolexpr16 = FALSE ;
  else {
  mu__boolexpr16 = (Sta.mu_Dir.mu_InvSet[p]) ; 
}
if ( mu__boolexpr16 )
{
Sta.mu_LastOtherInvAck = p;
}
};
};
}
else
{
Sta.mu_Dir.mu_Pending = false;
bool mu__boolexpr17;
  if (!(Sta.mu_Dir.mu_Local)) mu__boolexpr17 = FALSE ;
  else {
  mu__boolexpr17 = (!(Sta.mu_Dir.mu_Dirty)) ; 
}
if ( mu__boolexpr17 )
{
Sta.mu_Dir.mu_Local = false;
}
Sta.mu_Collecting = false;
Sta.mu_LastInvAck = src;
}
  };

};
/******************** RuleBase5 ********************/
class RuleBase5
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Inv, dst:%s", dst.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr18;
  if (!((dst) != (Home))) mu__boolexpr18 = FALSE ;
  else {
  mu__boolexpr18 = ((Sta.mu_InvMsg[dst].mu_Cmd) == (INV_Inv)) ; 
}
    return mu__boolexpr18;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 11;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 15 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr19;
  if (!((dst) != (Home))) mu__boolexpr19 = FALSE ;
  else {
  mu__boolexpr19 = ((Sta.mu_InvMsg[dst].mu_Cmd) == (INV_Inv)) ; 
}
	      if (mu__boolexpr19) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 11;
    dst.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
Sta.mu_InvMsg[dst].mu_Cmd = INV_InvAck;
Sta.mu_Proc[dst].mu_CacheState = CACHE_I;
if ( (Sta.mu_Proc[dst].mu_ProcCmd) == (NODE_Get) )
{
Sta.mu_Proc[dst].mu_InvMarked = true;
}
  };

};
/******************** RuleBase6 ********************/
class RuleBase6
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Remote_PutX, dst:%s", dst.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr20;
bool mu__boolexpr21;
  if (!((dst) != (Home))) mu__boolexpr21 = FALSE ;
  else {
  mu__boolexpr21 = ((Sta.mu_UniMsg[dst].mu_Cmd) == (UNI_PutX)) ; 
}
  if (!(mu__boolexpr21)) mu__boolexpr20 = FALSE ;
  else {
  mu__boolexpr20 = ((Sta.mu_Proc[dst].mu_ProcCmd) == (NODE_GetX)) ; 
}
    return mu__boolexpr20;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 15;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 19 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr22;
bool mu__boolexpr23;
  if (!((dst) != (Home))) mu__boolexpr23 = FALSE ;
  else {
  mu__boolexpr23 = ((Sta.mu_UniMsg[dst].mu_Cmd) == (UNI_PutX)) ; 
}
  if (!(mu__boolexpr23)) mu__boolexpr22 = FALSE ;
  else {
  mu__boolexpr22 = ((Sta.mu_Proc[dst].mu_ProcCmd) == (NODE_GetX)) ; 
}
	      if (mu__boolexpr22) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 15;
    dst.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[dst].mu_Cmd = UNI_None;
Sta.mu_Proc[dst].mu_ProcCmd = NODE_None;
Sta.mu_Proc[dst].mu_InvMarked = false;
Sta.mu_Proc[dst].mu_CacheState = CACHE_E;
Sta.mu_Proc[dst].mu_CacheData = Sta.mu_UniMsg[dst].mu_Data;
  };

};
/******************** RuleBase7 ********************/
class RuleBase7
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("NI_Local_PutXAcksDone");
  }
  bool Condition(unsigned r)
  {
    return (Sta.mu_UniMsg[Home].mu_Cmd) == (UNI_PutX);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 19;
    while (what_rule < 20 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_UniMsg[Home].mu_Cmd) == (UNI_PutX)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 19;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_UniMsg[Home].mu_Cmd = UNI_None;
Sta.mu_Dir.mu_Pending = false;
Sta.mu_Dir.mu_Local = true;
Sta.mu_Dir.mu_HeadVld = false;
Sta.mu_Proc[Home].mu_ProcCmd = NODE_None;
Sta.mu_Proc[Home].mu_InvMarked = false;
Sta.mu_Proc[Home].mu_CacheState = CACHE_E;
Sta.mu_Proc[Home].mu_CacheData = Sta.mu_UniMsg[Home].mu_Data;
  };

};
/******************** RuleBase8 ********************/
class RuleBase8
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Remote_Put, dst:%s", dst.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr24;
  if (!((dst) != (Home))) mu__boolexpr24 = FALSE ;
  else {
  mu__boolexpr24 = ((Sta.mu_UniMsg[dst].mu_Cmd) == (UNI_Put)) ; 
}
    return mu__boolexpr24;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 20;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 24 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr25;
  if (!((dst) != (Home))) mu__boolexpr25 = FALSE ;
  else {
  mu__boolexpr25 = ((Sta.mu_UniMsg[dst].mu_Cmd) == (UNI_Put)) ; 
}
	      if (mu__boolexpr25) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 20;
    dst.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[dst].mu_Cmd = UNI_None;
Sta.mu_Proc[dst].mu_ProcCmd = NODE_None;
if ( Sta.mu_Proc[dst].mu_InvMarked )
{
Sta.mu_Proc[dst].mu_InvMarked = false;
Sta.mu_Proc[dst].mu_CacheState = CACHE_I;
}
else
{
Sta.mu_Proc[dst].mu_CacheState = CACHE_S;
Sta.mu_Proc[dst].mu_CacheData = Sta.mu_UniMsg[dst].mu_Data;
}
  };

};
/******************** RuleBase9 ********************/
class RuleBase9
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("NI_Local_Put");
  }
  bool Condition(unsigned r)
  {
    return (Sta.mu_UniMsg[Home].mu_Cmd) == (UNI_Put);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 24;
    while (what_rule < 25 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_UniMsg[Home].mu_Cmd) == (UNI_Put)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 24;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_UniMsg[Home].mu_Cmd = UNI_None;
Sta.mu_Dir.mu_Pending = false;
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_Dir.mu_Local = true;
Sta.mu_MemData = Sta.mu_UniMsg[Home].mu_Data;
Sta.mu_Proc[Home].mu_ProcCmd = NODE_None;
if ( Sta.mu_Proc[Home].mu_InvMarked )
{
Sta.mu_Proc[Home].mu_InvMarked = false;
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
}
else
{
Sta.mu_Proc[Home].mu_CacheState = CACHE_S;
Sta.mu_Proc[Home].mu_CacheData = Sta.mu_UniMsg[Home].mu_Data;
}
  };

};
/******************** RuleBase10 ********************/
class RuleBase10
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Remote_GetX_PutX, dst:%s, src:%s", dst.Name(), src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr26;
bool mu__boolexpr27;
bool mu__boolexpr28;
bool mu__boolexpr29;
  if (!((src) != (dst))) mu__boolexpr29 = FALSE ;
  else {
  mu__boolexpr29 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr29)) mu__boolexpr28 = FALSE ;
  else {
  mu__boolexpr28 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr28)) mu__boolexpr27 = FALSE ;
  else {
  mu__boolexpr27 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr27)) mu__boolexpr26 = FALSE ;
  else {
  mu__boolexpr26 = ((Sta.mu_Proc[dst].mu_CacheState) == (CACHE_E)) ; 
}
    return mu__boolexpr26;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 25;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 41 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr30;
bool mu__boolexpr31;
bool mu__boolexpr32;
bool mu__boolexpr33;
  if (!((src) != (dst))) mu__boolexpr33 = FALSE ;
  else {
  mu__boolexpr33 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr33)) mu__boolexpr32 = FALSE ;
  else {
  mu__boolexpr32 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr32)) mu__boolexpr31 = FALSE ;
  else {
  mu__boolexpr31 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr31)) mu__boolexpr30 = FALSE ;
  else {
  mu__boolexpr30 = ((Sta.mu_Proc[dst].mu_CacheState) == (CACHE_E)) ; 
}
	      if (mu__boolexpr30) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 25;
    dst.value((r % 4) + 0);
    r = r / 4;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[dst].mu_CacheState = CACHE_I;
Sta.mu_UniMsg[src].mu_Cmd = UNI_PutX;
Sta.mu_UniMsg[src].mu_Proc = dst;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_Proc[dst].mu_CacheData;
if ( (src) != (Home) )
{
Sta.mu_ShWbMsg.mu_Cmd = SHWB_FAck;
Sta.mu_ShWbMsg.mu_Proc = src;
}
Sta.mu_FwdCmd = UNI_None;
Sta.mu_FwdSrc = src;
  };

};
/******************** RuleBase11 ********************/
class RuleBase11
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Remote_GetX_Nak, dst:%s, src:%s", dst.Name(), src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr34;
bool mu__boolexpr35;
bool mu__boolexpr36;
bool mu__boolexpr37;
  if (!((src) != (dst))) mu__boolexpr37 = FALSE ;
  else {
  mu__boolexpr37 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr37)) mu__boolexpr36 = FALSE ;
  else {
  mu__boolexpr36 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr36)) mu__boolexpr35 = FALSE ;
  else {
  mu__boolexpr35 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr35)) mu__boolexpr34 = FALSE ;
  else {
  mu__boolexpr34 = ((Sta.mu_Proc[dst].mu_CacheState) != (CACHE_E)) ; 
}
    return mu__boolexpr34;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 41;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 57 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr38;
bool mu__boolexpr39;
bool mu__boolexpr40;
bool mu__boolexpr41;
  if (!((src) != (dst))) mu__boolexpr41 = FALSE ;
  else {
  mu__boolexpr41 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr41)) mu__boolexpr40 = FALSE ;
  else {
  mu__boolexpr40 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr40)) mu__boolexpr39 = FALSE ;
  else {
  mu__boolexpr39 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr39)) mu__boolexpr38 = FALSE ;
  else {
  mu__boolexpr38 = ((Sta.mu_Proc[dst].mu_CacheState) != (CACHE_E)) ; 
}
	      if (mu__boolexpr38) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 41;
    dst.value((r % 4) + 0);
    r = r / 4;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Nak;
Sta.mu_UniMsg[src].mu_Proc = dst;
Sta.mu_NakcMsg.mu_Cmd = NAKC_Nakc;
Sta.mu_FwdCmd = UNI_None;
Sta.mu_FwdSrc = src;
  };

};
/******************** RuleBase12 ********************/
class RuleBase12
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Local_GetX_PutX, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr42;
bool mu__boolexpr43;
bool mu__boolexpr44;
bool mu__boolexpr45;
  if (!((src) != (Home))) mu__boolexpr45 = FALSE ;
  else {
  mu__boolexpr45 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr45)) mu__boolexpr44 = FALSE ;
  else {
  mu__boolexpr44 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr44)) mu__boolexpr43 = FALSE ;
  else {
  mu__boolexpr43 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr43)) mu__boolexpr42 = FALSE ;
  else {
bool mu__boolexpr46;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr46 = TRUE ;
  else {
bool mu__boolexpr47;
  if (!(Sta.mu_Dir.mu_Local)) mu__boolexpr47 = FALSE ;
  else {
  mu__boolexpr47 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_E)) ; 
}
  mu__boolexpr46 = (mu__boolexpr47) ; 
}
  mu__boolexpr42 = (mu__boolexpr46) ; 
}
    return mu__boolexpr42;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 57;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 61 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr48;
bool mu__boolexpr49;
bool mu__boolexpr50;
bool mu__boolexpr51;
  if (!((src) != (Home))) mu__boolexpr51 = FALSE ;
  else {
  mu__boolexpr51 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr51)) mu__boolexpr50 = FALSE ;
  else {
  mu__boolexpr50 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr50)) mu__boolexpr49 = FALSE ;
  else {
  mu__boolexpr49 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr49)) mu__boolexpr48 = FALSE ;
  else {
bool mu__boolexpr52;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr52 = TRUE ;
  else {
bool mu__boolexpr53;
  if (!(Sta.mu_Dir.mu_Local)) mu__boolexpr53 = FALSE ;
  else {
  mu__boolexpr53 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_E)) ; 
}
  mu__boolexpr52 = (mu__boolexpr53) ; 
}
  mu__boolexpr48 = (mu__boolexpr52) ; 
}
	      if (mu__boolexpr48) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 57;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
if ( Sta.mu_Dir.mu_Dirty )
{
Sta.mu_Dir.mu_Local = false;
Sta.mu_Dir.mu_Dirty = true;
Sta.mu_Dir.mu_HeadVld = true;
Sta.mu_Dir.mu_HeadPtr = src;
Sta.mu_Dir.mu_ShrVld = false;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
Sta.mu_Dir.mu_ShrSet[p] = false;
Sta.mu_Dir.mu_InvSet[p] = false;
};
};
Sta.mu_UniMsg[src].mu_Cmd = UNI_PutX;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_Proc[Home].mu_CacheData;
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
}
else
{
bool mu__boolexpr54;
  if (!(Sta.mu_Dir.mu_HeadVld)) mu__boolexpr54 = TRUE ;
  else {
bool mu__boolexpr55;
  if (!((Sta.mu_Dir.mu_HeadPtr) == (src))) mu__boolexpr55 = FALSE ;
  else {
bool mu__quant56; 
mu__quant56 = TRUE;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr57;
  if (!((p) != (src))) mu__boolexpr57 = TRUE ;
  else {
  mu__boolexpr57 = (!(Sta.mu_Dir.mu_ShrSet[p])) ; 
}
if ( !(mu__boolexpr57) )
  { mu__quant56 = FALSE; break; }
};
};
  mu__boolexpr55 = (mu__quant56) ; 
}
  mu__boolexpr54 = (mu__boolexpr55) ; 
}
if ( mu__boolexpr54 )
{
Sta.mu_Dir.mu_Local = false;
Sta.mu_Dir.mu_Dirty = true;
Sta.mu_Dir.mu_HeadVld = true;
Sta.mu_Dir.mu_HeadPtr = src;
Sta.mu_Dir.mu_ShrVld = false;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
Sta.mu_Dir.mu_ShrSet[p] = false;
Sta.mu_Dir.mu_InvSet[p] = false;
};
};
Sta.mu_UniMsg[src].mu_Cmd = UNI_PutX;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_MemData;
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
if ( Sta.mu_Dir.mu_Local )
{
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
if ( (Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_Get) )
{
Sta.mu_Proc[Home].mu_InvMarked = true;
}
}
}
else
{
Sta.mu_Dir.mu_Pending = true;
Sta.mu_Dir.mu_Local = false;
Sta.mu_Dir.mu_Dirty = true;
Sta.mu_Dir.mu_HeadVld = true;
Sta.mu_Dir.mu_HeadPtr = src;
Sta.mu_Dir.mu_ShrVld = false;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
Sta.mu_Dir.mu_ShrSet[p] = false;
bool mu__boolexpr58;
bool mu__boolexpr59;
  if (!((p) != (Home))) mu__boolexpr59 = FALSE ;
  else {
  mu__boolexpr59 = ((p) != (src)) ; 
}
  if (!(mu__boolexpr59)) mu__boolexpr58 = FALSE ;
  else {
bool mu__boolexpr60;
bool mu__boolexpr61;
  if (!(Sta.mu_Dir.mu_ShrVld)) mu__boolexpr61 = FALSE ;
  else {
  mu__boolexpr61 = (Sta.mu_Dir.mu_ShrSet[p]) ; 
}
  if (mu__boolexpr61) mu__boolexpr60 = TRUE ;
  else {
bool mu__boolexpr62;
  if (!(Sta.mu_Dir.mu_HeadVld)) mu__boolexpr62 = FALSE ;
  else {
  mu__boolexpr62 = ((Sta.mu_Dir.mu_HeadPtr) == (p)) ; 
}
  mu__boolexpr60 = (mu__boolexpr62) ; 
}
  mu__boolexpr58 = (mu__boolexpr60) ; 
}
if ( mu__boolexpr58 )
{
Sta.mu_Dir.mu_InvSet[p] = true;
Sta.mu_InvMsg[p].mu_Cmd = INV_Inv;
}
else
{
Sta.mu_Dir.mu_InvSet[p] = false;
Sta.mu_InvMsg[p].mu_Cmd = INV_None;
}
};
};
Sta.mu_UniMsg[src].mu_Cmd = UNI_PutX;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_MemData;
if ( Sta.mu_Dir.mu_Local )
{
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
if ( (Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_Get) )
{
Sta.mu_Proc[Home].mu_InvMarked = true;
}
}
Sta.mu_Requester = src;
Sta.mu_Collecting = true;
Sta.mu_PrevData = Sta.mu_CurrData;
if ( (Sta.mu_Dir.mu_HeadPtr) != (src) )
{
Sta.mu_LastOtherInvAck = Sta.mu_Dir.mu_HeadPtr;
}
else
{
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr63;
  if (!((p) != (src))) mu__boolexpr63 = FALSE ;
  else {
  mu__boolexpr63 = (Sta.mu_Dir.mu_ShrSet[p]) ; 
}
if ( mu__boolexpr63 )
{
Sta.mu_LastOtherInvAck = p;
}
};
};
}
}
}
  };

};
/******************** RuleBase13 ********************/
class RuleBase13
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Local_GetX_GetX, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr64;
bool mu__boolexpr65;
bool mu__boolexpr66;
bool mu__boolexpr67;
bool mu__boolexpr68;
bool mu__boolexpr69;
  if (!((src) != (Home))) mu__boolexpr69 = FALSE ;
  else {
  mu__boolexpr69 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr69)) mu__boolexpr68 = FALSE ;
  else {
  mu__boolexpr68 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr68)) mu__boolexpr67 = FALSE ;
  else {
  mu__boolexpr67 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr67)) mu__boolexpr66 = FALSE ;
  else {
  mu__boolexpr66 = (Sta.mu_Dir.mu_Dirty) ; 
}
  if (!(mu__boolexpr66)) mu__boolexpr65 = FALSE ;
  else {
  mu__boolexpr65 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr65)) mu__boolexpr64 = FALSE ;
  else {
  mu__boolexpr64 = ((Sta.mu_Dir.mu_HeadPtr) != (src)) ; 
}
    return mu__boolexpr64;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 61;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 65 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr70;
bool mu__boolexpr71;
bool mu__boolexpr72;
bool mu__boolexpr73;
bool mu__boolexpr74;
bool mu__boolexpr75;
  if (!((src) != (Home))) mu__boolexpr75 = FALSE ;
  else {
  mu__boolexpr75 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr75)) mu__boolexpr74 = FALSE ;
  else {
  mu__boolexpr74 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr74)) mu__boolexpr73 = FALSE ;
  else {
  mu__boolexpr73 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr73)) mu__boolexpr72 = FALSE ;
  else {
  mu__boolexpr72 = (Sta.mu_Dir.mu_Dirty) ; 
}
  if (!(mu__boolexpr72)) mu__boolexpr71 = FALSE ;
  else {
  mu__boolexpr71 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr71)) mu__boolexpr70 = FALSE ;
  else {
  mu__boolexpr70 = ((Sta.mu_Dir.mu_HeadPtr) != (src)) ; 
}
	      if (mu__boolexpr70) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 61;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Dir.mu_Pending = true;
Sta.mu_UniMsg[src].mu_Cmd = UNI_GetX;
Sta.mu_UniMsg[src].mu_Proc = Sta.mu_Dir.mu_HeadPtr;
if ( (Sta.mu_Dir.mu_HeadPtr) != (Home) )
{
Sta.mu_FwdCmd = UNI_GetX;
}
Sta.mu_Requester = src;
Sta.mu_Collecting = false;
  };

};
/******************** RuleBase14 ********************/
class RuleBase14
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Local_GetX_Nak, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr76;
bool mu__boolexpr77;
bool mu__boolexpr78;
  if (!((src) != (Home))) mu__boolexpr78 = FALSE ;
  else {
  mu__boolexpr78 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr78)) mu__boolexpr77 = FALSE ;
  else {
  mu__boolexpr77 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr77)) mu__boolexpr76 = FALSE ;
  else {
bool mu__boolexpr79;
bool mu__boolexpr80;
  if (Sta.mu_Dir.mu_Pending) mu__boolexpr80 = TRUE ;
  else {
bool mu__boolexpr81;
bool mu__boolexpr82;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr82 = FALSE ;
  else {
  mu__boolexpr82 = (Sta.mu_Dir.mu_Local) ; 
}
  if (!(mu__boolexpr82)) mu__boolexpr81 = FALSE ;
  else {
  mu__boolexpr81 = ((Sta.mu_Proc[Home].mu_CacheState) != (CACHE_E)) ; 
}
  mu__boolexpr80 = (mu__boolexpr81) ; 
}
  if (mu__boolexpr80) mu__boolexpr79 = TRUE ;
  else {
bool mu__boolexpr83;
bool mu__boolexpr84;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr84 = FALSE ;
  else {
  mu__boolexpr84 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr84)) mu__boolexpr83 = FALSE ;
  else {
  mu__boolexpr83 = ((Sta.mu_Dir.mu_HeadPtr) == (src)) ; 
}
  mu__boolexpr79 = (mu__boolexpr83) ; 
}
  mu__boolexpr76 = (mu__boolexpr79) ; 
}
    return mu__boolexpr76;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 65;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 69 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr85;
bool mu__boolexpr86;
bool mu__boolexpr87;
  if (!((src) != (Home))) mu__boolexpr87 = FALSE ;
  else {
  mu__boolexpr87 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_GetX)) ; 
}
  if (!(mu__boolexpr87)) mu__boolexpr86 = FALSE ;
  else {
  mu__boolexpr86 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr86)) mu__boolexpr85 = FALSE ;
  else {
bool mu__boolexpr88;
bool mu__boolexpr89;
  if (Sta.mu_Dir.mu_Pending) mu__boolexpr89 = TRUE ;
  else {
bool mu__boolexpr90;
bool mu__boolexpr91;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr91 = FALSE ;
  else {
  mu__boolexpr91 = (Sta.mu_Dir.mu_Local) ; 
}
  if (!(mu__boolexpr91)) mu__boolexpr90 = FALSE ;
  else {
  mu__boolexpr90 = ((Sta.mu_Proc[Home].mu_CacheState) != (CACHE_E)) ; 
}
  mu__boolexpr89 = (mu__boolexpr90) ; 
}
  if (mu__boolexpr89) mu__boolexpr88 = TRUE ;
  else {
bool mu__boolexpr92;
bool mu__boolexpr93;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr93 = FALSE ;
  else {
  mu__boolexpr93 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr93)) mu__boolexpr92 = FALSE ;
  else {
  mu__boolexpr92 = ((Sta.mu_Dir.mu_HeadPtr) == (src)) ; 
}
  mu__boolexpr88 = (mu__boolexpr92) ; 
}
  mu__boolexpr85 = (mu__boolexpr88) ; 
}
	      if (mu__boolexpr85) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 65;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Nak;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
  };

};
/******************** RuleBase15 ********************/
class RuleBase15
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Remote_Get_Put, dst:%s, src:%s", dst.Name(), src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr94;
bool mu__boolexpr95;
bool mu__boolexpr96;
bool mu__boolexpr97;
  if (!((src) != (dst))) mu__boolexpr97 = FALSE ;
  else {
  mu__boolexpr97 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr97)) mu__boolexpr96 = FALSE ;
  else {
  mu__boolexpr96 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr96)) mu__boolexpr95 = FALSE ;
  else {
  mu__boolexpr95 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr95)) mu__boolexpr94 = FALSE ;
  else {
  mu__boolexpr94 = ((Sta.mu_Proc[dst].mu_CacheState) == (CACHE_E)) ; 
}
    return mu__boolexpr94;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 69;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 85 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr98;
bool mu__boolexpr99;
bool mu__boolexpr100;
bool mu__boolexpr101;
  if (!((src) != (dst))) mu__boolexpr101 = FALSE ;
  else {
  mu__boolexpr101 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr101)) mu__boolexpr100 = FALSE ;
  else {
  mu__boolexpr100 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr100)) mu__boolexpr99 = FALSE ;
  else {
  mu__boolexpr99 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr99)) mu__boolexpr98 = FALSE ;
  else {
  mu__boolexpr98 = ((Sta.mu_Proc[dst].mu_CacheState) == (CACHE_E)) ; 
}
	      if (mu__boolexpr98) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 69;
    dst.value((r % 4) + 0);
    r = r / 4;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[dst].mu_CacheState = CACHE_S;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Put;
Sta.mu_UniMsg[src].mu_Proc = dst;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_Proc[dst].mu_CacheData;
if ( (src) != (Home) )
{
Sta.mu_ShWbMsg.mu_Cmd = SHWB_ShWb;
Sta.mu_ShWbMsg.mu_Proc = src;
Sta.mu_ShWbMsg.mu_Data = Sta.mu_Proc[dst].mu_CacheData;
}
Sta.mu_FwdCmd = UNI_None;
Sta.mu_FwdSrc = src;
  };

};
/******************** RuleBase16 ********************/
class RuleBase16
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Remote_Get_Nak, dst:%s, src:%s", dst.Name(), src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr102;
bool mu__boolexpr103;
bool mu__boolexpr104;
bool mu__boolexpr105;
  if (!((src) != (dst))) mu__boolexpr105 = FALSE ;
  else {
  mu__boolexpr105 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr105)) mu__boolexpr104 = FALSE ;
  else {
  mu__boolexpr104 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr104)) mu__boolexpr103 = FALSE ;
  else {
  mu__boolexpr103 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr103)) mu__boolexpr102 = FALSE ;
  else {
  mu__boolexpr102 = ((Sta.mu_Proc[dst].mu_CacheState) != (CACHE_E)) ; 
}
    return mu__boolexpr102;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 85;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 101 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr106;
bool mu__boolexpr107;
bool mu__boolexpr108;
bool mu__boolexpr109;
  if (!((src) != (dst))) mu__boolexpr109 = FALSE ;
  else {
  mu__boolexpr109 = ((dst) != (Home)) ; 
}
  if (!(mu__boolexpr109)) mu__boolexpr108 = FALSE ;
  else {
  mu__boolexpr108 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr108)) mu__boolexpr107 = FALSE ;
  else {
  mu__boolexpr107 = ((Sta.mu_UniMsg[src].mu_Proc) == (dst)) ; 
}
  if (!(mu__boolexpr107)) mu__boolexpr106 = FALSE ;
  else {
  mu__boolexpr106 = ((Sta.mu_Proc[dst].mu_CacheState) != (CACHE_E)) ; 
}
	      if (mu__boolexpr106) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 85;
    dst.value((r % 4) + 0);
    r = r / 4;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Nak;
Sta.mu_UniMsg[src].mu_Proc = dst;
Sta.mu_NakcMsg.mu_Cmd = NAKC_Nakc;
Sta.mu_FwdCmd = UNI_None;
Sta.mu_FwdSrc = src;
  };

};
/******************** RuleBase17 ********************/
class RuleBase17
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Local_Get_Put, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr110;
bool mu__boolexpr111;
bool mu__boolexpr112;
bool mu__boolexpr113;
bool mu__boolexpr114;
  if (!((src) != (Home))) mu__boolexpr114 = FALSE ;
  else {
  mu__boolexpr114 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr114)) mu__boolexpr113 = FALSE ;
  else {
  mu__boolexpr113 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr113)) mu__boolexpr112 = FALSE ;
  else {
  mu__boolexpr112 = ((Sta.mu_RpMsg[src].mu_Cmd) != (RP_Replace)) ; 
}
  if (!(mu__boolexpr112)) mu__boolexpr111 = FALSE ;
  else {
  mu__boolexpr111 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr111)) mu__boolexpr110 = FALSE ;
  else {
bool mu__boolexpr115;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr115 = TRUE ;
  else {
bool mu__boolexpr116;
  if (!(Sta.mu_Dir.mu_Local)) mu__boolexpr116 = FALSE ;
  else {
  mu__boolexpr116 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_E)) ; 
}
  mu__boolexpr115 = (mu__boolexpr116) ; 
}
  mu__boolexpr110 = (mu__boolexpr115) ; 
}
    return mu__boolexpr110;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 101;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 105 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr117;
bool mu__boolexpr118;
bool mu__boolexpr119;
bool mu__boolexpr120;
bool mu__boolexpr121;
  if (!((src) != (Home))) mu__boolexpr121 = FALSE ;
  else {
  mu__boolexpr121 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr121)) mu__boolexpr120 = FALSE ;
  else {
  mu__boolexpr120 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr120)) mu__boolexpr119 = FALSE ;
  else {
  mu__boolexpr119 = ((Sta.mu_RpMsg[src].mu_Cmd) != (RP_Replace)) ; 
}
  if (!(mu__boolexpr119)) mu__boolexpr118 = FALSE ;
  else {
  mu__boolexpr118 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr118)) mu__boolexpr117 = FALSE ;
  else {
bool mu__boolexpr122;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr122 = TRUE ;
  else {
bool mu__boolexpr123;
  if (!(Sta.mu_Dir.mu_Local)) mu__boolexpr123 = FALSE ;
  else {
  mu__boolexpr123 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_E)) ; 
}
  mu__boolexpr122 = (mu__boolexpr123) ; 
}
  mu__boolexpr117 = (mu__boolexpr122) ; 
}
	      if (mu__boolexpr117) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 101;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
if ( Sta.mu_Dir.mu_Dirty )
{
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_Dir.mu_HeadVld = true;
Sta.mu_Dir.mu_HeadPtr = src;
Sta.mu_MemData = Sta.mu_Proc[Home].mu_CacheData;
Sta.mu_Proc[Home].mu_CacheState = CACHE_S;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Put;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_Proc[Home].mu_CacheData;
}
else
{
if ( Sta.mu_Dir.mu_HeadVld )
{
Sta.mu_Dir.mu_ShrVld = true;
Sta.mu_Dir.mu_ShrSet[src] = true;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr124;
  if ((p) == (src)) mu__boolexpr124 = TRUE ;
  else {
  mu__boolexpr124 = (Sta.mu_Dir.mu_ShrSet[p]) ; 
}
if ( mu__boolexpr124 )
{
Sta.mu_Dir.mu_InvSet[p] = true;
}
else
{
Sta.mu_Dir.mu_InvSet[p] = false;
}
};
};
}
else
{
Sta.mu_Dir.mu_HeadVld = true;
Sta.mu_Dir.mu_HeadPtr = src;
}
Sta.mu_UniMsg[src].mu_Cmd = UNI_Put;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
Sta.mu_UniMsg[src].mu_Data = Sta.mu_MemData;
}
  };

};
/******************** RuleBase18 ********************/
class RuleBase18
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Local_Get_Get, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr125;
bool mu__boolexpr126;
bool mu__boolexpr127;
bool mu__boolexpr128;
bool mu__boolexpr129;
bool mu__boolexpr130;
bool mu__boolexpr131;
  if (!((src) != (Home))) mu__boolexpr131 = FALSE ;
  else {
  mu__boolexpr131 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr131)) mu__boolexpr130 = FALSE ;
  else {
  mu__boolexpr130 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr130)) mu__boolexpr129 = FALSE ;
  else {
  mu__boolexpr129 = ((Sta.mu_RpMsg[src].mu_Cmd) != (RP_Replace)) ; 
}
  if (!(mu__boolexpr129)) mu__boolexpr128 = FALSE ;
  else {
  mu__boolexpr128 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr128)) mu__boolexpr127 = FALSE ;
  else {
  mu__boolexpr127 = (Sta.mu_Dir.mu_Dirty) ; 
}
  if (!(mu__boolexpr127)) mu__boolexpr126 = FALSE ;
  else {
  mu__boolexpr126 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr126)) mu__boolexpr125 = FALSE ;
  else {
  mu__boolexpr125 = ((Sta.mu_Dir.mu_HeadPtr) != (src)) ; 
}
    return mu__boolexpr125;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 105;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 109 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr132;
bool mu__boolexpr133;
bool mu__boolexpr134;
bool mu__boolexpr135;
bool mu__boolexpr136;
bool mu__boolexpr137;
bool mu__boolexpr138;
  if (!((src) != (Home))) mu__boolexpr138 = FALSE ;
  else {
  mu__boolexpr138 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr138)) mu__boolexpr137 = FALSE ;
  else {
  mu__boolexpr137 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr137)) mu__boolexpr136 = FALSE ;
  else {
  mu__boolexpr136 = ((Sta.mu_RpMsg[src].mu_Cmd) != (RP_Replace)) ; 
}
  if (!(mu__boolexpr136)) mu__boolexpr135 = FALSE ;
  else {
  mu__boolexpr135 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr135)) mu__boolexpr134 = FALSE ;
  else {
  mu__boolexpr134 = (Sta.mu_Dir.mu_Dirty) ; 
}
  if (!(mu__boolexpr134)) mu__boolexpr133 = FALSE ;
  else {
  mu__boolexpr133 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr133)) mu__boolexpr132 = FALSE ;
  else {
  mu__boolexpr132 = ((Sta.mu_Dir.mu_HeadPtr) != (src)) ; 
}
	      if (mu__boolexpr132) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 105;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Dir.mu_Pending = true;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Get;
Sta.mu_UniMsg[src].mu_Proc = Sta.mu_Dir.mu_HeadPtr;
if ( (Sta.mu_Dir.mu_HeadPtr) != (Home) )
{
Sta.mu_FwdCmd = UNI_Get;
}
Sta.mu_Requester = src;
Sta.mu_Collecting = false;
  };

};
/******************** RuleBase19 ********************/
class RuleBase19
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Local_Get_Nak, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr139;
bool mu__boolexpr140;
bool mu__boolexpr141;
bool mu__boolexpr142;
  if (!((src) != (Home))) mu__boolexpr142 = FALSE ;
  else {
  mu__boolexpr142 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr142)) mu__boolexpr141 = FALSE ;
  else {
  mu__boolexpr141 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr141)) mu__boolexpr140 = FALSE ;
  else {
  mu__boolexpr140 = ((Sta.mu_RpMsg[src].mu_Cmd) != (RP_Replace)) ; 
}
  if (!(mu__boolexpr140)) mu__boolexpr139 = FALSE ;
  else {
bool mu__boolexpr143;
bool mu__boolexpr144;
  if (Sta.mu_Dir.mu_Pending) mu__boolexpr144 = TRUE ;
  else {
bool mu__boolexpr145;
bool mu__boolexpr146;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr146 = FALSE ;
  else {
  mu__boolexpr146 = (Sta.mu_Dir.mu_Local) ; 
}
  if (!(mu__boolexpr146)) mu__boolexpr145 = FALSE ;
  else {
  mu__boolexpr145 = ((Sta.mu_Proc[Home].mu_CacheState) != (CACHE_E)) ; 
}
  mu__boolexpr144 = (mu__boolexpr145) ; 
}
  if (mu__boolexpr144) mu__boolexpr143 = TRUE ;
  else {
bool mu__boolexpr147;
bool mu__boolexpr148;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr148 = FALSE ;
  else {
  mu__boolexpr148 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr148)) mu__boolexpr147 = FALSE ;
  else {
  mu__boolexpr147 = ((Sta.mu_Dir.mu_HeadPtr) == (src)) ; 
}
  mu__boolexpr143 = (mu__boolexpr147) ; 
}
  mu__boolexpr139 = (mu__boolexpr143) ; 
}
    return mu__boolexpr139;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 109;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 113 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr149;
bool mu__boolexpr150;
bool mu__boolexpr151;
bool mu__boolexpr152;
  if (!((src) != (Home))) mu__boolexpr152 = FALSE ;
  else {
  mu__boolexpr152 = ((Sta.mu_UniMsg[src].mu_Cmd) == (UNI_Get)) ; 
}
  if (!(mu__boolexpr152)) mu__boolexpr151 = FALSE ;
  else {
  mu__boolexpr151 = ((Sta.mu_UniMsg[src].mu_Proc) == (Home)) ; 
}
  if (!(mu__boolexpr151)) mu__boolexpr150 = FALSE ;
  else {
  mu__boolexpr150 = ((Sta.mu_RpMsg[src].mu_Cmd) != (RP_Replace)) ; 
}
  if (!(mu__boolexpr150)) mu__boolexpr149 = FALSE ;
  else {
bool mu__boolexpr153;
bool mu__boolexpr154;
  if (Sta.mu_Dir.mu_Pending) mu__boolexpr154 = TRUE ;
  else {
bool mu__boolexpr155;
bool mu__boolexpr156;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr156 = FALSE ;
  else {
  mu__boolexpr156 = (Sta.mu_Dir.mu_Local) ; 
}
  if (!(mu__boolexpr156)) mu__boolexpr155 = FALSE ;
  else {
  mu__boolexpr155 = ((Sta.mu_Proc[Home].mu_CacheState) != (CACHE_E)) ; 
}
  mu__boolexpr154 = (mu__boolexpr155) ; 
}
  if (mu__boolexpr154) mu__boolexpr153 = TRUE ;
  else {
bool mu__boolexpr157;
bool mu__boolexpr158;
  if (!(Sta.mu_Dir.mu_Dirty)) mu__boolexpr158 = FALSE ;
  else {
  mu__boolexpr158 = (!(Sta.mu_Dir.mu_Local)) ; 
}
  if (!(mu__boolexpr158)) mu__boolexpr157 = FALSE ;
  else {
  mu__boolexpr157 = ((Sta.mu_Dir.mu_HeadPtr) == (src)) ; 
}
  mu__boolexpr153 = (mu__boolexpr157) ; 
}
  mu__boolexpr149 = (mu__boolexpr153) ; 
}
	      if (mu__boolexpr149) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 109;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Nak;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
  };

};
/******************** RuleBase20 ********************/
class RuleBase20
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("NI_Nak_Clear");
  }
  bool Condition(unsigned r)
  {
    return (Sta.mu_NakcMsg.mu_Cmd) == (NAKC_Nakc);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 113;
    while (what_rule < 114 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_NakcMsg.mu_Cmd) == (NAKC_Nakc)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 113;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_NakcMsg.mu_Cmd = NAKC_None;
Sta.mu_Dir.mu_Pending = false;
  };

};
/******************** RuleBase21 ********************/
class RuleBase21
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("NI_Nak, dst:%s", dst.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    return (Sta.mu_UniMsg[dst].mu_Cmd) == (UNI_Nak);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 114;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 118 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_UniMsg[dst].mu_Cmd) == (UNI_Nak)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 114;
    dst.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
Sta.mu_UniMsg[dst].mu_Cmd = UNI_None;
Sta.mu_Proc[dst].mu_ProcCmd = NODE_None;
Sta.mu_Proc[dst].mu_InvMarked = false;
  };

};
/******************** RuleBase22 ********************/
class RuleBase22
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("PI_Local_Replace");
  }
  bool Condition(unsigned r)
  {
bool mu__boolexpr159;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr159 = FALSE ;
  else {
  mu__boolexpr159 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_S)) ; 
}
    return mu__boolexpr159;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 118;
    while (what_rule < 119 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr160;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr160 = FALSE ;
  else {
  mu__boolexpr160 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_S)) ; 
}
	      if (mu__boolexpr160) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 118;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_Dir.mu_Local = false;
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
  };

};
/******************** RuleBase23 ********************/
class RuleBase23
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("PI_Remote_Replace, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr161;
bool mu__boolexpr162;
  if (!((src) != (Home))) mu__boolexpr162 = FALSE ;
  else {
  mu__boolexpr162 = ((Sta.mu_Proc[src].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr162)) mu__boolexpr161 = FALSE ;
  else {
  mu__boolexpr161 = ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_S)) ; 
}
    return mu__boolexpr161;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 119;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 123 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr163;
bool mu__boolexpr164;
  if (!((src) != (Home))) mu__boolexpr164 = FALSE ;
  else {
  mu__boolexpr164 = ((Sta.mu_Proc[src].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr164)) mu__boolexpr163 = FALSE ;
  else {
  mu__boolexpr163 = ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_S)) ; 
}
	      if (mu__boolexpr163) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 119;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[src].mu_CacheState = CACHE_I;
Sta.mu_RpMsg[src].mu_Cmd = RP_Replace;
  };

};
/******************** RuleBase24 ********************/
class RuleBase24
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("PI_Local_PutX");
  }
  bool Condition(unsigned r)
  {
bool mu__boolexpr165;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr165 = FALSE ;
  else {
  mu__boolexpr165 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_E)) ; 
}
    return mu__boolexpr165;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 123;
    while (what_rule < 124 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr166;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr166 = FALSE ;
  else {
  mu__boolexpr166 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_E)) ; 
}
	      if (mu__boolexpr166) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 123;
    }
  }

  void Code(unsigned r)
  {
if ( Sta.mu_Dir.mu_Pending )
{
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_MemData = Sta.mu_Proc[Home].mu_CacheData;
}
else
{
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
Sta.mu_Dir.mu_Local = false;
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_MemData = Sta.mu_Proc[Home].mu_CacheData;
}
  };

};
/******************** RuleBase25 ********************/
class RuleBase25
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("PI_Remote_PutX, dst:%s", dst.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr167;
bool mu__boolexpr168;
  if (!((dst) != (Home))) mu__boolexpr168 = FALSE ;
  else {
  mu__boolexpr168 = ((Sta.mu_Proc[dst].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr168)) mu__boolexpr167 = FALSE ;
  else {
  mu__boolexpr167 = ((Sta.mu_Proc[dst].mu_CacheState) == (CACHE_E)) ; 
}
    return mu__boolexpr167;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 124;
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 128 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr169;
bool mu__boolexpr170;
  if (!((dst) != (Home))) mu__boolexpr170 = FALSE ;
  else {
  mu__boolexpr170 = ((Sta.mu_Proc[dst].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr170)) mu__boolexpr169 = FALSE ;
  else {
  mu__boolexpr169 = ((Sta.mu_Proc[dst].mu_CacheState) == (CACHE_E)) ; 
}
	      if (mu__boolexpr169) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 124;
    dst.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE dst;
    dst.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[dst].mu_CacheState = CACHE_I;
Sta.mu_WbMsg.mu_Cmd = WB_Wb;
Sta.mu_WbMsg.mu_Proc = dst;
Sta.mu_WbMsg.mu_Data = Sta.mu_Proc[dst].mu_CacheData;
  };

};
/******************** RuleBase26 ********************/
class RuleBase26
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("PI_Local_GetX_PutX");
  }
  bool Condition(unsigned r)
  {
bool mu__boolexpr171;
bool mu__boolexpr172;
bool mu__boolexpr173;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr173 = FALSE ;
  else {
bool mu__boolexpr174;
  if ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) mu__boolexpr174 = TRUE ;
  else {
  mu__boolexpr174 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_S)) ; 
}
  mu__boolexpr173 = (mu__boolexpr174) ; 
}
  if (!(mu__boolexpr173)) mu__boolexpr172 = FALSE ;
  else {
  mu__boolexpr172 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr172)) mu__boolexpr171 = FALSE ;
  else {
  mu__boolexpr171 = (!(Sta.mu_Dir.mu_Dirty)) ; 
}
    return mu__boolexpr171;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 128;
    while (what_rule < 129 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr175;
bool mu__boolexpr176;
bool mu__boolexpr177;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr177 = FALSE ;
  else {
bool mu__boolexpr178;
  if ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) mu__boolexpr178 = TRUE ;
  else {
  mu__boolexpr178 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_S)) ; 
}
  mu__boolexpr177 = (mu__boolexpr178) ; 
}
  if (!(mu__boolexpr177)) mu__boolexpr176 = FALSE ;
  else {
  mu__boolexpr176 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr176)) mu__boolexpr175 = FALSE ;
  else {
  mu__boolexpr175 = (!(Sta.mu_Dir.mu_Dirty)) ; 
}
	      if (mu__boolexpr175) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 128;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_Dir.mu_Local = true;
Sta.mu_Dir.mu_Dirty = true;
if ( Sta.mu_Dir.mu_HeadVld )
{
Sta.mu_Dir.mu_Pending = true;
Sta.mu_Dir.mu_HeadVld = false;
Sta.mu_Dir.mu_ShrVld = false;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
Sta.mu_Dir.mu_ShrSet[p] = false;
bool mu__boolexpr179;
  if (!((p) != (Home))) mu__boolexpr179 = FALSE ;
  else {
bool mu__boolexpr180;
bool mu__boolexpr181;
  if (!(Sta.mu_Dir.mu_ShrVld)) mu__boolexpr181 = FALSE ;
  else {
  mu__boolexpr181 = (Sta.mu_Dir.mu_ShrSet[p]) ; 
}
  if (mu__boolexpr181) mu__boolexpr180 = TRUE ;
  else {
bool mu__boolexpr182;
  if (!(Sta.mu_Dir.mu_HeadVld)) mu__boolexpr182 = FALSE ;
  else {
  mu__boolexpr182 = ((Sta.mu_Dir.mu_HeadPtr) == (p)) ; 
}
  mu__boolexpr180 = (mu__boolexpr182) ; 
}
  mu__boolexpr179 = (mu__boolexpr180) ; 
}
if ( mu__boolexpr179 )
{
Sta.mu_Dir.mu_InvSet[p] = true;
Sta.mu_InvMsg[p].mu_Cmd = INV_Inv;
}
else
{
Sta.mu_Dir.mu_InvSet[p] = false;
Sta.mu_InvMsg[p].mu_Cmd = INV_None;
}
};
};
Sta.mu_Collecting = true;
Sta.mu_PrevData = Sta.mu_CurrData;
Sta.mu_LastOtherInvAck = Sta.mu_Dir.mu_HeadPtr;
}
Sta.mu_Proc[Home].mu_ProcCmd = NODE_None;
Sta.mu_Proc[Home].mu_InvMarked = false;
Sta.mu_Proc[Home].mu_CacheState = CACHE_E;
Sta.mu_Proc[Home].mu_CacheData = Sta.mu_MemData;
  };

};
/******************** RuleBase27 ********************/
class RuleBase27
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("PI_Local_GetX_GetX");
  }
  bool Condition(unsigned r)
  {
bool mu__boolexpr183;
bool mu__boolexpr184;
bool mu__boolexpr185;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr185 = FALSE ;
  else {
bool mu__boolexpr186;
  if ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) mu__boolexpr186 = TRUE ;
  else {
  mu__boolexpr186 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_S)) ; 
}
  mu__boolexpr185 = (mu__boolexpr186) ; 
}
  if (!(mu__boolexpr185)) mu__boolexpr184 = FALSE ;
  else {
  mu__boolexpr184 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr184)) mu__boolexpr183 = FALSE ;
  else {
  mu__boolexpr183 = (Sta.mu_Dir.mu_Dirty) ; 
}
    return mu__boolexpr183;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 129;
    while (what_rule < 130 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr187;
bool mu__boolexpr188;
bool mu__boolexpr189;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr189 = FALSE ;
  else {
bool mu__boolexpr190;
  if ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) mu__boolexpr190 = TRUE ;
  else {
  mu__boolexpr190 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_S)) ; 
}
  mu__boolexpr189 = (mu__boolexpr190) ; 
}
  if (!(mu__boolexpr189)) mu__boolexpr188 = FALSE ;
  else {
  mu__boolexpr188 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr188)) mu__boolexpr187 = FALSE ;
  else {
  mu__boolexpr187 = (Sta.mu_Dir.mu_Dirty) ; 
}
	      if (mu__boolexpr187) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 129;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_Proc[Home].mu_ProcCmd = NODE_GetX;
Sta.mu_Dir.mu_Pending = true;
Sta.mu_UniMsg[Home].mu_Cmd = UNI_GetX;
Sta.mu_UniMsg[Home].mu_Proc = Sta.mu_Dir.mu_HeadPtr;
if ( (Sta.mu_Dir.mu_HeadPtr) != (Home) )
{
Sta.mu_FwdCmd = UNI_GetX;
}
if (Home.isundefined())
  Sta.mu_Requester.undefine();
else
  Sta.mu_Requester = Home;
Sta.mu_Collecting = false;
  };

};
/******************** RuleBase28 ********************/
class RuleBase28
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("PI_Remote_GetX, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr191;
bool mu__boolexpr192;
  if (!((src) != (Home))) mu__boolexpr192 = FALSE ;
  else {
  mu__boolexpr192 = ((Sta.mu_Proc[src].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr192)) mu__boolexpr191 = FALSE ;
  else {
  mu__boolexpr191 = ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_I)) ; 
}
    return mu__boolexpr191;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 130;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 134 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr193;
bool mu__boolexpr194;
  if (!((src) != (Home))) mu__boolexpr194 = FALSE ;
  else {
  mu__boolexpr194 = ((Sta.mu_Proc[src].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr194)) mu__boolexpr193 = FALSE ;
  else {
  mu__boolexpr193 = ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_I)) ; 
}
	      if (mu__boolexpr193) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 130;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[src].mu_ProcCmd = NODE_GetX;
Sta.mu_UniMsg[src].mu_Cmd = UNI_GetX;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
  };

};
/******************** RuleBase29 ********************/
class RuleBase29
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("PI_Local_Get_Put");
  }
  bool Condition(unsigned r)
  {
bool mu__boolexpr195;
bool mu__boolexpr196;
bool mu__boolexpr197;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr197 = FALSE ;
  else {
  mu__boolexpr197 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) ; 
}
  if (!(mu__boolexpr197)) mu__boolexpr196 = FALSE ;
  else {
  mu__boolexpr196 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr196)) mu__boolexpr195 = FALSE ;
  else {
  mu__boolexpr195 = (!(Sta.mu_Dir.mu_Dirty)) ; 
}
    return mu__boolexpr195;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 134;
    while (what_rule < 135 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr198;
bool mu__boolexpr199;
bool mu__boolexpr200;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr200 = FALSE ;
  else {
  mu__boolexpr200 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) ; 
}
  if (!(mu__boolexpr200)) mu__boolexpr199 = FALSE ;
  else {
  mu__boolexpr199 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr199)) mu__boolexpr198 = FALSE ;
  else {
  mu__boolexpr198 = (!(Sta.mu_Dir.mu_Dirty)) ; 
}
	      if (mu__boolexpr198) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 134;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_Dir.mu_Local = true;
Sta.mu_Proc[Home].mu_ProcCmd = NODE_None;
if ( Sta.mu_Proc[Home].mu_InvMarked )
{
Sta.mu_Proc[Home].mu_InvMarked = false;
Sta.mu_Proc[Home].mu_CacheState = CACHE_I;
}
else
{
Sta.mu_Proc[Home].mu_CacheState = CACHE_S;
Sta.mu_Proc[Home].mu_CacheData = Sta.mu_MemData;
}
  };

};
/******************** RuleBase30 ********************/
class RuleBase30
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    return tsprintf("PI_Local_Get_Get");
  }
  bool Condition(unsigned r)
  {
bool mu__boolexpr201;
bool mu__boolexpr202;
bool mu__boolexpr203;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr203 = FALSE ;
  else {
  mu__boolexpr203 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) ; 
}
  if (!(mu__boolexpr203)) mu__boolexpr202 = FALSE ;
  else {
  mu__boolexpr202 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr202)) mu__boolexpr201 = FALSE ;
  else {
  mu__boolexpr201 = (Sta.mu_Dir.mu_Dirty) ; 
}
    return mu__boolexpr201;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 135;
    while (what_rule < 136 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr204;
bool mu__boolexpr205;
bool mu__boolexpr206;
  if (!((Sta.mu_Proc[Home].mu_ProcCmd) == (NODE_None))) mu__boolexpr206 = FALSE ;
  else {
  mu__boolexpr206 = ((Sta.mu_Proc[Home].mu_CacheState) == (CACHE_I)) ; 
}
  if (!(mu__boolexpr206)) mu__boolexpr205 = FALSE ;
  else {
  mu__boolexpr205 = (!(Sta.mu_Dir.mu_Pending)) ; 
}
  if (!(mu__boolexpr205)) mu__boolexpr204 = FALSE ;
  else {
  mu__boolexpr204 = (Sta.mu_Dir.mu_Dirty) ; 
}
	      if (mu__boolexpr204) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 135;
    }
  }

  void Code(unsigned r)
  {
Sta.mu_Proc[Home].mu_ProcCmd = NODE_Get;
Sta.mu_Dir.mu_Pending = true;
Sta.mu_UniMsg[Home].mu_Cmd = UNI_Get;
Sta.mu_UniMsg[Home].mu_Proc = Sta.mu_Dir.mu_HeadPtr;
if ( (Sta.mu_Dir.mu_HeadPtr) != (Home) )
{
Sta.mu_FwdCmd = UNI_Get;
}
if (Home.isundefined())
  Sta.mu_Requester.undefine();
else
  Sta.mu_Requester = Home;
Sta.mu_Collecting = false;
  };

};
/******************** RuleBase31 ********************/
class RuleBase31
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("PI_Remote_Get, src:%s", src.Name());
  }
  bool Condition(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
bool mu__boolexpr207;
bool mu__boolexpr208;
  if (!((src) != (Home))) mu__boolexpr208 = FALSE ;
  else {
  mu__boolexpr208 = ((Sta.mu_Proc[src].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr208)) mu__boolexpr207 = FALSE ;
  else {
  mu__boolexpr207 = ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_I)) ; 
}
    return mu__boolexpr207;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 136;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 140 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr209;
bool mu__boolexpr210;
  if (!((src) != (Home))) mu__boolexpr210 = FALSE ;
  else {
  mu__boolexpr210 = ((Sta.mu_Proc[src].mu_ProcCmd) == (NODE_None)) ; 
}
  if (!(mu__boolexpr210)) mu__boolexpr209 = FALSE ;
  else {
  mu__boolexpr209 = ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_I)) ; 
}
	      if (mu__boolexpr209) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 136;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[src].mu_ProcCmd = NODE_Get;
Sta.mu_UniMsg[src].mu_Cmd = UNI_Get;
if (Home.isundefined())
  Sta.mu_UniMsg[src].mu_Proc.undefine();
else
  Sta.mu_UniMsg[src].mu_Proc = Home;
  };

};
/******************** RuleBase32 ********************/
class RuleBase32
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static DATA data;
    data.value((r % 2) + 1);
    r = r / 2;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return tsprintf("Store, data:%s, src:%s", data.Name(), src.Name());
  }
  bool Condition(unsigned r)
  {
    static DATA data;
    data.value((r % 2) + 1);
    r = r / 2;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    return (Sta.mu_Proc[src].mu_CacheState) == (CACHE_E);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 140;
    static DATA data;
    data.value((r % 2) + 1);
    r = r / 2;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
    while (what_rule < 148 )
      {
	if ( ( TRUE  ) ) {
	      if ((Sta.mu_Proc[src].mu_CacheState) == (CACHE_E)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 2;
	}
	else
	  what_rule += 2;
    r = what_rule - 140;
    data.value((r % 2) + 1);
    r = r / 2;
    src.value((r % 4) + 0);
    r = r / 4;
    }
  }

  void Code(unsigned r)
  {
    static DATA data;
    data.value((r % 2) + 1);
    r = r / 2;
    static NODE src;
    src.value((r % 4) + 0);
    r = r / 4;
Sta.mu_Proc[src].mu_CacheData = data;
Sta.mu_CurrData = data;
Sta.mu_LastWrVld = true;
Sta.mu_LastWrPtr = src;
  };

};
class NextStateGenerator
{
  RuleBase0 R0;
  RuleBase1 R1;
  RuleBase2 R2;
  RuleBase3 R3;
  RuleBase4 R4;
  RuleBase5 R5;
  RuleBase6 R6;
  RuleBase7 R7;
  RuleBase8 R8;
  RuleBase9 R9;
  RuleBase10 R10;
  RuleBase11 R11;
  RuleBase12 R12;
  RuleBase13 R13;
  RuleBase14 R14;
  RuleBase15 R15;
  RuleBase16 R16;
  RuleBase17 R17;
  RuleBase18 R18;
  RuleBase19 R19;
  RuleBase20 R20;
  RuleBase21 R21;
  RuleBase22 R22;
  RuleBase23 R23;
  RuleBase24 R24;
  RuleBase25 R25;
  RuleBase26 R26;
  RuleBase27 R27;
  RuleBase28 R28;
  RuleBase29 R29;
  RuleBase30 R30;
  RuleBase31 R31;
  RuleBase32 R32;
public:
void SetNextEnabledRule(unsigned & what_rule)
{
  category = CONDITION;
  if (what_rule<4)
    { R0.NextRule(what_rule);
      if (what_rule<4) return; }
  if (what_rule>=4 && what_rule<5)
    { R1.NextRule(what_rule);
      if (what_rule<5) return; }
  if (what_rule>=5 && what_rule<6)
    { R2.NextRule(what_rule);
      if (what_rule<6) return; }
  if (what_rule>=6 && what_rule<7)
    { R3.NextRule(what_rule);
      if (what_rule<7) return; }
  if (what_rule>=7 && what_rule<11)
    { R4.NextRule(what_rule);
      if (what_rule<11) return; }
  if (what_rule>=11 && what_rule<15)
    { R5.NextRule(what_rule);
      if (what_rule<15) return; }
  if (what_rule>=15 && what_rule<19)
    { R6.NextRule(what_rule);
      if (what_rule<19) return; }
  if (what_rule>=19 && what_rule<20)
    { R7.NextRule(what_rule);
      if (what_rule<20) return; }
  if (what_rule>=20 && what_rule<24)
    { R8.NextRule(what_rule);
      if (what_rule<24) return; }
  if (what_rule>=24 && what_rule<25)
    { R9.NextRule(what_rule);
      if (what_rule<25) return; }
  if (what_rule>=25 && what_rule<41)
    { R10.NextRule(what_rule);
      if (what_rule<41) return; }
  if (what_rule>=41 && what_rule<57)
    { R11.NextRule(what_rule);
      if (what_rule<57) return; }
  if (what_rule>=57 && what_rule<61)
    { R12.NextRule(what_rule);
      if (what_rule<61) return; }
  if (what_rule>=61 && what_rule<65)
    { R13.NextRule(what_rule);
      if (what_rule<65) return; }
  if (what_rule>=65 && what_rule<69)
    { R14.NextRule(what_rule);
      if (what_rule<69) return; }
  if (what_rule>=69 && what_rule<85)
    { R15.NextRule(what_rule);
      if (what_rule<85) return; }
  if (what_rule>=85 && what_rule<101)
    { R16.NextRule(what_rule);
      if (what_rule<101) return; }
  if (what_rule>=101 && what_rule<105)
    { R17.NextRule(what_rule);
      if (what_rule<105) return; }
  if (what_rule>=105 && what_rule<109)
    { R18.NextRule(what_rule);
      if (what_rule<109) return; }
  if (what_rule>=109 && what_rule<113)
    { R19.NextRule(what_rule);
      if (what_rule<113) return; }
  if (what_rule>=113 && what_rule<114)
    { R20.NextRule(what_rule);
      if (what_rule<114) return; }
  if (what_rule>=114 && what_rule<118)
    { R21.NextRule(what_rule);
      if (what_rule<118) return; }
  if (what_rule>=118 && what_rule<119)
    { R22.NextRule(what_rule);
      if (what_rule<119) return; }
  if (what_rule>=119 && what_rule<123)
    { R23.NextRule(what_rule);
      if (what_rule<123) return; }
  if (what_rule>=123 && what_rule<124)
    { R24.NextRule(what_rule);
      if (what_rule<124) return; }
  if (what_rule>=124 && what_rule<128)
    { R25.NextRule(what_rule);
      if (what_rule<128) return; }
  if (what_rule>=128 && what_rule<129)
    { R26.NextRule(what_rule);
      if (what_rule<129) return; }
  if (what_rule>=129 && what_rule<130)
    { R27.NextRule(what_rule);
      if (what_rule<130) return; }
  if (what_rule>=130 && what_rule<134)
    { R28.NextRule(what_rule);
      if (what_rule<134) return; }
  if (what_rule>=134 && what_rule<135)
    { R29.NextRule(what_rule);
      if (what_rule<135) return; }
  if (what_rule>=135 && what_rule<136)
    { R30.NextRule(what_rule);
      if (what_rule<136) return; }
  if (what_rule>=136 && what_rule<140)
    { R31.NextRule(what_rule);
      if (what_rule<140) return; }
  if (what_rule>=140 && what_rule<148)
    { R32.NextRule(what_rule);
      if (what_rule<148) return; }
}
bool Condition(unsigned r)
{
  category = CONDITION;
  if (r<=3) return R0.Condition(r-0);
  if (r>=4 && r<=4) return R1.Condition(r-4);
  if (r>=5 && r<=5) return R2.Condition(r-5);
  if (r>=6 && r<=6) return R3.Condition(r-6);
  if (r>=7 && r<=10) return R4.Condition(r-7);
  if (r>=11 && r<=14) return R5.Condition(r-11);
  if (r>=15 && r<=18) return R6.Condition(r-15);
  if (r>=19 && r<=19) return R7.Condition(r-19);
  if (r>=20 && r<=23) return R8.Condition(r-20);
  if (r>=24 && r<=24) return R9.Condition(r-24);
  if (r>=25 && r<=40) return R10.Condition(r-25);
  if (r>=41 && r<=56) return R11.Condition(r-41);
  if (r>=57 && r<=60) return R12.Condition(r-57);
  if (r>=61 && r<=64) return R13.Condition(r-61);
  if (r>=65 && r<=68) return R14.Condition(r-65);
  if (r>=69 && r<=84) return R15.Condition(r-69);
  if (r>=85 && r<=100) return R16.Condition(r-85);
  if (r>=101 && r<=104) return R17.Condition(r-101);
  if (r>=105 && r<=108) return R18.Condition(r-105);
  if (r>=109 && r<=112) return R19.Condition(r-109);
  if (r>=113 && r<=113) return R20.Condition(r-113);
  if (r>=114 && r<=117) return R21.Condition(r-114);
  if (r>=118 && r<=118) return R22.Condition(r-118);
  if (r>=119 && r<=122) return R23.Condition(r-119);
  if (r>=123 && r<=123) return R24.Condition(r-123);
  if (r>=124 && r<=127) return R25.Condition(r-124);
  if (r>=128 && r<=128) return R26.Condition(r-128);
  if (r>=129 && r<=129) return R27.Condition(r-129);
  if (r>=130 && r<=133) return R28.Condition(r-130);
  if (r>=134 && r<=134) return R29.Condition(r-134);
  if (r>=135 && r<=135) return R30.Condition(r-135);
  if (r>=136 && r<=139) return R31.Condition(r-136);
  if (r>=140 && r<=147) return R32.Condition(r-140);
Error.Notrace("Internal: NextStateGenerator -- checking condition for nonexisting rule.");
return 0;}
void Code(unsigned r)
{
  if (r<=3) { R0.Code(r-0); return; } 
  if (r>=4 && r<=4) { R1.Code(r-4); return; } 
  if (r>=5 && r<=5) { R2.Code(r-5); return; } 
  if (r>=6 && r<=6) { R3.Code(r-6); return; } 
  if (r>=7 && r<=10) { R4.Code(r-7); return; } 
  if (r>=11 && r<=14) { R5.Code(r-11); return; } 
  if (r>=15 && r<=18) { R6.Code(r-15); return; } 
  if (r>=19 && r<=19) { R7.Code(r-19); return; } 
  if (r>=20 && r<=23) { R8.Code(r-20); return; } 
  if (r>=24 && r<=24) { R9.Code(r-24); return; } 
  if (r>=25 && r<=40) { R10.Code(r-25); return; } 
  if (r>=41 && r<=56) { R11.Code(r-41); return; } 
  if (r>=57 && r<=60) { R12.Code(r-57); return; } 
  if (r>=61 && r<=64) { R13.Code(r-61); return; } 
  if (r>=65 && r<=68) { R14.Code(r-65); return; } 
  if (r>=69 && r<=84) { R15.Code(r-69); return; } 
  if (r>=85 && r<=100) { R16.Code(r-85); return; } 
  if (r>=101 && r<=104) { R17.Code(r-101); return; } 
  if (r>=105 && r<=108) { R18.Code(r-105); return; } 
  if (r>=109 && r<=112) { R19.Code(r-109); return; } 
  if (r>=113 && r<=113) { R20.Code(r-113); return; } 
  if (r>=114 && r<=117) { R21.Code(r-114); return; } 
  if (r>=118 && r<=118) { R22.Code(r-118); return; } 
  if (r>=119 && r<=122) { R23.Code(r-119); return; } 
  if (r>=123 && r<=123) { R24.Code(r-123); return; } 
  if (r>=124 && r<=127) { R25.Code(r-124); return; } 
  if (r>=128 && r<=128) { R26.Code(r-128); return; } 
  if (r>=129 && r<=129) { R27.Code(r-129); return; } 
  if (r>=130 && r<=133) { R28.Code(r-130); return; } 
  if (r>=134 && r<=134) { R29.Code(r-134); return; } 
  if (r>=135 && r<=135) { R30.Code(r-135); return; } 
  if (r>=136 && r<=139) { R31.Code(r-136); return; } 
  if (r>=140 && r<=147) { R32.Code(r-140); return; } 
}
int Priority(unsigned short r)
{
  if (r<=3) { return R0.Priority(); } 
  if (r>=4 && r<=4) { return R1.Priority(); } 
  if (r>=5 && r<=5) { return R2.Priority(); } 
  if (r>=6 && r<=6) { return R3.Priority(); } 
  if (r>=7 && r<=10) { return R4.Priority(); } 
  if (r>=11 && r<=14) { return R5.Priority(); } 
  if (r>=15 && r<=18) { return R6.Priority(); } 
  if (r>=19 && r<=19) { return R7.Priority(); } 
  if (r>=20 && r<=23) { return R8.Priority(); } 
  if (r>=24 && r<=24) { return R9.Priority(); } 
  if (r>=25 && r<=40) { return R10.Priority(); } 
  if (r>=41 && r<=56) { return R11.Priority(); } 
  if (r>=57 && r<=60) { return R12.Priority(); } 
  if (r>=61 && r<=64) { return R13.Priority(); } 
  if (r>=65 && r<=68) { return R14.Priority(); } 
  if (r>=69 && r<=84) { return R15.Priority(); } 
  if (r>=85 && r<=100) { return R16.Priority(); } 
  if (r>=101 && r<=104) { return R17.Priority(); } 
  if (r>=105 && r<=108) { return R18.Priority(); } 
  if (r>=109 && r<=112) { return R19.Priority(); } 
  if (r>=113 && r<=113) { return R20.Priority(); } 
  if (r>=114 && r<=117) { return R21.Priority(); } 
  if (r>=118 && r<=118) { return R22.Priority(); } 
  if (r>=119 && r<=122) { return R23.Priority(); } 
  if (r>=123 && r<=123) { return R24.Priority(); } 
  if (r>=124 && r<=127) { return R25.Priority(); } 
  if (r>=128 && r<=128) { return R26.Priority(); } 
  if (r>=129 && r<=129) { return R27.Priority(); } 
  if (r>=130 && r<=133) { return R28.Priority(); } 
  if (r>=134 && r<=134) { return R29.Priority(); } 
  if (r>=135 && r<=135) { return R30.Priority(); } 
  if (r>=136 && r<=139) { return R31.Priority(); } 
  if (r>=140 && r<=147) { return R32.Priority(); } 
return 0;}
char * Name(unsigned r)
{
  if (r<=3) return R0.Name(r-0);
  if (r>=4 && r<=4) return R1.Name(r-4);
  if (r>=5 && r<=5) return R2.Name(r-5);
  if (r>=6 && r<=6) return R3.Name(r-6);
  if (r>=7 && r<=10) return R4.Name(r-7);
  if (r>=11 && r<=14) return R5.Name(r-11);
  if (r>=15 && r<=18) return R6.Name(r-15);
  if (r>=19 && r<=19) return R7.Name(r-19);
  if (r>=20 && r<=23) return R8.Name(r-20);
  if (r>=24 && r<=24) return R9.Name(r-24);
  if (r>=25 && r<=40) return R10.Name(r-25);
  if (r>=41 && r<=56) return R11.Name(r-41);
  if (r>=57 && r<=60) return R12.Name(r-57);
  if (r>=61 && r<=64) return R13.Name(r-61);
  if (r>=65 && r<=68) return R14.Name(r-65);
  if (r>=69 && r<=84) return R15.Name(r-69);
  if (r>=85 && r<=100) return R16.Name(r-85);
  if (r>=101 && r<=104) return R17.Name(r-101);
  if (r>=105 && r<=108) return R18.Name(r-105);
  if (r>=109 && r<=112) return R19.Name(r-109);
  if (r>=113 && r<=113) return R20.Name(r-113);
  if (r>=114 && r<=117) return R21.Name(r-114);
  if (r>=118 && r<=118) return R22.Name(r-118);
  if (r>=119 && r<=122) return R23.Name(r-119);
  if (r>=123 && r<=123) return R24.Name(r-123);
  if (r>=124 && r<=127) return R25.Name(r-124);
  if (r>=128 && r<=128) return R26.Name(r-128);
  if (r>=129 && r<=129) return R27.Name(r-129);
  if (r>=130 && r<=133) return R28.Name(r-130);
  if (r>=134 && r<=134) return R29.Name(r-134);
  if (r>=135 && r<=135) return R30.Name(r-135);
  if (r>=136 && r<=139) return R31.Name(r-136);
  if (r>=140 && r<=147) return R32.Name(r-140);
  return NULL;
}
};
const unsigned numrules = 148;

/********************
  parameter
 ********************/
#define RULES_IN_WORLD 148


/********************
  Startstate records
 ********************/
/******************** StartStateBase0 ********************/
class StartStateBase0
{
public:
  char * Name(unsigned short r)
  {
    static DATA d;
    d.value((r % 2) + 1);
    r = r / 2;
    return tsprintf("Init, d:%s", d.Name());
  }
  void Code(unsigned short r)
  {
    static DATA d;
    d.value((r % 2) + 1);
    r = r / 2;
Home = 0;
Sta.mu_MemData = d;
Sta.mu_Dir.mu_Pending = false;
Sta.mu_Dir.mu_Local = false;
Sta.mu_Dir.mu_Dirty = false;
Sta.mu_Dir.mu_HeadVld = false;
Sta.mu_Dir.mu_HeadPtr = 0;
Sta.mu_Dir.mu_ShrVld = false;
Sta.mu_WbMsg.mu_Cmd = WB_None;
Sta.mu_ShWbMsg.mu_Cmd = SHWB_None;
Sta.mu_NakcMsg.mu_Cmd = NAKC_None;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
Sta.mu_Proc[p].mu_ProcCmd = NODE_None;
Sta.mu_Proc[p].mu_InvMarked = false;
Sta.mu_Proc[p].mu_CacheState = CACHE_I;
Sta.mu_Dir.mu_ShrSet[p] = false;
Sta.mu_Dir.mu_InvSet[p] = false;
Sta.mu_UniMsg[p].mu_Cmd = UNI_None;
Sta.mu_InvMsg[p].mu_Cmd = INV_None;
Sta.mu_RpMsg[p].mu_Cmd = RP_None;
};
};
Sta.mu_CurrData = d;
Sta.mu_PrevData = d;
Sta.mu_LastWrVld = false;
Sta.mu_Collecting = false;
Sta.mu_FwdCmd = UNI_None;
  };

};
class StartStateGenerator
{
  StartStateBase0 S0;
public:
void Code(unsigned short r)
{
  if (r<=1) { S0.Code(r-0); return; }
}
char * Name(unsigned short r)
{
  if (r<=1) return S0.Name(r-0);
  return NULL;
}
};
const rulerec startstates[] = {
{ NULL, NULL, NULL, FALSE},
};
unsigned short StartStateManager::numstartstates = 2;

/********************
  Invariant records
 ********************/
int mu__invariant_211() // Invariant "MemDataProp"
{
bool mu__boolexpr212;
  if (!(!(Sta.mu_Dir.mu_Dirty))) mu__boolexpr212 = TRUE ;
  else {
  mu__boolexpr212 = ((Sta.mu_MemData) == (Sta.mu_CurrData)) ; 
}
return mu__boolexpr212;
};

bool mu__condition_213() // Condition for Rule "MemDataProp"
{
  return mu__invariant_211( );
}

/**** end rule declaration ****/

int mu__invariant_214() // Invariant "CacheDataProp"
{
bool mu__quant215; 
mu__quant215 = TRUE;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__boolexpr216;
bool mu__boolexpr217;
  if (!((Sta.mu_Proc[p].mu_CacheState) == (CACHE_E))) mu__boolexpr217 = TRUE ;
  else {
  mu__boolexpr217 = ((Sta.mu_Proc[p].mu_CacheData) == (Sta.mu_CurrData)) ; 
}
  if (!(mu__boolexpr217)) mu__boolexpr216 = FALSE ;
  else {
bool mu__boolexpr218;
  if (!((Sta.mu_Proc[p].mu_CacheState) == (CACHE_S))) mu__boolexpr218 = TRUE ;
  else {
bool mu__boolexpr219;
bool mu__boolexpr220;
  if (!(Sta.mu_Collecting)) mu__boolexpr220 = TRUE ;
  else {
  mu__boolexpr220 = ((Sta.mu_Proc[p].mu_CacheData) == (Sta.mu_PrevData)) ; 
}
  if (!(mu__boolexpr220)) mu__boolexpr219 = FALSE ;
  else {
bool mu__boolexpr221;
  if (!(!(Sta.mu_Collecting))) mu__boolexpr221 = TRUE ;
  else {
  mu__boolexpr221 = ((Sta.mu_Proc[p].mu_CacheData) == (Sta.mu_CurrData)) ; 
}
  mu__boolexpr219 = (mu__boolexpr221) ; 
}
  mu__boolexpr218 = (mu__boolexpr219) ; 
}
  mu__boolexpr216 = (mu__boolexpr218) ; 
}
if ( !(mu__boolexpr216) )
  { mu__quant215 = FALSE; break; }
};
};
return mu__quant215;
};

bool mu__condition_222() // Condition for Rule "CacheDataProp"
{
  return mu__invariant_214( );
}

/**** end rule declaration ****/

int mu__invariant_223() // Invariant "CacheStateProp"
{
bool mu__quant224; 
mu__quant224 = TRUE;
{
for(int mu_p = 0; mu_p <= 3; mu_p++) {
bool mu__quant225; 
mu__quant225 = TRUE;
{
for(int mu_q = 0; mu_q <= 3; mu_q++) {
bool mu__boolexpr226;
  if (!((p) != (q))) mu__boolexpr226 = TRUE ;
  else {
bool mu__boolexpr227;
  if (!((Sta.mu_Proc[p].mu_CacheState) == (CACHE_E))) mu__boolexpr227 = FALSE ;
  else {
  mu__boolexpr227 = ((Sta.mu_Proc[q].mu_CacheState) == (CACHE_E)) ; 
}
  mu__boolexpr226 = (!(mu__boolexpr227)) ; 
}
if ( !(mu__boolexpr226) )
  { mu__quant225 = FALSE; break; }
};
};
if ( !(mu__quant225) )
  { mu__quant224 = FALSE; break; }
};
};
return mu__quant224;
};

bool mu__condition_228() // Condition for Rule "CacheStateProp"
{
  return mu__invariant_223( );
}

/**** end rule declaration ****/

const rulerec invariants[] = {
{"CacheStateProp", &mu__condition_228, NULL, },
{"CacheDataProp", &mu__condition_222, NULL, },
{"MemDataProp", &mu__condition_213, NULL, },
};
const unsigned short numinvariants = 3;

/********************
  Normal/Canonicalization for scalarset
 ********************/
/*
Home:NoScalarset
Sta:NoScalarset
*/

/********************
Code for symmetry
 ********************/

/********************
 Permutation Set Class
 ********************/
class PermSet
{
public:
  // book keeping
  enum PresentationType {Simple, Explicit};
  PresentationType Presentation;

  void ResetToSimple();
  void ResetToExplicit();
  void SimpleToExplicit();
  void SimpleToOne();
  bool NextPermutation();

  void Print_in_size()
  { int ret=0; for (int i=0; i<count; i++) if (in[i]) ret++; cout << "in_size:" << ret << "\n"; }


  /********************
   Simple and efficient representation
   ********************/
  bool AlreadyOnlyOneRemain;
  bool MoreThanOneRemain();


  /********************
   Explicit representation
  ********************/
  unsigned long size;
  unsigned long count;
  // in will be of product of factorial sizes for fast canonicalize
  // in will be of size 1 for reduced local memory canonicalize
  bool * in;

  // auxiliary for explicit representation

  // in/perm/revperm will be of factorial size for fast canonicalize
  // they will be of size 1 for reduced local memory canonicalize
  // second range will be size of the scalarset
  // procedure for explicit representation
  // General procedure
  PermSet();
  bool In(int i) const { return in[i]; };
  void Add(int i) { for (int j=0; j<i; j++) in[j] = FALSE;};
  void Remove(int i) { in[i] = FALSE; };
};
bool PermSet::MoreThanOneRemain()
{
  int i,j;
  if (AlreadyOnlyOneRemain)
    return FALSE;
  else {
  }
  AlreadyOnlyOneRemain = TRUE;
  return FALSE;
}
PermSet::PermSet()
: Presentation(Simple)
{
  int i,j,k;
  if (  args->sym_alg.mode == argsym_alg::Exhaustive_Fast_Canonicalize) {

  /********************
   declaration of class variables
  ********************/
  in = new bool[1];

    // Set perm and revperm

    // setting up combination of permutations
    // for different scalarset
    int carry;
    size = 1;
    count = 1;
    for (i=0; i<1; i++)
      {
        carry = 1;
        in[i]= TRUE;
    }
  }
  else
  {

  /********************
   declaration of class variables
  ********************/
  in = new bool[1];
  in[0] = TRUE;
  }
}
void PermSet::ResetToSimple()
{
  int i;

  AlreadyOnlyOneRemain = FALSE;
  Presentation = Simple;
}
void PermSet::ResetToExplicit()
{
  for (int i=0; i<1; i++) in[i] = TRUE;
  Presentation = Explicit;
}
void PermSet::SimpleToExplicit()
{
  int i,j,k;
  int start, class_size;

  // Setup range for mapping

  // To be In or not to be

  // setup explicit representation 
  // Set perm and revperm
  for (i=0; i<1; i++)
    {
      in[i] = TRUE;
    }
  Presentation = Explicit;
  if (args->test_parameter1.value==0) Print_in_size();
}
void PermSet::SimpleToOne()
{
  int i,j,k;
  int class_size;
  int start;


  // Setup range for mapping
  Presentation = Explicit;
}
bool PermSet::NextPermutation()
{
  bool nexted = FALSE;
  int start, end; 
  int class_size;
  int temp;
  int j,k;

  // algorithm
  // for each class
  //   if forall in the same class reverse_sorted, 
  //     { sort again; goto next class }
  //   else
  //     {
  //       nexted = TRUE;
  //       for (j from l to r)
  // 	       if (for all j+ are reversed sorted)
  // 	         {
  // 	           swap j, j+1
  // 	           sort all j+ again
  // 	           break;
  // 	         }
  //     }
if (!nexted) return FALSE;
  return TRUE;
}

/********************
 Symmetry Class
 ********************/
class SymmetryClass
{
  PermSet Perm;
  bool BestInitialized;
  state BestPermutedState;

  // utilities
  void SetBestResult(int i, state* temp);
  void ResetBestResult() {BestInitialized = FALSE;};

public:
  // initializer
  SymmetryClass() : Perm(), BestInitialized(FALSE) {};
  ~SymmetryClass() {};

  void Normalize(state* s);

  void Exhaustive_Fast_Canonicalize(state *s);
  void Heuristic_Fast_Canonicalize(state *s);
  void Heuristic_Small_Mem_Canonicalize(state *s);
  void Heuristic_Fast_Normalize(state *s);

  void MultisetSort(state* s);
};


/********************
 Symmetry Class Members
 ********************/
void SymmetryClass::MultisetSort(state* s)
{
        mu_Home.MultisetSort();
        mu_Sta.MultisetSort();
}
void SymmetryClass::Normalize(state* s)
{
  switch (args->sym_alg.mode) {
  case argsym_alg::Exhaustive_Fast_Canonicalize:
    Exhaustive_Fast_Canonicalize(s);
    break;
  case argsym_alg::Heuristic_Fast_Canonicalize:
    Heuristic_Fast_Canonicalize(s);
    break;
  case argsym_alg::Heuristic_Small_Mem_Canonicalize:
    Heuristic_Small_Mem_Canonicalize(s);
    break;
  case argsym_alg::Heuristic_Fast_Normalize:
    Heuristic_Fast_Normalize(s);
    break;
  default:
    Heuristic_Fast_Canonicalize(s);
  }
}

/********************
 Permute and Canonicalize function for different types
 ********************/
void mu_1_NODE::Permute(PermSet& Perm, int i) {};
void mu_1_NODE::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_NODE::Canonicalize(PermSet& Perm) {};
void mu_1_NODE::SimpleLimit(PermSet& Perm) {};
void mu_1_NODE::ArrayLimit(PermSet& Perm) {};
void mu_1_NODE::Limit(PermSet& Perm) {};
void mu_1_NODE::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for subrange type.\n"); };
void mu_1_DATA::Permute(PermSet& Perm, int i) {};
void mu_1_DATA::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_DATA::Canonicalize(PermSet& Perm) {};
void mu_1_DATA::SimpleLimit(PermSet& Perm) {};
void mu_1_DATA::ArrayLimit(PermSet& Perm) {};
void mu_1_DATA::Limit(PermSet& Perm) {};
void mu_1_DATA::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for subrange type.\n"); };
void mu_1_CACHE_STATE::Permute(PermSet& Perm, int i) {};
void mu_1_CACHE_STATE::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_CACHE_STATE::Canonicalize(PermSet& Perm) {};
void mu_1_CACHE_STATE::SimpleLimit(PermSet& Perm) {};
void mu_1_CACHE_STATE::ArrayLimit(PermSet& Perm) {};
void mu_1_CACHE_STATE::Limit(PermSet& Perm) {};
void mu_1_CACHE_STATE::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_NODE_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_NODE_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_NODE_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_NODE_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_NODE_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_NODE_CMD::Limit(PermSet& Perm) {};
void mu_1_NODE_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_NODE_STATE::Permute(PermSet& Perm, int i)
{
};
void mu_1_NODE_STATE::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_NODE_STATE::Canonicalize(PermSet& Perm)
{
};
void mu_1_NODE_STATE::SimpleLimit(PermSet& Perm){}
void mu_1_NODE_STATE::ArrayLimit(PermSet& Perm){}
void mu_1_NODE_STATE::Limit(PermSet& Perm)
{
};
void mu_1_NODE_STATE::MultisetLimit(PermSet& Perm)
{
};
void mu_1__type_0::Permute(PermSet& Perm, int i)
{
  static mu_1__type_0 temp("Permute_mu_1__type_0",-1);
  int j;
  for (j=0; j<4; j++)
    array[j].Permute(Perm, i);
};
void mu_1__type_0::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_0::Canonicalize(PermSet& Perm){};
void mu_1__type_0::SimpleLimit(PermSet& Perm){}
void mu_1__type_0::ArrayLimit(PermSet& Perm) {}
void mu_1__type_0::Limit(PermSet& Perm){}
void mu_1__type_0::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };
void mu_1__type_1::Permute(PermSet& Perm, int i)
{
  static mu_1__type_1 temp("Permute_mu_1__type_1",-1);
  int j;
  for (j=0; j<4; j++)
    array[j].Permute(Perm, i);
};
void mu_1__type_1::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_1::Canonicalize(PermSet& Perm){};
void mu_1__type_1::SimpleLimit(PermSet& Perm){}
void mu_1__type_1::ArrayLimit(PermSet& Perm) {}
void mu_1__type_1::Limit(PermSet& Perm){}
void mu_1__type_1::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };
void mu_1_DIR_STATE::Permute(PermSet& Perm, int i)
{
};
void mu_1_DIR_STATE::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_DIR_STATE::Canonicalize(PermSet& Perm)
{
};
void mu_1_DIR_STATE::SimpleLimit(PermSet& Perm){}
void mu_1_DIR_STATE::ArrayLimit(PermSet& Perm){}
void mu_1_DIR_STATE::Limit(PermSet& Perm)
{
};
void mu_1_DIR_STATE::MultisetLimit(PermSet& Perm)
{
};
void mu_1_UNI_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_UNI_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_UNI_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_UNI_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_UNI_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_UNI_CMD::Limit(PermSet& Perm) {};
void mu_1_UNI_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_UNI_MSG::Permute(PermSet& Perm, int i)
{
};
void mu_1_UNI_MSG::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_UNI_MSG::Canonicalize(PermSet& Perm)
{
};
void mu_1_UNI_MSG::SimpleLimit(PermSet& Perm){}
void mu_1_UNI_MSG::ArrayLimit(PermSet& Perm){}
void mu_1_UNI_MSG::Limit(PermSet& Perm)
{
};
void mu_1_UNI_MSG::MultisetLimit(PermSet& Perm)
{
};
void mu_1_INV_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_INV_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_INV_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_INV_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_INV_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_INV_CMD::Limit(PermSet& Perm) {};
void mu_1_INV_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_INV_MSG::Permute(PermSet& Perm, int i)
{
};
void mu_1_INV_MSG::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_INV_MSG::Canonicalize(PermSet& Perm)
{
};
void mu_1_INV_MSG::SimpleLimit(PermSet& Perm){}
void mu_1_INV_MSG::ArrayLimit(PermSet& Perm){}
void mu_1_INV_MSG::Limit(PermSet& Perm)
{
};
void mu_1_INV_MSG::MultisetLimit(PermSet& Perm)
{
};
void mu_1_RP_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_RP_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_RP_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_RP_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_RP_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_RP_CMD::Limit(PermSet& Perm) {};
void mu_1_RP_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_RP_MSG::Permute(PermSet& Perm, int i)
{
};
void mu_1_RP_MSG::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_RP_MSG::Canonicalize(PermSet& Perm)
{
};
void mu_1_RP_MSG::SimpleLimit(PermSet& Perm){}
void mu_1_RP_MSG::ArrayLimit(PermSet& Perm){}
void mu_1_RP_MSG::Limit(PermSet& Perm)
{
};
void mu_1_RP_MSG::MultisetLimit(PermSet& Perm)
{
};
void mu_1_WB_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_WB_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_WB_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_WB_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_WB_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_WB_CMD::Limit(PermSet& Perm) {};
void mu_1_WB_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_WB_MSG::Permute(PermSet& Perm, int i)
{
};
void mu_1_WB_MSG::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_WB_MSG::Canonicalize(PermSet& Perm)
{
};
void mu_1_WB_MSG::SimpleLimit(PermSet& Perm){}
void mu_1_WB_MSG::ArrayLimit(PermSet& Perm){}
void mu_1_WB_MSG::Limit(PermSet& Perm)
{
};
void mu_1_WB_MSG::MultisetLimit(PermSet& Perm)
{
};
void mu_1_SHWB_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_SHWB_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_SHWB_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_SHWB_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_SHWB_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_SHWB_CMD::Limit(PermSet& Perm) {};
void mu_1_SHWB_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_SHWB_MSG::Permute(PermSet& Perm, int i)
{
};
void mu_1_SHWB_MSG::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_SHWB_MSG::Canonicalize(PermSet& Perm)
{
};
void mu_1_SHWB_MSG::SimpleLimit(PermSet& Perm){}
void mu_1_SHWB_MSG::ArrayLimit(PermSet& Perm){}
void mu_1_SHWB_MSG::Limit(PermSet& Perm)
{
};
void mu_1_SHWB_MSG::MultisetLimit(PermSet& Perm)
{
};
void mu_1_NAKC_CMD::Permute(PermSet& Perm, int i) {};
void mu_1_NAKC_CMD::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_NAKC_CMD::Canonicalize(PermSet& Perm) {};
void mu_1_NAKC_CMD::SimpleLimit(PermSet& Perm) {};
void mu_1_NAKC_CMD::ArrayLimit(PermSet& Perm) {};
void mu_1_NAKC_CMD::Limit(PermSet& Perm) {};
void mu_1_NAKC_CMD::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_NAKC_MSG::Permute(PermSet& Perm, int i)
{
};
void mu_1_NAKC_MSG::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_NAKC_MSG::Canonicalize(PermSet& Perm)
{
};
void mu_1_NAKC_MSG::SimpleLimit(PermSet& Perm){}
void mu_1_NAKC_MSG::ArrayLimit(PermSet& Perm){}
void mu_1_NAKC_MSG::Limit(PermSet& Perm)
{
};
void mu_1_NAKC_MSG::MultisetLimit(PermSet& Perm)
{
};
void mu_1__type_2::Permute(PermSet& Perm, int i)
{
  static mu_1__type_2 temp("Permute_mu_1__type_2",-1);
  int j;
  for (j=0; j<4; j++)
    array[j].Permute(Perm, i);
};
void mu_1__type_2::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_2::Canonicalize(PermSet& Perm){};
void mu_1__type_2::SimpleLimit(PermSet& Perm){}
void mu_1__type_2::ArrayLimit(PermSet& Perm) {}
void mu_1__type_2::Limit(PermSet& Perm){}
void mu_1__type_2::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };
void mu_1__type_3::Permute(PermSet& Perm, int i)
{
  static mu_1__type_3 temp("Permute_mu_1__type_3",-1);
  int j;
  for (j=0; j<4; j++)
    array[j].Permute(Perm, i);
};
void mu_1__type_3::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_3::Canonicalize(PermSet& Perm){};
void mu_1__type_3::SimpleLimit(PermSet& Perm){}
void mu_1__type_3::ArrayLimit(PermSet& Perm) {}
void mu_1__type_3::Limit(PermSet& Perm){}
void mu_1__type_3::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };
void mu_1__type_4::Permute(PermSet& Perm, int i)
{
  static mu_1__type_4 temp("Permute_mu_1__type_4",-1);
  int j;
  for (j=0; j<4; j++)
    array[j].Permute(Perm, i);
};
void mu_1__type_4::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_4::Canonicalize(PermSet& Perm){};
void mu_1__type_4::SimpleLimit(PermSet& Perm){}
void mu_1__type_4::ArrayLimit(PermSet& Perm) {}
void mu_1__type_4::Limit(PermSet& Perm){}
void mu_1__type_4::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };
void mu_1__type_5::Permute(PermSet& Perm, int i)
{
  static mu_1__type_5 temp("Permute_mu_1__type_5",-1);
  int j;
  for (j=0; j<4; j++)
    array[j].Permute(Perm, i);
};
void mu_1__type_5::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_5::Canonicalize(PermSet& Perm){};
void mu_1__type_5::SimpleLimit(PermSet& Perm){}
void mu_1__type_5::ArrayLimit(PermSet& Perm) {}
void mu_1__type_5::Limit(PermSet& Perm){}
void mu_1__type_5::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };
void mu_1_STATE::Permute(PermSet& Perm, int i)
{
};
void mu_1_STATE::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Record with no scalarset variable\n"); };
void mu_1_STATE::Canonicalize(PermSet& Perm)
{
};
void mu_1_STATE::SimpleLimit(PermSet& Perm){}
void mu_1_STATE::ArrayLimit(PermSet& Perm){}
void mu_1_STATE::Limit(PermSet& Perm)
{
};
void mu_1_STATE::MultisetLimit(PermSet& Perm)
{
};

/********************
 Auxiliary function for error trace printing
 ********************/
bool match(state* ns, StatePtr p)
{
  int i;
  static PermSet Perm;
  static state temp;
  StateCopy(&temp, ns);
  if (args->symmetry_reduction.value)
    {
      if (  args->sym_alg.mode == argsym_alg::Exhaustive_Fast_Canonicalize) {
        Perm.ResetToExplicit();
        for (i=0; i<Perm.count; i++)
          if (Perm.In(i))
            {
              if (ns != workingstate)
                  StateCopy(workingstate, ns);
              
              mu_Home.Permute(Perm,i);
              if (args->multiset_reduction.value)
                mu_Home.MultisetSort();
              mu_Sta.Permute(Perm,i);
              if (args->multiset_reduction.value)
                mu_Sta.MultisetSort();
            if (p.compare(workingstate)) {
              StateCopy(workingstate,&temp); return TRUE; }
          }
        StateCopy(workingstate,&temp);
        return FALSE;
      }
      else {
        Perm.ResetToSimple();
        Perm.SimpleToOne();
        if (ns != workingstate)
          StateCopy(workingstate, ns);

          mu_Home.Permute(Perm,0);
          if (args->multiset_reduction.value)
            mu_Home.MultisetSort();
          mu_Sta.Permute(Perm,0);
          if (args->multiset_reduction.value)
            mu_Sta.MultisetSort();
        if (p.compare(workingstate)) {
          StateCopy(workingstate,&temp); return TRUE; }

        while (Perm.NextPermutation())
          {
            if (ns != workingstate)
              StateCopy(workingstate, ns);
              
              mu_Home.Permute(Perm,0);
              if (args->multiset_reduction.value)
                mu_Home.MultisetSort();
              mu_Sta.Permute(Perm,0);
              if (args->multiset_reduction.value)
                mu_Sta.MultisetSort();
            if (p.compare(workingstate)) {
              StateCopy(workingstate,&temp); return TRUE; }
          }
        StateCopy(workingstate,&temp);
        return FALSE;
      }
    }
  if (!args->symmetry_reduction.value
      && args->multiset_reduction.value)
    {
      if (ns != workingstate)
          StateCopy(workingstate, ns);
      mu_Home.MultisetSort();
      mu_Sta.MultisetSort();
      if (p.compare(workingstate)) {
        StateCopy(workingstate,&temp); return TRUE; }
      StateCopy(workingstate,&temp);
      return FALSE;
    }
  return (p.compare(ns));
}

/********************
 Canonicalization by fast exhaustive generation of
 all permutations
 ********************/
void SymmetryClass::Exhaustive_Fast_Canonicalize(state* s)
{
  int i;
  static state temp;
  Perm.ResetToExplicit();

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_Home.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_Home.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_Sta.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_Sta.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

};

/********************
 Canonicalization by fast simple variable canonicalization,
 fast simple scalarset array canonicalization,
 fast restriction on permutation set with simple scalarset array of scalarset,
 and fast exhaustive generation of
 all permutations for other variables
 ********************/
void SymmetryClass::Heuristic_Fast_Canonicalize(state* s)
{
  int i;
  static state temp;

  Perm.ResetToSimple();

};

/********************
 Canonicalization by fast simple variable canonicalization,
 fast simple scalarset array canonicalization,
 fast restriction on permutation set with simple scalarset array of scalarset,
 and fast exhaustive generation of
 all permutations for other variables
 and use less local memory
 ********************/
void SymmetryClass::Heuristic_Small_Mem_Canonicalize(state* s)
{
  unsigned long cycle;
  static state temp;

  Perm.ResetToSimple();

};

/********************
 Normalization by fast simple variable canonicalization,
 fast simple scalarset array canonicalization,
 fast restriction on permutation set with simple scalarset array of scalarset,
 and for all other variables, pick any remaining permutation
 ********************/
void SymmetryClass::Heuristic_Fast_Normalize(state* s)
{
  int i;
  static state temp;

  Perm.ResetToSimple();

};

/********************
  Include
 ********************/
#include "mu_epilog.hpp"
