
const

  NODE_NUM : 3;
  DATA_NUM : 2;
                                                            
type

  NODE : scalarset(3);
  DATA : scalarset(2);
  
  ABS_NODE : union {NODE, enum{Other}};
  
  CACHE_STATE : enum{CACHE_I,CACHE_S,CACHE_E};
  
  NODE_CMD : enum{NODE_None,NODE_Get,NODE_GetX};
  
  NODE_STATE : record
    ProcCmd : NODE_CMD;
    InvMarked : boolean;
    CacheState : CACHE_STATE;
    CacheData : DATA;
  end;
  new_type_0 : array [ NODE ] of boolean;
  new_type_1 : array [ NODE ] of boolean;
  
  DIR_STATE : record
    Pending : boolean;
    Local : boolean;
    Dirty : boolean;
    HeadVld : boolean;
    HeadPtr : ABS_NODE;
    ShrVld : boolean;
    ShrSet : new_type_0;
    InvSet : new_type_1;
  end;
  
  UNI_CMD : enum{UNI_None,UNI_Get,UNI_GetX,UNI_Put,UNI_PutX,UNI_Nak};
  
  UNI_MSG : record
    Cmd : UNI_CMD;
    Proc : ABS_NODE;
    Data : DATA;
  end;
  
  INV_CMD : enum{INV_None,INV_Inv,INV_InvAck};
  
  INV_MSG : record
    Cmd : INV_CMD;
  end;
  
  RP_CMD : enum{RP_None,RP_Replace};
  
  RP_MSG : record
    Cmd : RP_CMD;
  end;
  
  WB_CMD : enum{WB_None,WB_Wb};
  
  WB_MSG : record
    Cmd : WB_CMD;
    Proc : ABS_NODE;
    Data : DATA;
  end;
  
  SHWB_CMD : enum{SHWB_None,SHWB_ShWb,SHWB_FAck};
  
  SHWB_MSG : record
    Cmd : SHWB_CMD;
    Proc : ABS_NODE;
    Data : DATA;
  end;
  
  NAKC_CMD : enum{NAKC_None,NAKC_Nakc};
  
  NAKC_MSG : record
    Cmd : NAKC_CMD;
  end;
  new_type_2 : array [ NODE ] of NODE_STATE;
  new_type_3 : array [ NODE ] of UNI_MSG;
  new_type_4 : array [ NODE ] of INV_MSG;
  new_type_5 : array [ NODE ] of RP_MSG;
  
  STATE : record
    Proc : new_type_2;
    Dir : DIR_STATE;
    MemData : DATA;
    UniMsg : new_type_3;
    InvMsg : new_type_4;
    RpMsg : new_type_5;
    WbMsg : WB_MSG;
    ShWbMsg : SHWB_MSG;
    NakcMsg : NAKC_MSG;
    CurrData : DATA;
    PrevData : DATA;
    LastWrVld : boolean;
    LastWrPtr : ABS_NODE;
    PendReqSrc : ABS_NODE;
    PendReqCmd : UNI_CMD;
    Collecting : boolean;
    FwdCmd : UNI_CMD;
    FwdSrc : ABS_NODE;
    LastInvAck : ABS_NODE;
    LastOtherInvAck : ABS_NODE;
  end;

var

  Home : NODE;
  Sta : STATE;

ruleset  src : NODE do
rule "NI_Replace1"
  Sta.RpMsg[src].Cmd = RP_Replace &
  Sta.Dir.ShrVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.RpMsg[src].Cmd := RP_None;
  NxtSta.Dir.ShrSet[src] := false;
  NxtSta.Dir.InvSet[src] := false;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Replace2"
  Sta.RpMsg[src].Cmd = RP_Replace &
  !Sta.Dir.ShrVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.RpMsg[src].Cmd := RP_None;
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_ShWb3"
  Sta.ShWbMsg.Cmd = SHWB_ShWb
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.ShWbMsg.Cmd := SHWB_None;
  undefine NxtSta.ShWbMsg.Proc;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.ShrVld := true;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := (p = Sta.ShWbMsg.Proc |
    Sta.Dir.ShrSet[p]);
    NxtSta.Dir.InvSet[p] := (p = Sta.ShWbMsg.Proc |
    Sta.Dir.ShrSet[p]);
  end;
  NxtSta.MemData := Sta.ShWbMsg.Data;
  Sta := NxtSta;
endrule;

rule "NI_FAck4"
  Sta.ShWbMsg.Cmd = SHWB_FAck &
  Sta.Dir.Dirty
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.ShWbMsg.Cmd := SHWB_None;
  undefine NxtSta.ShWbMsg.Proc;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.HeadPtr := Sta.ShWbMsg.Proc;
  Sta := NxtSta;
endrule;

rule "NI_FAck5"
  Sta.ShWbMsg.Cmd = SHWB_FAck &
  !Sta.Dir.Dirty
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.ShWbMsg.Cmd := SHWB_None;
  undefine NxtSta.ShWbMsg.Proc;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.Dir.Pending := false;
  Sta := NxtSta;
endrule;

rule "NI_Wb6"
  Sta.WbMsg.Cmd = WB_Wb
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.WbMsg.Cmd := WB_None;
  undefine NxtSta.WbMsg.Proc;
  undefine NxtSta.WbMsg.Data;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.MemData := Sta.WbMsg.Data;
  Sta := NxtSta;
endrule;

ruleset  src : NODE do
rule "NI_InvAck_37"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true &
  Sta.Dir.InvSet[src] &
  Sta.Dir.Dirty = true &
  Sta.Dir.InvSet[Home] = false &
  forall p : NODE do
    Sta.Dir.InvSet[p] = false
  end
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.Dir.Pending := false;
  NxtSta.Collecting := false;
  NxtSta.LastInvAck := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_InvAck_28"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true &
  Sta.Dir.InvSet[src] &
  Sta.Dir.Local = false &
  Sta.Dir.InvSet[Home] = false &
  forall p : NODE do
    Sta.Dir.InvSet[p] = false
  end
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.Dir.Pending := false;
  NxtSta.Collecting := false;
  NxtSta.LastInvAck := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_InvAck_19"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true &
  Sta.Dir.InvSet[src] &
  Sta.Dir.Local = true &
  Sta.Dir.Dirty = false &
  Sta.Dir.InvSet[Home] = false &
  forall p : NODE do
    p = src |
    Sta.Dir.InvSet[p] = false
  end
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Local := false;
  NxtSta.Collecting := false;
  NxtSta.LastInvAck := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE; src : NODE do
rule "NI_InvAck_exists10"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true &
  Sta.Dir.InvSet[src] = true &
  dst != src &
  Sta.Dir.InvSet[dst]
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.LastInvAck := src;
  NxtSta.LastOtherInvAck := dst;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_InvAck_exists_Home11"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true &
  Sta.Dir.InvSet[src] &
  Sta.Dir.InvSet[Home] = true
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.LastInvAck := src;
  NxtSta.LastOtherInvAck := Home;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE do
rule "NI_Inv12"
  dst != Home &
  Sta.InvMsg[dst].Cmd = INV_Inv &
  Sta.Proc[dst].ProcCmd = NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[dst].Cmd := INV_InvAck;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.Proc[dst].InvMarked := true;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE do
rule "NI_Inv13"
  dst != Home &
  Sta.InvMsg[dst].Cmd = INV_Inv &
  Sta.Proc[dst].ProcCmd != NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.InvMsg[dst].Cmd := INV_InvAck;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE do
rule "NI_Remote_PutX14"
  dst != Home &
  Sta.UniMsg[dst].Cmd = UNI_PutX &
  Sta.Proc[dst].ProcCmd = NODE_GetX
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  NxtSta.Proc[dst].InvMarked := false;
  NxtSta.Proc[dst].CacheState := CACHE_E;
  NxtSta.Proc[dst].CacheData := Sta.UniMsg[dst].Data;
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Local_PutXAcksDone15"
  Sta.UniMsg[Home].Cmd = UNI_PutX
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[Home].Cmd := UNI_None;
  undefine NxtSta.UniMsg[Home].Proc;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Local := true;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_E;
  NxtSta.Proc[Home].CacheData := Sta.UniMsg[Home].Data;
  Sta := NxtSta;
endrule;

ruleset  dst : NODE do
rule "NI_Remote_Put16"
  dst != Home &
  Sta.UniMsg[dst].Cmd = UNI_Put &
  Sta.Proc[dst].InvMarked
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  NxtSta.Proc[dst].InvMarked := false;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE do
rule "NI_Remote_Put17"
  dst != Home &
  Sta.UniMsg[dst].Cmd = UNI_Put &
  !Sta.Proc[dst].InvMarked
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  NxtSta.Proc[dst].CacheState := CACHE_S;
  NxtSta.Proc[dst].CacheData := Sta.UniMsg[dst].Data;
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Local_Put18"
  Sta.UniMsg[Home].Cmd = UNI_Put &
  Sta.Proc[Home].InvMarked
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[Home].Cmd := UNI_None;
  undefine NxtSta.UniMsg[Home].Proc;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.Local := true;
  NxtSta.MemData := Sta.UniMsg[Home].Data;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;

rule "NI_Local_Put19"
  Sta.UniMsg[Home].Cmd = UNI_Put &
  !Sta.Proc[Home].InvMarked
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[Home].Cmd := UNI_None;
  undefine NxtSta.UniMsg[Home].Proc;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.Local := true;
  NxtSta.MemData := Sta.UniMsg[Home].Data;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].CacheState := CACHE_S;
  NxtSta.Proc[Home].CacheData := Sta.UniMsg[Home].Data;
  Sta := NxtSta;
endrule;

ruleset  dst : NODE; src : NODE do
rule "NI_Remote_GetX_PutX20"
  src != dst &
  dst != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState = CACHE_E &
  src != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := dst;
  NxtSta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  NxtSta.ShWbMsg.Cmd := SHWB_FAck;
  NxtSta.ShWbMsg.Proc := src;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.FwdCmd := UNI_None;
  NxtSta.FwdSrc := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE; src : NODE do
rule "NI_Remote_GetX_PutX21"
  src != dst &
  dst != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState = CACHE_E &
  src = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := dst;
  NxtSta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  NxtSta.FwdCmd := UNI_None;
  NxtSta.FwdSrc := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE; src : NODE do
rule "NI_Remote_GetX_Nak22"
  src != dst &
  dst != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState != CACHE_E
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := dst;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.NakcMsg.Cmd := NAKC_Nakc;
  NxtSta.FwdCmd := UNI_None;
  NxtSta.FwdSrc := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX23"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  Sta.Dir.Dirty
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX24"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  Sta.Dir.Dirty
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX25"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX26"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadPtr = src &
  forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX27"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX28"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadPtr = src &
  forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX29"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX30"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadPtr = src &
  forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX31"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX32"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadPtr = src &
  forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX33"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld &
  !Sta.Dir.Local
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX34"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadPtr = src &
  forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  !Sta.Dir.Local
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX35"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld &
  !Sta.Dir.Local
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX36"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadPtr = src &
  forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  !Sta.Dir.Local
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX37"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX38"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX39"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX40"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX41"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX42"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX43"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX44"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd = NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Proc[Home].InvMarked := true;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX45"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX46"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX47"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX48"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX49"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX50"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX51"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX52"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  Sta.Dir.Local &
  Sta.Proc[Home].ProcCmd != NODE_Get &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX53"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX54"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX55"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX56"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr != src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX57"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX58"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX59"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  Sta.Dir.HeadPtr != src &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_PutX60"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = true &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld &
  !forall p : NODE do
    p != src ->
    !Sta.Dir.ShrSet[p]
  end &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if (((p != Home &
    p != src) &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  for p : NODE do
    if ((p != src &
    Sta.Dir.ShrSet[p])) then
      NxtSta.LastOtherInvAck := p;
    end;
  end;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_GetX61"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.Local = false &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.HeadPtr != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[src].Cmd := UNI_GetX;
  NxtSta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.FwdCmd := UNI_GetX;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_GetX62"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.Local = false &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.HeadPtr = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[src].Cmd := UNI_GetX;
  NxtSta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_Nak63"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Pending
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_Nak64"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Dirty &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState != CACHE_E
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_GetX_Nak65"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = Home &
  Sta.Dir.Dirty &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE; src : NODE do
rule "NI_Remote_Get_Put66"
  src != dst &
  dst != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState = CACHE_E &
  src != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[dst].CacheState := CACHE_S;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := dst;
  NxtSta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  NxtSta.ShWbMsg.Cmd := SHWB_ShWb;
  NxtSta.ShWbMsg.Proc := src;
  NxtSta.ShWbMsg.Data := Sta.Proc[dst].CacheData;
  NxtSta.FwdCmd := UNI_None;
  NxtSta.FwdSrc := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE; src : NODE do
rule "NI_Remote_Get_Put67"
  src != dst &
  dst != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState = CACHE_E &
  src = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[dst].CacheState := CACHE_S;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := dst;
  NxtSta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  NxtSta.FwdCmd := UNI_None;
  NxtSta.FwdSrc := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  dst : NODE; src : NODE do
rule "NI_Remote_Get_Nak68"
  src != dst &
  dst != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState != CACHE_E
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := dst;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.NakcMsg.Cmd := NAKC_Nakc;
  NxtSta.FwdCmd := UNI_None;
  NxtSta.FwdSrc := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Put69"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  !Sta.Dir.Dirty &
  Sta.Dir.Dirty
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.MemData := Sta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_S;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Put70"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  Sta.Dir.Dirty
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.MemData := Sta.Proc[Home].CacheData;
  NxtSta.Proc[Home].CacheState := CACHE_S;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Put71"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.ShrVld := true;
  NxtSta.Dir.ShrSet[src] := true;
  for p : NODE do
    NxtSta.Dir.InvSet[p] := (p = src |
    Sta.Dir.ShrSet[p]);
  end;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Put72"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.ShrVld := true;
  NxtSta.Dir.ShrSet[src] := true;
  for p : NODE do
    NxtSta.Dir.InvSet[p] := (p = src |
    Sta.Dir.ShrSet[p]);
  end;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Put73"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  !Sta.Dir.Dirty &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Put74"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Dirty &
  !Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Proc := Home;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Get75"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.Local = false &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.HeadPtr != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[src].Cmd := UNI_Get;
  NxtSta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.FwdCmd := UNI_Get;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_Get;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Get76"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.Local = false &
  Sta.Dir.HeadPtr != src &
  Sta.Dir.HeadPtr = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[src].Cmd := UNI_Get;
  NxtSta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.PendReqSrc := src;
  NxtSta.PendReqCmd := UNI_Get;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Nak77"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Nak78"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Dirty &
  Sta.Dir.Local &
  Sta.Proc[Home].CacheState != CACHE_E
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  src : NODE do
rule "NI_Local_Get_Nak79"
  src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = Home &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Dirty &
  !Sta.Dir.Local &
  Sta.Dir.HeadPtr = src
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Nak_Clear80"
  Sta.NakcMsg.Cmd = NAKC_Nakc
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.NakcMsg.Cmd := NAKC_None;
  NxtSta.Dir.Pending := false;
  Sta := NxtSta;
endrule;

ruleset  dst : NODE do
rule "NI_Nak81"
  Sta.UniMsg[dst].Cmd = UNI_Nak
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  NxtSta.Proc[dst].InvMarked := false;
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_Replace82"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_S
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := false;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;

ruleset  src : NODE do
rule "PI_Remote_Replace83"
  src != Home &
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_S
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[src].CacheState := CACHE_I;
  undefine NxtSta.Proc[src].CacheData;
  NxtSta.RpMsg[src].Cmd := RP_Replace;
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_PutX84"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_E &
  Sta.Dir.Pending
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Dir.Dirty := false;
  NxtSta.MemData := Sta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;

rule "PI_Local_PutX85"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_E &
  !Sta.Dir.Pending
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := false;
  NxtSta.MemData := Sta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;

ruleset  dst : NODE do
rule "PI_Remote_PutX86"
  dst != Home &
  Sta.Proc[dst].ProcCmd = NODE_None &
  Sta.Proc[dst].CacheState = CACHE_E
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.WbMsg.Cmd := WB_Wb;
  NxtSta.WbMsg.Proc := dst;
  NxtSta.WbMsg.Data := Sta.Proc[dst].CacheData;
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_GetX_PutX87"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = false &
  Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := true;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ((p != Home &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_E;
  NxtSta.Proc[Home].CacheData := Sta.MemData;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_PutX88"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_S &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = false &
  Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := true;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ((p != Home &
    ((Sta.Dir.ShrVld &
    Sta.Dir.ShrSet[p]) |
    (Sta.Dir.HeadVld &
    Sta.Dir.HeadPtr = p)))) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Collecting := true;
  NxtSta.PrevData := Sta.CurrData;
  NxtSta.LastOtherInvAck := Sta.Dir.HeadPtr;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_E;
  NxtSta.Proc[Home].CacheData := Sta.MemData;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_PutX89"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = false &
  !Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := true;
  NxtSta.Dir.Dirty := true;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_E;
  NxtSta.Proc[Home].CacheData := Sta.MemData;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_PutX90"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_S &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = false &
  !Sta.Dir.HeadVld
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := true;
  NxtSta.Dir.Dirty := true;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_E;
  NxtSta.Proc[Home].CacheData := Sta.MemData;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_GetX91"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.HeadPtr != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].ProcCmd := NODE_GetX;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[Home].Cmd := UNI_GetX;
  NxtSta.UniMsg[Home].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.FwdCmd := UNI_GetX;
  NxtSta.PendReqSrc := Home;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_GetX92"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_S &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.HeadPtr != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].ProcCmd := NODE_GetX;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[Home].Cmd := UNI_GetX;
  NxtSta.UniMsg[Home].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.FwdCmd := UNI_GetX;
  NxtSta.PendReqSrc := Home;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_GetX93"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.HeadPtr = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].ProcCmd := NODE_GetX;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[Home].Cmd := UNI_GetX;
  NxtSta.UniMsg[Home].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.PendReqSrc := Home;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_GetX94"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_S &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.HeadPtr = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].ProcCmd := NODE_GetX;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[Home].Cmd := UNI_GetX;
  NxtSta.UniMsg[Home].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.PendReqSrc := Home;
  NxtSta.PendReqCmd := UNI_GetX;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;

ruleset  src : NODE do
rule "PI_Remote_GetX95"
  src != Home &
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_I
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[src].ProcCmd := NODE_GetX;
  NxtSta.UniMsg[src].Cmd := UNI_GetX;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_Get_Put96"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = false &
  Sta.Proc[Home].InvMarked
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := true;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].InvMarked := false;
  NxtSta.Proc[Home].CacheState := CACHE_I;
  undefine NxtSta.Proc[Home].CacheData;
  Sta := NxtSta;
endrule;

rule "PI_Local_Get_Put97"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = false &
  !Sta.Proc[Home].InvMarked
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Dir.Local := true;
  NxtSta.Proc[Home].ProcCmd := NODE_None;
  NxtSta.Proc[Home].CacheState := CACHE_S;
  NxtSta.Proc[Home].CacheData := Sta.MemData;
  Sta := NxtSta;
endrule;

rule "PI_Local_Get_Get98"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.HeadPtr != Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].ProcCmd := NODE_Get;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[Home].Cmd := UNI_Get;
  NxtSta.UniMsg[Home].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.FwdCmd := UNI_Get;
  NxtSta.PendReqSrc := Home;
  NxtSta.PendReqCmd := UNI_Get;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;

rule "PI_Local_Get_Get99"
  Sta.Proc[Home].ProcCmd = NODE_None &
  Sta.Proc[Home].CacheState = CACHE_I &
  Sta.Dir.Pending = false &
  Sta.Dir.Dirty = true &
  Sta.Dir.HeadPtr = Home
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[Home].ProcCmd := NODE_Get;
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[Home].Cmd := UNI_Get;
  NxtSta.UniMsg[Home].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[Home].Data;
  NxtSta.PendReqSrc := Home;
  NxtSta.PendReqCmd := UNI_Get;
  NxtSta.Collecting := false;
  Sta := NxtSta;
endrule;

ruleset  src : NODE do
rule "PI_Remote_Get100"
  src != Home &
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_I
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[src].ProcCmd := NODE_Get;
  NxtSta.UniMsg[src].Cmd := UNI_Get;
  NxtSta.UniMsg[src].Proc := Home;
  undefine NxtSta.UniMsg[src].Data;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  data : DATA; src : NODE do
rule "Store101"
  Sta.Proc[src].CacheState = CACHE_E
==>
Var 
  NxtSta : STATE;
Begin
  NxtSta := Sta;
  NxtSta.Proc[src].CacheData := data;
  NxtSta.CurrData := data;
  NxtSta.LastWrVld := true;
  NxtSta.LastWrPtr := src;
  Sta := NxtSta;
endrule;
endruleset;

ruleset  h : NODE; d : DATA do
startstate
  Home := h;
  undefine Sta;
  Sta.MemData := d;
  Sta.Dir.Pending := false;
  Sta.Dir.Local := false;
  Sta.Dir.Dirty := false;
  Sta.Dir.HeadVld := false;
  Sta.Dir.ShrVld := false;
  Sta.WbMsg.Cmd := WB_None;
  Sta.ShWbMsg.Cmd := SHWB_None;
  Sta.NakcMsg.Cmd := NAKC_None;
  for p : NODE do
    Sta.Proc[p].ProcCmd := NODE_None;
    Sta.Proc[p].InvMarked := false;
    Sta.Proc[p].CacheState := CACHE_I;
    Sta.Dir.ShrSet[p] := false;
    Sta.Dir.InvSet[p] := false;
    Sta.UniMsg[p].Cmd := UNI_None;
    Sta.InvMsg[p].Cmd := INV_None;
    Sta.RpMsg[p].Cmd := RP_None;
  end;
  Sta.CurrData := d;
  Sta.PrevData := d;
  Sta.LastWrVld := false;
  Sta.Collecting := false;
  Sta.FwdCmd := UNI_None;
endstartstate;
endruleset;
invariant "CacheStateProp"
  forall p : NODE do
    forall q : NODE do
      (p != q ->
      !(Sta.Proc[p].CacheState = CACHE_E &
      Sta.Proc[q].CacheState = CACHE_E))
    end
  end;

invariant "CacheDataProp"
  forall p : NODE do
    ((Sta.Proc[p].CacheState = CACHE_E ->
    Sta.Proc[p].CacheData = Sta.CurrData) &
    (Sta.Proc[p].CacheState = CACHE_S ->
    ((Sta.Collecting ->
    Sta.Proc[p].CacheData = Sta.PrevData) &
    (!Sta.Collecting ->
    Sta.Proc[p].CacheData = Sta.CurrData))))
  end;

invariant "MemDataProp"
  (!Sta.Dir.Dirty ->
  Sta.MemData = Sta.CurrData);

