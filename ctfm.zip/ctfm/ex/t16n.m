
const

  clientNUMS : 5;
        
type

  
  state : enum{I,T,C,E};
  client : 1..5;
  new_type_0 : array [ client ] of state;

var

  n : new_type_0;
  x : boolean;

ruleset  i : client do
rule "Idle1"
  n[i] = E
==>
Begin
  n[i] := I;
  x := true;
endrule;
endruleset;

ruleset  i : client do
rule "Exit2"
  n[i] = C
==>
Begin
  n[i] := E;
endrule;
endruleset;

ruleset  i : client do
rule "Crit3"
  n[i] = T &
  x = true
==>
Begin
  n[i] := C;
  x := false;
endrule;
endruleset;

ruleset  i : client do
rule "Try4"
  n[i] = I
==>
Begin
  n[i] := T;
endrule;
endruleset;

startstate
  for i : client do
    n[i] := I;
  end;
  x := true;
endstartstate;
ruleset  j : client; i : client do
invariant "coherence"
  (i != j ->
  (n[i] = C ->
  n[j] != C))
endruleset;
