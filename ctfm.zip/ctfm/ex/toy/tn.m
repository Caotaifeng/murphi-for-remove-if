Const
clientNUMS : 5;
Type
 state : enum{I,T,C,E,A,B,Q,W,R,AA,AAA};
client : 1..5;
new_type_0 : array [ client ] of state;
Var 
n : new_type_0;
x : boolean;
a : client;
Ruleset  ctf : client Do
Rule "Try1"
n[ctf] != I &
n[ctf] = T
==>
Var 
b : boolean;
Begin
undefine b;
n[ctf] := E;
n[ctf] := AA;
endrule;
endruleset;

Ruleset  ctf : client Do
Rule "Try2"
n[ctf] = A &
n[ctf] = T
==>
Var 
b : boolean;
Begin
undefine b;
n[ctf] := E;
n[ctf] := AA;
endrule;
endruleset;

Ruleset  ctf : client Do
Rule "Try3"
n[ctf] != I &
n[ctf] != T
==>
Var 
b : boolean;
Begin
undefine b;
n[ctf] := AA;
endrule;
endruleset;

Ruleset  ctf : client Do
Rule "Try4"
n[ctf] = A &
n[ctf] != T
==>
Var 
b : boolean;
Begin
undefine b;
n[ctf] := AA;
endrule;
endruleset;

Startstate
Begin
x := true;
endstartstate;
Ruleset  jj : client; ii : client Do
Invariant "coherence"
(ii != jj ->
(n[ii] = C ->
n[jj] != C))
endruleset;
