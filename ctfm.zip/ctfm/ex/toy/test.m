const clientNUMS : 2;
