Ruleset  channel2 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' sends grant for `addr'1"
      ((((channel2 = 2 & source = node[home].home_requests[addr].source) & node[home].home_requests[addr].status = completed) & !(node[home].outchan[channel2].valid)))&node[home].home_requests[addr].op = read_shared
    ==>
    Begin
      node[home].outchan[channel2].msg.source := home;
      node[home].outchan[channel2].msg.dest := node[home].home_requests[addr].source;
      node[home].outchan[channel2].msg.op := grant_shared;
node[home].directory[addr][source] := cache_shared;
        For i : num_data_type Do
node[home].outchan[channel2].msg.data.values[i] := node[home].home_requests[addr].data.values[i];

End;      node[home].outchan[channel2].msg.addr := addr;
      node[home].outchan[channel2].valid := true;
      node[home].home_requests[addr].source := 0;
      node[home].home_requests[addr].op := op_invalid;
        For k : num_data_type Do
node[home].home_requests[addr].data.values[k] := false;

End;        For k : node_id Do
node[home].home_requests[addr].invalidate_list[k] := false;

End;      node[home].home_requests[addr].status := inactive;
    End;


endruleset;
Ruleset  channel2 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' sends grant for `addr'2"
      ((((channel2 = 2 & source = node[home].home_requests[addr].source) & node[home].home_requests[addr].status = completed) & !(node[home].outchan[channel2].valid)))&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)
    ==>
    Begin
      node[home].outchan[channel2].msg.source := home;
      node[home].outchan[channel2].msg.dest := node[home].home_requests[addr].source;
              For i : num_data_type Do
node[home].outchan[channel2].msg.data.values[i] := node[home].home_requests[addr].data.values[i];

End;      node[home].outchan[channel2].msg.addr := addr;
      node[home].outchan[channel2].valid := true;
      node[home].home_requests[addr].source := 0;
      node[home].home_requests[addr].op := op_invalid;
        For k : num_data_type Do
node[home].home_requests[addr].data.values[k] := false;

End;        For k : node_id Do
node[home].home_requests[addr].invalidate_list[k] := false;

End;      node[home].home_requests[addr].status := inactive;
    End;


endruleset;
Ruleset  channel2 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' sends grant for `addr'3"
      ((((channel2 = 2 & source = node[home].home_requests[addr].source) & node[home].home_requests[addr].status = completed) & !(node[home].outchan[channel2].valid)))&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)
    ==>
    Begin
      node[home].outchan[channel2].msg.source := home;
      node[home].outchan[channel2].msg.dest := node[home].home_requests[addr].source;
              For i : num_data_type Do
node[home].outchan[channel2].msg.data.values[i] := node[home].home_requests[addr].data.values[i];

End;      node[home].outchan[channel2].msg.addr := addr;
      node[home].outchan[channel2].valid := true;
      node[home].home_requests[addr].source := 0;
      node[home].home_requests[addr].op := op_invalid;
        For k : num_data_type Do
node[home].home_requests[addr].data.values[k] := false;

End;        For k : node_id Do
node[home].home_requests[addr].invalidate_list[k] := false;

End;      node[home].home_requests[addr].status := inactive;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack4"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&node[home].directory[addr][source] = cache_exclusive&node[home].home_requests[addr].op = read_shared
    ==>
    Begin
        For i : num_data_type Do
node[home].memory[addr].values[i] := node[home].inchan[channel3].msg.data.values[i];

End;        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
      node[home].home_requests[addr].status := completed;
      node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack5"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&node[home].directory[addr][source] = cache_exclusive&!(node[home].home_requests[addr].op = read_shared)&node[home].home_requests[addr].op = req_upgrade
    ==>
    Begin
        For i : num_data_type Do
node[home].memory[addr].values[i] := node[home].inchan[channel3].msg.data.values[i];

End;        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack6"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&node[home].directory[addr][source] = cache_exclusive&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)&node[home].home_requests[addr].op = read_exclusive
    ==>
    Begin
        For i : num_data_type Do
node[home].memory[addr].values[i] := node[home].inchan[channel3].msg.data.values[i];

End;        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack7"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&node[home].directory[addr][source] = cache_exclusive&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)&!(node[home].home_requests[addr].op = read_exclusive)
    ==>
    Begin
        For i : num_data_type Do
node[home].memory[addr].values[i] := node[home].inchan[channel3].msg.data.values[i];

End;        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack8"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&node[home].directory[addr][source] = cache_exclusive&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)&!(node[home].home_requests[addr].op = read_exclusive)
    ==>
    Begin
        For i : num_data_type Do
node[home].memory[addr].values[i] := node[home].inchan[channel3].msg.data.values[i];

End;        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack9"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&!(node[home].directory[addr][source] = cache_exclusive)&node[home].home_requests[addr].op = read_shared&!(node[home].home_requests[addr].op = req_upgrade)&!(node[home].home_requests[addr].op = read_exclusive)
    ==>
    Begin
              For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
      node[home].home_requests[addr].status := completed;
      node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack10"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&!(node[home].directory[addr][source] = cache_exclusive)&!(node[home].home_requests[addr].op = read_shared)&node[home].home_requests[addr].op = req_upgrade&!(node[home].home_requests[addr].op = read_exclusive)
    ==>
    Begin
              For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack11"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&!(node[home].directory[addr][source] = cache_exclusive)&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)&node[home].home_requests[addr].op = read_exclusive
    ==>
    Begin
              For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack12"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&!(node[home].directory[addr][source] = cache_exclusive)&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)&!(node[home].home_requests[addr].op = read_exclusive)
    ==>
    Begin
              For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' processes invalidate ack13"
      ((((((channel3 = 3 & addr = node[home].inchan[channel3].msg.addr) & source = node[home].inchan[channel3].msg.source) & node[home].inchan[channel3].valid) & node[home].home_requests[addr].status = pending) & node[home].inchan[channel3].msg.op = invalidate_ack))&!(node[home].directory[addr][source] = cache_exclusive)&!(node[home].home_requests[addr].op = read_shared)&!(node[home].home_requests[addr].op = req_upgrade)&!(node[home].home_requests[addr].op = read_exclusive)
    ==>
    Begin
              For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].inchan[channel3].msg.data.values[i];

End;      node[home].directory[addr][source] := cache_invalid;
            node[home].inchan[channel3].msg.source := 0;
      node[home].inchan[channel3].msg.dest := 0;
      node[home].inchan[channel3].msg.op := op_invalid;
      node[home].inchan[channel3].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel3].msg.data.values[k] := false;

End;      node[home].inchan[channel3].valid := false;
    End;


endruleset;
Ruleset  channel2 : channel_id; dest : node_id; addr : addr_type; home : node_id Do
    Rule "`home' prepares invalidate for `addr'14"
      (((((channel2 = 2 & node[home].home_requests[addr].invalidate_list[dest]) & node[home].home_requests[addr].status = pending) &   exists n : node_id Do
node[home].home_requests[addr].invalidate_list[n]
End) & !(node[home].outchan[channel2].valid)))
    ==>
    Begin
      node[home].outchan[channel2].msg.addr := addr;
      node[home].outchan[channel2].msg.op := invalidate;
      node[home].outchan[channel2].msg.source := home;
      node[home].outchan[channel2].msg.dest := dest;
      node[home].outchan[channel2].valid := true;
      node[home].home_requests[addr].invalidate_list[dest] := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message15"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&(node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid)&(node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared)&node[home].cache[addr].state = cache_shared
    ==>
    Begin
      node[home].inchan[channel1].msg.op := read_exclusive;
      node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].cache[addr].data.values[i];

End;node[home].home_requests[addr].status := completed;
      node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message16"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&(node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid)&(node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared)&!(node[home].cache[addr].state = cache_shared)
    ==>
    Begin
      node[home].inchan[channel1].msg.op := read_exclusive;
      node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].memory[addr].values[i];

End;node[home].home_requests[addr].status := completed;
      node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message17"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&(node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid)&(node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared)&!(node[home].cache[addr].state = cache_shared)
    ==>
    Begin
      node[home].inchan[channel1].msg.op := read_exclusive;
      node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].memory[addr].values[i];

End;node[home].home_requests[addr].status := completed;
      node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message18"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&(node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid)&!((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared))&!(node[home].cache[addr].state = cache_shared)&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
      node[home].inchan[channel1].msg.op := read_exclusive;
      node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
            node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message19"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&(node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid)&!((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared))&!(node[home].cache[addr].state = cache_shared)&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
      node[home].inchan[channel1].msg.op := read_exclusive;
      node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
            node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message20"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&!((node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid))&(node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared)&node[home].cache[addr].state = cache_shared&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
            node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].cache[addr].data.values[i];

End;node[home].home_requests[addr].status := completed;
      node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message21"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&!((node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid))&(node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared)&!(node[home].cache[addr].state = cache_shared)&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
            node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].memory[addr].values[i];

End;node[home].home_requests[addr].status := completed;
      node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message22"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&!((node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid))&(node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared)&!(node[home].cache[addr].state = cache_shared)&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
            node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
        For i : num_data_type Do
node[home].home_requests[addr].data.values[i] := node[home].memory[addr].values[i];

End;node[home].home_requests[addr].status := completed;
      node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message23"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&!((node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid))&!((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared))&!(node[home].cache[addr].state = cache_shared)&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
            node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
            node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; source : node_id; addr : addr_type; home : node_id Do
    Rule "`home' accepts a request message24"
      (((((channel1 = 1 & addr = node[home].inchan[channel1].msg.addr) & source = node[home].inchan[channel1].msg.source) & node[home].inchan[channel1].valid) & node[home].home_requests[addr].status = inactive))&!((node[home].inchan[channel1].msg.op = req_upgrade & node[home].directory[addr][source] = cache_invalid))&!((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_shared))&!(node[home].cache[addr].state = cache_shared)&!(((node[home].inchan[channel1].msg.op = read_shared & node[home].directory[addr][home] = cache_invalid) & !(  exists n : node_id Do
node[home].directory[addr][n] = cache_exclusive
End)))
    ==>
    Begin
            node[home].home_requests[addr].source := source;
      node[home].home_requests[addr].op := node[home].inchan[channel1].msg.op;
            node[home].inchan[channel1].msg.source := 0;
      node[home].inchan[channel1].msg.dest := 0;
      node[home].inchan[channel1].msg.op := op_invalid;
      node[home].inchan[channel1].msg.addr := 1;
        For k : num_data_type Do
node[home].inchan[channel1].msg.data.values[k] := false;

End;      node[home].inchan[channel1].valid := false;
    End;


endruleset;
Ruleset  data : boolean; data_n : num_data_type; addr : addr_type; client : node_id Do
    Rule "`client' stores data in cache for `addr'25"
      ((node[client].remote_requests[addr].status != pending & node[client].cache[addr].state = cache_exclusive))
    ==>
    Begin
      node[client].cache[addr].data.values[data_n] := data;
      auxdata[addr].values[data_n] := data;
    End;


endruleset;
Ruleset  channel2 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' receives reply from home26"
      ((((channel2 = 2 & addr = node[client].inchan[channel2].msg.addr) & node[client].inchan[channel2].valid) & ((node[client].inchan[channel2].msg.op = grant_shared | node[client].inchan[channel2].msg.op = grant_upgrade) | node[client].inchan[channel2].msg.op = grant_exclusive)))&node[client].inchan[channel2].msg.op = grant_shared
    ==>
    Begin
        For i : num_data_type Do
node[client].cache[addr].data.values[i] := node[client].inchan[channel2].msg.data.values[i];

End;node[client].cache[addr].state := cache_shared;
      node[client].local_requests[addr] := false;
      node[client].inchan[channel2].msg.source := 0;
      node[client].inchan[channel2].msg.dest := 0;
      node[client].inchan[channel2].msg.op := op_invalid;
      node[client].inchan[channel2].msg.addr := 1;
        For k : num_data_type Do
node[client].inchan[channel2].msg.data.values[k] := false;

End;      node[client].inchan[channel2].valid := false;
    End;


endruleset;
Ruleset  channel2 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' receives reply from home27"
      ((((channel2 = 2 & addr = node[client].inchan[channel2].msg.addr) & node[client].inchan[channel2].valid) & ((node[client].inchan[channel2].msg.op = grant_shared | node[client].inchan[channel2].msg.op = grant_upgrade) | node[client].inchan[channel2].msg.op = grant_exclusive)))&!(node[client].inchan[channel2].msg.op = grant_shared)&node[client].inchan[channel2].msg.op = grant_upgrade
    ==>
    Begin
      node[client].cache[addr].state := cache_exclusive;
      node[client].local_requests[addr] := false;
      node[client].inchan[channel2].msg.source := 0;
      node[client].inchan[channel2].msg.dest := 0;
      node[client].inchan[channel2].msg.op := op_invalid;
      node[client].inchan[channel2].msg.addr := 1;
        For k : num_data_type Do
node[client].inchan[channel2].msg.data.values[k] := false;

End;      node[client].inchan[channel2].valid := false;
    End;


endruleset;
Ruleset  channel2 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' receives reply from home28"
      ((((channel2 = 2 & addr = node[client].inchan[channel2].msg.addr) & node[client].inchan[channel2].valid) & ((node[client].inchan[channel2].msg.op = grant_shared | node[client].inchan[channel2].msg.op = grant_upgrade) | node[client].inchan[channel2].msg.op = grant_exclusive)))&!(node[client].inchan[channel2].msg.op = grant_shared)&!(node[client].inchan[channel2].msg.op = grant_upgrade)&node[client].inchan[channel2].msg.op = grant_exclusive
    ==>
    Begin
        For i : num_data_type Do
node[client].cache[addr].data.values[i] := node[client].inchan[channel2].msg.data.values[i];

End;node[client].cache[addr].state := cache_exclusive;
      node[client].local_requests[addr] := false;
      node[client].inchan[channel2].msg.source := 0;
      node[client].inchan[channel2].msg.dest := 0;
      node[client].inchan[channel2].msg.op := op_invalid;
      node[client].inchan[channel2].msg.addr := 1;
        For k : num_data_type Do
node[client].inchan[channel2].msg.data.values[k] := false;

End;      node[client].inchan[channel2].valid := false;
    End;


endruleset;
Ruleset  channel2 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' receives reply from home29"
      ((((channel2 = 2 & addr = node[client].inchan[channel2].msg.addr) & node[client].inchan[channel2].valid) & ((node[client].inchan[channel2].msg.op = grant_shared | node[client].inchan[channel2].msg.op = grant_upgrade) | node[client].inchan[channel2].msg.op = grant_exclusive)))&!(node[client].inchan[channel2].msg.op = grant_shared)&!(node[client].inchan[channel2].msg.op = grant_upgrade)&!(node[client].inchan[channel2].msg.op = grant_exclusive)
    ==>
    Begin
            node[client].local_requests[addr] := false;
      node[client].inchan[channel2].msg.source := 0;
      node[client].inchan[channel2].msg.dest := 0;
      node[client].inchan[channel2].msg.op := op_invalid;
      node[client].inchan[channel2].msg.addr := 1;
        For k : num_data_type Do
node[client].inchan[channel2].msg.data.values[k] := false;

End;      node[client].inchan[channel2].valid := false;
    End;


endruleset;
Ruleset  channel2 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' receives reply from home30"
      ((((channel2 = 2 & addr = node[client].inchan[channel2].msg.addr) & node[client].inchan[channel2].valid) & ((node[client].inchan[channel2].msg.op = grant_shared | node[client].inchan[channel2].msg.op = grant_upgrade) | node[client].inchan[channel2].msg.op = grant_exclusive)))&!(node[client].inchan[channel2].msg.op = grant_shared)&!(node[client].inchan[channel2].msg.op = grant_upgrade)&!(node[client].inchan[channel2].msg.op = grant_exclusive)
    ==>
    Begin
            node[client].local_requests[addr] := false;
      node[client].inchan[channel2].msg.source := 0;
      node[client].inchan[channel2].msg.dest := 0;
      node[client].inchan[channel2].msg.op := op_invalid;
      node[client].inchan[channel2].msg.addr := 1;
        For k : num_data_type Do
node[client].inchan[channel2].msg.data.values[k] := false;

End;      node[client].inchan[channel2].valid := false;
    End;


endruleset;
Ruleset  channel3 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' prepares invalidate ack for `addr'31"
      ((((channel3 = 3 & node[client].remote_requests[addr].status = completed) & node[client].remote_requests[addr].op = invalidate) & !(node[client].outchan[channel3].valid)))
    ==>
    Begin
      node[client].outchan[channel3].msg.op := invalidate_ack;
      node[client].outchan[channel3].msg.source := client;
      node[client].outchan[channel3].msg.dest := node[client].remote_requests[addr].home;
        For i : num_data_type Do
node[client].outchan[channel3].msg.data.values[i] := node[client].remote_requests[addr].data.values[i];

End;      node[client].outchan[channel3].msg.addr := addr;
      node[client].outchan[channel3].valid := true;
      node[client].remote_requests[addr].home := 0;
      node[client].remote_requests[addr].op := op_invalid;
        For k : num_data_type Do
node[client].remote_requests[addr].data.values[k] := false;

End;      node[client].remote_requests[addr].status := inactive;
    End;


endruleset;
Ruleset  addr : addr_type; client : node_id Do
    Rule "`client' processes invalidate request for `addr'32"
      ((node[client].remote_requests[addr].status = pending & node[client].remote_requests[addr].op = invalidate))
    ==>
    Begin
        For i : num_data_type Do
node[client].remote_requests[addr].data.values[i] := node[client].cache[addr].data.values[i];

End;      node[client].remote_requests[addr].status := completed;
      node[client].cache[addr].state := cache_invalid;
        For k : num_data_type Do
node[client].cache[addr].data.values[k] := false;

End;    End;


endruleset;
Ruleset  channel2 : channel_id; addr : addr_type; client : node_id Do
    Rule "`client' accepts invalidate request33"
      (((((channel2 = 2 & addr = node[client].inchan[channel2].msg.addr) & node[client].inchan[channel2].valid) & node[client].inchan[channel2].msg.op = invalidate) & node[client].remote_requests[addr].status = inactive))
    ==>
    Begin
      node[client].remote_requests[addr].home := node[client].inchan[channel2].msg.source;
      node[client].remote_requests[addr].op := node[client].inchan[channel2].msg.op;
      node[client].remote_requests[addr].status := pending;
      node[client].inchan[channel2].msg.source := 0;
      node[client].inchan[channel2].msg.dest := 0;
      node[client].inchan[channel2].msg.op := op_invalid;
      node[client].inchan[channel2].msg.addr := 1;
        For k : num_data_type Do
node[client].inchan[channel2].msg.data.values[k] := false;

End;      node[client].inchan[channel2].valid := false;
    End;


endruleset;
Ruleset  channel1 : channel_id; addr : addr_type; req : request_opcode; client : node_id Do
    Rule "`client' generates new `req' for `addr'34"
      ((((channel1 = 1 & !(node[client].local_requests[addr])) & (((req = req_read_shared & node[client].cache[addr].state = cache_invalid) | (req = req_read_exclusive & node[client].cache[addr].state = cache_invalid)) | (req = req_req_upgrade & node[client].cache[addr].state = cache_shared))) & !(node[client].outchan[channel1].valid)))&req = req_read_shared
    ==>
    Begin
      node[client].outchan[channel1].msg.source := client;
      node[client].outchan[channel1].msg.dest := 0;
      node[client].outchan[channel1].msg.op := read_shared;
      node[client].outchan[channel1].msg.addr := addr;
      node[client].outchan[channel1].valid := true;
      node[client].local_requests[addr] := true;
    End;


endruleset;
Ruleset  channel1 : channel_id; addr : addr_type; req : request_opcode; client : node_id Do
    Rule "`client' generates new `req' for `addr'35"
      ((((channel1 = 1 & !(node[client].local_requests[addr])) & (((req = req_read_shared & node[client].cache[addr].state = cache_invalid) | (req = req_read_exclusive & node[client].cache[addr].state = cache_invalid)) | (req = req_req_upgrade & node[client].cache[addr].state = cache_shared))) & !(node[client].outchan[channel1].valid)))&!(req = req_read_shared)&req = req_read_exclusive
    ==>
    Begin
      node[client].outchan[channel1].msg.source := client;
      node[client].outchan[channel1].msg.dest := 0;
      node[client].outchan[channel1].msg.op := read_exclusive;
      node[client].outchan[channel1].msg.addr := addr;
      node[client].outchan[channel1].valid := true;
      node[client].local_requests[addr] := true;
    End;


endruleset;
Ruleset  channel1 : channel_id; addr : addr_type; req : request_opcode; client : node_id Do
    Rule "`client' generates new `req' for `addr'36"
      ((((channel1 = 1 & !(node[client].local_requests[addr])) & (((req = req_read_shared & node[client].cache[addr].state = cache_invalid) | (req = req_read_exclusive & node[client].cache[addr].state = cache_invalid)) | (req = req_req_upgrade & node[client].cache[addr].state = cache_shared))) & !(node[client].outchan[channel1].valid)))&!(req = req_read_shared)&!(req = req_read_exclusive)
    ==>
    Begin
      node[client].outchan[channel1].msg.source := client;
      node[client].outchan[channel1].msg.dest := 0;
      node[client].outchan[channel1].msg.op := req_upgrade;
      node[client].outchan[channel1].msg.addr := addr;
      node[client].outchan[channel1].valid := true;
      node[client].local_requests[addr] := true;
    End;


endruleset;
Ruleset  channel1 : channel_id; addr : addr_type; req : request_opcode; client : node_id Do
    Rule "`client' generates new `req' for `addr'37"
      ((((channel1 = 1 & !(node[client].local_requests[addr])) & (((req = req_read_shared & node[client].cache[addr].state = cache_invalid) | (req = req_read_exclusive & node[client].cache[addr].state = cache_invalid)) | (req = req_req_upgrade & node[client].cache[addr].state = cache_shared))) & !(node[client].outchan[channel1].valid)))&!(req = req_read_shared)&!(req = req_read_exclusive)
    ==>
    Begin
      node[client].outchan[channel1].msg.source := client;
      node[client].outchan[channel1].msg.dest := 0;
      node[client].outchan[channel1].msg.op := req_upgrade;
      node[client].outchan[channel1].msg.addr := addr;
      node[client].outchan[channel1].valid := true;
      node[client].local_requests[addr] := true;
    End;


endruleset;
Ruleset  dest : node_id; ch : channel_id; source : node_id Do
    Rule "Transfer message from `source' via `ch'38"
      (((dest = node[source].outchan[ch].msg.dest & node[source].outchan[ch].valid) & !(node[dest].inchan[ch].valid)))
    ==>
    Begin
      node[dest].inchan[ch].msg.source := node[source].outchan[ch].msg.source;
      node[dest].inchan[ch].msg.dest := node[source].outchan[ch].msg.dest;
      node[dest].inchan[ch].msg.op := node[source].outchan[ch].msg.op;
      node[dest].inchan[ch].msg.addr := node[source].outchan[ch].msg.addr;
        For i : num_data_type Do
node[dest].inchan[ch].msg.data.values[i] := node[source].outchan[ch].msg.data.values[i];

End;      node[dest].inchan[ch].valid := node[source].outchan[ch].valid;
      node[source].outchan[ch].msg.source := 0;
      node[source].outchan[ch].msg.dest := 0;
      node[source].outchan[ch].msg.op := op_invalid;
      node[source].outchan[ch].msg.addr := 1;
        For k : num_data_type Do
node[source].outchan[ch].msg.data.values[k] := false;

End;      node[source].outchan[ch].valid := false;
    End;


endruleset;
