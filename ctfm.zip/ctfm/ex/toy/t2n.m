
const

  clientNUMS : 5;
                      
type

  
  state : enum{I,T,C,E,A,B,Q,W,R,AA,AAA};
  client : 1..5;
  new_type_0 : array [ client ] of state;

var

  n : new_type_0;
  x : boolean;
  a : client;

ruleset  ctf : client do
rule "Try1"
  n[ctf] != I &
  n[ctf] != I
==>
Begin
  n[ctf] := I;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try2"
  n[ctf] = A &
  n[ctf] != I
==>
Begin
  n[ctf] := I;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try3"
  n[ctf] != I &
  n[ctf] = I &
  n[ctf] != C &
  n[ctf] != AA
==>
Begin
  n[ctf] := T;
  n[ctf] := C;
  n[ctf] := AA;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try4"
  n[ctf] = A &
  n[ctf] = I &
  n[ctf] != C &
  n[ctf] != AA
==>
Begin
  n[ctf] := T;
  n[ctf] := C;
  n[ctf] := AA;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try5"
  n[ctf] != I &
  n[ctf] = I &
  n[ctf] != C &
  n[ctf] = AA
==>
Begin
  n[ctf] := T;
  n[ctf] := C;
  for p : client do
    if ((p != 2 &
    x)) then
      n[ctf] := B;
    end;
  end;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try6"
  n[ctf] = A &
  n[ctf] = I &
  n[ctf] != C &
  n[ctf] = AA
==>
Begin
  n[ctf] := T;
  n[ctf] := C;
  for p : client do
    if ((p != 2 &
    x)) then
      n[ctf] := B;
    end;
  end;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try7"
  n[ctf] != I &
  n[ctf] = I &
  n[ctf] = C &
  n[ctf] != AA
==>
Begin
  n[ctf] := T;
  n[ctf] := AA;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try8"
  n[ctf] = A &
  n[ctf] = I &
  n[ctf] = C &
  n[ctf] != AA
==>
Begin
  n[ctf] := T;
  n[ctf] := AA;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try9"
  n[ctf] != I &
  n[ctf] = I &
  n[ctf] = C &
  n[ctf] = AA
==>
Begin
  n[ctf] := T;
  for p : client do
    if ((p != 2 &
    x)) then
      n[ctf] := B;
    end;
  end;
  n[ctf] := AA;
endrule;
endruleset;

ruleset  ctf : client do
rule "Try10"
  n[ctf] = A &
  n[ctf] = I &
  n[ctf] = C &
  n[ctf] = AA
==>
Begin
  n[ctf] := T;
  for p : client do
    if ((p != 2 &
    x)) then
      n[ctf] := B;
    end;
  end;
  n[ctf] := AA;
endrule;
endruleset;

startstate
  x := true;
endstartstate;
ruleset  jj : client; ii : client do
invariant "coherence"
  (ii != jj ->
  (n[ii] = C ->
  n[jj] != C))
endruleset;
