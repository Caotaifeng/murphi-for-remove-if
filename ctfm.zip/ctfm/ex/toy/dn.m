Const
INITIAL_VAL : 5
Type
   state : enum{I,T,C,E};
val_t : 1..5;
 a : tval_t;

Var 
Ruleset Do
  Alia Do 

    Rule "1"
      a > 0
    ==>
    Begin
       For i : val_t Do 
 a := a + 1;
End;
    End;

    Startstate
    Begin
      a := 0;
    End;

End;

End;

Invariant "Positive sum"
1;