Const clientNUMS : 5;
Type 
state : enum{I, T, C, E, A, B, Q, W, R, AA, AAA};
client: 1..clientNUMS;
Var n : array [client] of state;
    x : boolean; 
	a : client;
	
	
	
ruleset ctf : client do
	rule "Try" 
	n[ctf] = I -> n[ctf] = A
	==> 
	var b:boolean;
		begin
		undefine b;
		if(n[ctf] = T) then
		n[ctf] := E;
		endif;
		n[ctf] := AA;
	end;
end;
startstate
begin
  x := true;
end;
ruleset ii:client; jj: client do
invariant "coherence"
  ii != jj -> (n[ii] = C -> n[jj] != C);
endruleset;

