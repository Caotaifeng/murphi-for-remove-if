/**CFile***********************************************************************

  FileName    [cpp_code.cpp]

  Synopsis    [File for code generation]

  Author      [Igor Melatti]

  Copyright   [
  This file is part of the compiler package of CMurphi. 
  Copyright (C) 2009-2012 by Sapienza University of Rome. 

  CMurphi is free software; you can redistribute it and/or 
  modify it under the terms of the GNU Lesser General Public 
  License as published by the Free Software Foundation; either 
  of the License, or (at your option) any later version.

  CMurphi is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public 
  License along with this library; if not, write to the Free Software 
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA.

  To contact the CMurphi development board, email to <melatti@di.uniroma1.it>. ]

******************************************************************************/

#include "mu.hpp"
#include <string.h>
//int ctfflag = 0;
int forallnum = 0;
int rnum = 1;
int formark = 0;
int ruleflag = 0;
int condflag = 0;
int cflag = 0;
int tflag = 0;
int vflag = 0;
int lflag = 0;
int blanknum = 0;
int andflag = 0;
int isforall2 = 0;
int invflag = 0;
simplerule *startrule = NULL;
simplerule *invrule = NULL;
/* NOTE: 

   Beware of declarations introduced not at the beginnings
   of scopes.

   Why are expressions all handled with switches instead of
   virtual functions? 
*/

/*
 * Each generate_code() member function outputs to stdout the code
 * necessary to evaluate that thing, and returns a string with
 * what is necessary to use it as a value.
 *
 * Some examples:
 *
 * The statement "A := foo" sends this to stdout:
 *   A = foo;
 * And returns the null string.
 *
 * the expression "A[i]" sends nothing to stdout and returns
 * the string "A[i]".
 *
 * A more complicated example, the real motivation for this scheme:
 * The expression "FORALL i : 0..1 DO boolarray[i] END;"
 * sends something like the following to stdout, which is what is
 * required to compute the forall:
 * 
 *   mu__forall_1 = TRUE;
 *   {
 *     for(i = 0; i <= 1; i++)
 *       {
 *	 if ( !(boolarray[i]) )
 *       {
 *	 mu__forall_1 = FALSE;
 *	 break;
 *       }
 *       }
 *   }
 *
 * and then it returns "mu__forall_1", which is what\'s necessary to
 * use the value of the forall.
 *
 */

/*
 * Standard hack:
 * in many cases, we have to generate a list of things separated by commas.
 * Usually, we do this by sprintf-ing ", x" into a buffer for each x,
 * and then using (buffer + 1) as the value to use, so we skip the
 * comma at the betginning.
 */

/*
 * Debugging hint: to check whether all the parentheses and braces
 * this generating match, open the generated code in emacs in
 * c++-mode, put set the mark at one end and point at the other, and
 * do C-M-\ (indent-region) to reindent all the lines.  If the last
 * line of the generated code doesn\'t end in column 1, your braces
 * or parentheses don\'t match up somewhere.
 */
//ctf add use for print blank
void blankadd()
{
	blanknum++;
}
void blankred()
{
	blanknum--;
}
void writeblank()
{
	int i = blanknum;
	for(;i>0;i--)
	{
		fprintf(codefile,"  ");
	}
}

void Init(Stack &s)
 {
	 s.top = -1;
	 int i;
	 for(i = 0;i<100;i++)
	 {
		s.value[i] = NULL;
	 }
 }
 void Push(Stack &s,stmt *e)
 {
	 if(s.top > 99)
	 {}
	 else
	 {
		 s.top++;
		 s.value[s.top] = e;
	 }
 }
 int IsEmpty(Stack s)
 {
	 if(s.top == -1)
	 {
		 return 1;
	 }
	 else
	 {
		return 0;
	 }
 }
void Pop(Stack &s,stmt **e)
 {
	 (*e) = s.value[s.top];
	 s.top--;
 } 
 void Copy(Stack &s1,Stack &s2)
 {
	 for(int i = 0;i <100;i++)
	 {
		 s2.value[i] = s1.value[i];
	 }
	 s2.top = s1.top;
 }
/********************
  code related to decl
  --
  -- typedecl
  -- -- enumtypedecl
  -- -- subrangetypedecl
  -- -- arraytypedecl
  -- -- recordtypedecl
  -- -- scalarsettypedecl
  -- -- uniontypedecl
  -- constdecl
  -- vardecl
  -- aliasdecl
  -- quantdecl
  -- parameter
  -- -- param
  -- -- varparam
  -- -- valparam
  -- -- constparam
  -- procdecl
  -- funcdecl 
  ********************/

/********************
  code for decl
  ********************/
const char *decl::generate_decl()
{
  Error.Error
      ("Internal:  decl::generate_decl() should not have been called.");
  return "ERROR!";
}

const char *decl::generate_code()
{
  return name;
}

/********************
  code for typedecl
 ********************/
const char *typedecl::generate_decl()
{
  Error.Error
      ("Internal:  typedecl::generate_code() should never have been called.");
  return "ERROR!";
}
//meiyong
void typedecl::generate_all_decl()
{
  if (next != NULL) {
    next->generate_all_decl();
  }
  generate_decl();
}
//meiyong
/* AP: code for realtypedecl */
const char *realtypedecl::generate_decl()
{
  if (!declared) {
    /* Invent a name for the object, and a "mu_name" for
       the declaration of the object in the generated code. */
    if (name == NULL) {
      name = tsprintf("_real_%d", tNum);
      mu_name = tsprintf("mu_%s", name);
    }
    /* class name */
    fprintf(codefile, "class %s: public %s\n" "{\n" " public:\n" "  inline double operator=(double val) { return %s::operator=(val); };\n" "  inline double operator=(const %s& val) { return %s::operator=((double) val); };\n" "  %s (const char *name, int os): %s(%d,%d,%d,name, os) {};\n" "  %s (void): %s(%d,%d,%d) {};\n" "  %s (double val): %s(%d,%d,%d,\"Parameter or function result.\", 0)\n" "  {\n" "    operator=(val);\n" "  };\n" "  char * Name() { return tsprintf(\"%%le\",value()); };\n", mu_name, mu_type,	/* class name */
	    mu_type, mu_name, mu_type, mu_name, mu_type, accuracy, exponent_value, numbits,	//IM: fixed, exponent_value instead of exponent
	    mu_name, mu_type, accuracy, exponent_value, numbits,	//IM: fixed, exponent_value instead of exponent
	    mu_name, mu_type, accuracy, exponent_value, numbits	//IM: fixed, exponent_value instead of exponent
	);
    theprog->symmetry.generate_symmetry_function_decl();
    fprintf(codefile,
	    "  virtual void MultisetSort() {};\n"
	    "  void print_statistic() {};\n" "};\n\n");
    fprintf(codefile, "/*** end of real decl ***/\n");
    fprintf(codefile, "%s %s_undefined_var;\n\n", mu_name, mu_name);
    declared = TRUE;
  }
  /* Should never use this as a return value expression in the code gen */
  return "ERROR!";
}

/********************
  code for enumtypedecl
  Dill: I think this is bogusly ending each elt with ",", necessitating
   a "NULL" element at the end of the list.  
 ********************/
void make_enum_idvalues(ste * idvalues, typedecl * thistype)
{
  if (idvalues != NULL &&
      idvalues->getvalue()->getclass() == decl::Const &&
      type_equal(idvalues->getvalue()->gettype(), thistype)) {
    make_enum_idvalues(idvalues->getnext(), thistype);
    fprintf(codefile, "%s,", idvalues->getname()->getname());
  }
}
//meiyong
void make_enum (ste * idvalues, typedecl * thistype){
  if (idvalues != NULL &&
      idvalues->getvalue()->getclass() == decl::Const &&
      type_equal(idvalues->getvalue()->gettype(), thistype)) {
        make_enum(idvalues->getnext(), thistype);
	fprintf(codefile, "let _%s = strc \"%s\"\n",idvalues->getname()->getname(),idvalues->getname()->getname());
  }
}

const char *enumtypedecl::generate_decl()
{
  if (!declared) {
    /* Invent a name for the object, and a "mu_name" for
       the declaration of the object in the generated code. */
    if (name == NULL) {
      name = tsprintf("enum_n%d", tNum);
      //mu_name = tsprintf("mu_%s", name);
    }
    fprintf(codefile, "\n");
	writeblank();
	fprintf(codefile, "%s : enum{",name);
    make_enum_idvalues(idvalues, this);
    fseek(codefile,-1, SEEK_CUR);
    fprintf(codefile, "};\n");
	tNum++;
    declared = TRUE;
  }
  /* Should never use this as a return value expression in the code gen */
  return "ERROR!";
}

/********************
  code for subrangetypedecl
 ********************/
//ctf 
const char *subrangetypedecl::generate_decl()
{int i;
  /* if decl has not already been generated... */
  if (!declared) {
    /* make up a name for a new class, and a mu_name to be output. */
    if (name == NULL) {
      name = tsprintf("subrange_n%d", tNum);
      //mu_name = tsprintf("mu_%s", name);
    }
    fprintf(codefile, "%s : ",name);
	fprintf(codefile, "%d..%d",left,right);
	fprintf(codefile, ";\n");
	tNum++;
    declared = TRUE;
  }
  return "ERROR!";
}



/********************
  code for arraytypedecl
  Dill:  HERE IS ONE OF THE EVIL TSPRINTFS!
 ********************/
 //meiyong
int make_elt_ref_by_union(stelist * unionmembers)
{
  int base = 0;
  if (unionmembers->next != NULL)
    base = make_elt_ref_by_union(unionmembers->next);
  typedecl *t = (typedecl *) unionmembers->s->getvalue();
  fprintf(codefile,
	  "    if ( ( index >= %d ) && ( index <= %d ) )\n"
	  "      return array[ index - (%d) ];\n",
	  t->getleft(), t->getright(), t->getleft() - base);
  return base + t->getsize();
}
 //meiyong
void make_elt_with_scalarset(ste * idvalues, int size, int numbits)
{
  if (size > 1)
    make_elt_with_scalarset(idvalues->next, size - 1, numbits);
  fprintf(codefile,
	  "if (n) array[i].set_self_ar(n,\"%s\", i * %d + os); else array[i].set_self_ar(NULL, NULL, 0); i++;\n",
	  idvalues->getname()->getname(), numbits);
}
 //meiyong
void make_elt_with_enum(ste * idvalues, int size, int numbits)
{
  if (idvalues == NULL & size == 2) {
    fprintf(codefile,
	    "if (n) array[i].set_self_ar(n,\"false\", i * %d + os); else array[i].set_self_ar(NULL, NULL, 0); i++;\n",
	    numbits);
    fprintf(codefile,
	    "if (n) array[i].set_self_ar(n,\"true\", i * %d + os); else array[i].set_self_ar(NULL, NULL, 0); i++;\n",
	    numbits);
  } else if (idvalues != NULL) {
    if (size > 1)
      make_elt_with_enum(idvalues->next, size - 1, numbits);
    fprintf(codefile,
	    "if (n) array[i].set_self_ar(n,\"%s\", i * %d + os); else array[i].set_self_ar(NULL, NULL, 0); i++;\n",
	    idvalues->getname()->getname(), numbits);
  } else
    Error.Error("Internal Error: make_elt_with_enum");
}
 //meiyong
void make_elt_with_union(stelist * unionmembers, int numbits)
{
  if (unionmembers->next != NULL)
    make_elt_with_union(unionmembers->next, numbits);
  if (((typedecl *) unionmembers->s->getvalue())->gettypeclass() ==
      typedecl::Scalarset)
    make_elt_with_scalarset(((scalarsettypedecl *) unionmembers->
			     s->getvalue())->getidvalues(),
			    unionmembers->s->getvalue()->getsize(),
			    numbits);
  else if (((typedecl *) unionmembers->s->getvalue())->gettypeclass() ==
	   typedecl::Enum)
    make_elt_with_enum(((enumtypedecl *) unionmembers->s->
			getvalue())->getidvalues(),
		       unionmembers->s->getvalue()->getsize(), numbits);
  else
    Error.Error("funny element in union");
}

const char *arraytypedecl::generate_decl()
{
  if (!declared) {
    if (name == NULL) {
      name = tsprintf("array_n%d", tNum);
      //mu_name = tsprintf("mu_%s", name);
    }
    fprintf(codefile,"%s : array [ %s ] of %s;\n"
	,name, gettype()->getindextype()->name, gettype()->getelementtype()->name);
	tNum++;
	declared = TRUE;
    /* declare class with set_self, constructor and destructor */

    /* declare range-checked operator [] */
	/*
    switch (indextype->gettypeclass()) {
    case typedecl::Enum:
    case typedecl::Range:
      break;
    case typedecl::Scalarset:
      break;
    case typedecl::Union:
      (void)
	  make_elt_ref_by_union(((uniontypedecl *)
				 indextype)->getunionmembers());
      fprintf(codefile,
	      "    if (index==UNDEFVAL) \n"
	      "      Error.Error(\"Indexing to %%s using an undefined value.\", name);\n"
	      "    else\n"
	      "      Error.Error(\"Funny index value %%d for %%s. (Internal Error in Type Checking.\",index, name);\n"
	      "    return array[0];\n" "  }\n");
      break;
    case typedecl::Array:
    case typedecl::Record:
    case typedecl::Error_type:
    default:
      // the error should already be flagged. 

      // On the other hand, if this error happened, it should never
      // have gotten here. Therefore, we will put an error here, because
      // redundant error-checking is never a waste. --RLM
      Error.Error("Internal: Odd value for arraydecl::elementtype;");
      break;
    }
   */
    /* and an operator =. */
   // generate_assign();
//    if (elementtype->issimple()) 
//      fprintf(codefile, 
//      "  %s& operator= (const %s& from)\n"
//      "  {\n"
//      "    for (int i = 0; i < %d; i++)\n"
//      "      if (from.array[i].isundefined() )\n"
//      "       array[i].undefine();\n"
//      "      else\n"
//      "       array[i] = from.array[i];\n"
//      "    return *this;\n"
//      "  }\n\n",
//      mu_name,
//      mu_name,
//      indextype->getsize());
//   else
//      fprintf(codefile, 
//      "  %s& operator= (const %s& from)\n"
//      "  {\n"
//      "    for (int i = 0; i < %d; i++)\n"
//      "      array[i] = from.array[i];\n"
//      "    return *this;\n"
//      "  }\n\n",
//      mu_name,
//      mu_name,
//      indextype->getsize());

    /* comparsion function */
  //  if (indextype->getstructure() == typedecl::ScalarsetVariable)
   //   fprintf(codefile,
//	      "friend int CompareWeight(%s& a, %s& b)\n"
//	      "  {\n" "    return 0;\n" "  }\n", mu_name, mu_name);
  //  else
    //  fprintf(codefile,
//	      "friend int CompareWeight(%s& a, %s& b)\n"
//	      "  {\n"
//	      "    int w;\n"
//	      "    for (int i=0; i<%d; i++) {\n"
//	      "      w = CompareWeight(a.array[i], b.array[i]);\n"
//	      "      if (w!=0) return w;\n"
//	      "    }\n"
//	      "    return 0;\n"
//	      "  }\n", mu_name, mu_name, indextype->getsize()
//	  );

    /* comparsion function */
  /*  fprintf(codefile,
	    "friend int Compare(%s& a, %s& b)\n"
	    "  {\n"
	    "    int w;\n"
	    "    for (int i=0; i<%d; i++) {\n"
	    "      w = Compare(a.array[i], b.array[i]);\n"
	    "      if (w!=0) return w;\n"
	    "    }\n"
	    "    return 0;\n"
	    "  }\n", mu_name, mu_name, indextype->getsize()
	);*/

    /* declare permute() */
//    theprog->symmetry.generate_symmetry_function_decl();
  /*  fprintf(codefile,
	    "  virtual void MultisetSort()\n"
	    "  {\n"
	    "    for (int i=0; i<%d; i++)\n"
	    "      array[i].MultisetSort();\n" "  }\n",
	    indextype->getsize()
	);
    fprintf(codefile,
	    "  void print_statistic()\n"
	    "  {\n"
	    "    for (int i=0; i<%d; i++)\n"
	    "      array[i].print_statistic();\n"
	    "  }\n", indextype->getsize()
	);*/

    /* standard functions:
     * clear(), undefine(), to_state() */
  /*  fprintf(codefile,
	    "  void clear() { for (int i = 0; i < %d; i++) array[i].clear(); };\n\n"
	    "  void undefine() { for (int i = 0; i < %d; i++) array[i].undefine(); };\n\n"
	    "  void reset() { for (int i = 0; i < %d; i++) array[i].reset(); };\n\n"
	    "  void to_state(state *thestate)\n"
	    "  {\n"
	    "    for (int i = 0; i < %d; i++)\n"
	    "      array[i].to_state(thestate);\n" "  };\n\n",*/
//      "  void from_state(state *thestate)\n"
//      "  {\n"
//      "    for (int i = 0; i < %d; i++)\n"
//      "      array[i].from_state(thestate);\n"
//      "  };\n\n",
//	    indextype->getsize(),	/* body of clear */
//	    indextype->getsize(),	/* body of undefine */
//	    indextype->getsize(),	/* body of reset */
//	    indextype->getsize()	/* body of to_state */
	    //      indextype->getsize()  /* body of from_state */
//	);

    /* compact print function */
    // Uli: print() function has to be used because of Undefined value
  /*  if (FALSE)			// (elementtype->issimple())
      fprintf(codefile,
	      "  void print()\n"
	      "  {\n"
	      "    cout << name << \"[]: \\t\";\n"
	      "    for (int i = 0; i < %d; i++)\n"
	      "      cout << array[i] << '\\t';\n"
	      "  cout << \"\\n\";\n" "  }\n\n", indextype->getsize());
    else
      fprintf(codefile,
	      "  void print()\n"
	      "  {\n"
	      "    for (int i = 0; i < %d; i++)\n"
	      "      array[i].print(); };\n\n", indextype->getsize());

    fprintf(codefile,
	    "  void print_diff(state *prevstate)\n"
	    "  {\n"
	    "    for (int i = 0; i < %d; i++)\n"
	    "      array[i].print_diff(prevstate);\n"
	    "  };\n", indextype->getsize());*/
    /*
       "  void print_diff(state *prevstate)\n"
       "  {\n"
       "    bool diff = FALSE;\n"
       "    for (int i = 0; i < %d; i++)\n"
       "      if (array[i] != array[i].get_value_from_state(prevstate))\n"
       "   diff = TRUE;\n"
       "    if (diff) {\n"
       "      cout << name << \":\\t\";\n"
       "      for (int i = 0; i < %d; i++)\n"
       "   cout << array[i] << '\\t';\n"
       "      cout << \"\\n\";\n"
       "    }\n"
       "  }\n",
       indextype->getright() - indextype->getleft() + 1, 
       indextype->getright() - indextype->getleft() + 1, 
       indextype->getright() - indextype->getleft() + 1);
     */

    /* end class definition */
  //  fprintf(codefile, "};\n\n");

    /* write the set_self function. */
  /*  fprintf(codefile,
	    "  void %s::set_self_ar( const char *n1, const char *n2, int os ) {\n"
	    "    if (n1 == NULL) {set_self(NULL, 0); return;}\n"
	    "    int l1 = strlen(n1), l2 = strlen(n2);\n"
	    "    strcpy( longname, n1 );\n"
	    "    longname[l1] = '[';\n"
	    "    strcpy( longname+l1+1, n2 );\n"
	    "    longname[l1+l2+1] = ']';\n"
	    "    longname[l1+l2+2] = 0;\n"
	    "    set_self( longname, os );\n"
	    "  };\n"
	    "  void %s::set_self_2( const char *n1, const char *n2, int os ) {\n"
	    "    if (n1 == NULL) {set_self(NULL, 0); return;}\n"
	    "    strcpy( longname, n1 );\n"
	    "    strcat( longname, n2 );\n"
	    "    set_self( longname, os );\n" "  };\n", mu_name, mu_name);
    switch (indextype->gettypeclass()) {
    case typedecl::Enum:
      fprintf(codefile,
	      "  void %s::set_self( const char *n, int os)\n"
	      "  {\n" "    int i=0;\n"
	      "    name = (char *)n;\n\n", mu_name);
      make_elt_with_enum(((enumtypedecl *) indextype)->getidvalues(),
			 indextype->getsize(),
			 elementtype->getbitsalloc());
      fprintf(codefile, "  }\n");
      break;
    case typedecl::Range:
      fprintf(codefile,
	      "void %s::set_self( const char *n, int os)\n"
	      "{\n"
	      "  char* s;\n"
	      "  name = (char *)n;\n"
	      "  for(int i = 0; i < %d; i++) {\n"*/
	      /* ANOTHER EVIL TSPRINTF! */
	      // Uli: I don't know who made the above comment, but it's 
	      //      really evil since the allocated memory is in many
	      //      cases hard to free (LABEL1)
        //      "    array[i].set_self_ar(n, s=tsprintf(\"%%d\",i + %d), i * %d + os);\n"
          //    "    delete[] s;\n"
            //  "  }\n"
             // "};\n",
 
    //      mu_name,  /* first line of format */
//	      indextype->getsize(),	/* for loop bound */
//	      indextype->getleft(),	/* 3rd arg to tsprintf */
//	      elementtype->getbitsalloc());	/* second arg to set_self */
  //    break;
  /*  case typedecl::Scalarset:
      fprintf(codefile,
	      "void %s::set_self( const char *n, int os)\n"
	      "  {\n" "    int i=0;\n"
	      "    name = (char *)n;\n\n", mu_name);
      make_elt_with_scalarset(((scalarsettypedecl *)
			       indextype)->getidvalues(),
			      indextype->getsize(),
			      elementtype->getbitsalloc());
      fprintf(codefile, "}\n");
      break;
    case typedecl::Union:
      fprintf(codefile,
	      "void %s::set_self( const char *n, int os)\n"
	      "  {\n" "    int i=0;\n"
	      "    name = (char *)n;\n\n", mu_name);
      make_elt_with_union(((uniontypedecl *) indextype)->getunionmembers(),
			  elementtype->getbitsalloc());
      fprintf(codefile, "}\n");
      break;
    case typedecl::Array:
    case typedecl::Record:
    case typedecl::Error_type:
    default:
      // the error should already be flaged. 
      break;
    }*/

 //   fprintf(codefile,
	    /* DELETE PROBLEM */// Uli: no delete since there in no new
//	    "%s::~%s()\n" "{\n"
//	    "  if (name) delete [] name;\n"
	    // "  for(int i = 0; i < %d; i++)\n"
	    // "    delete[ OLD_GPP(strlen(array[i].name) +1) ] array[i].name; // Should be delete[] \n"
//	    "}\n", mu_name, mu_name, indextype->getsize());

  //  fprintf(codefile, "/*** end array declaration ***/\n");
  //  fprintf(codefile, "%s %s_undefined_var;\n\n", mu_name, mu_name);

  }
  return "ERROR!";
}

/********************
  code for multisettypedecl
 ********************/
 //meiyong
const char *multisetidtypedecl::generate_decl()
{
  return "ERROR!";
}
 //meiyong
const char *multisettypedecl::generate_decl()
{
  if (!declared) {

    /* make up a name for a new class, and a mu_name to be output. */
    if (name == NULL) {
      name = tsprintf("_multiset_%d", tNum);
      mu_name = tsprintf("mu_%s", name);
    }

    fprintf(codefile, "/*** begin multiset declaration ***/\n");

    // declare multiest id
    fprintf(codefile, "class %s_id: public %s\n" "{\n" " public:\n" "  inline int operator=(int val) { return value(val); };\n" "  inline int operator=(const %s_id& val) {" " return value(val.value()); };\n"	// Uli: return added
	    "  inline operator int() const { return value(); };\n" "  %s_id () : %s(0,%d,0) {};\n" "  %s_id (int val) : %s(0,%d,0, \"Parameter or function result.\",0) {operator=(val); };\n" "  char * Name() { return tsprintf(\"%%d\", value()); };\n" "};\n", mu_name, mu_type,	// class
	    mu_name,		// operator=
	    mu_name, mu_type, maximum_size - 1,	// constructor
	    mu_name, mu_type, maximum_size - 1	// constructor
	);

    /* declare class with set_self, constructor and destructor */
    fprintf(codefile, "class %s\n" "{\n" " public:\n" "  %s array[ %d ];\n" "  int max_size;\n" "  int current_size;\n" " public:\n" "  mu_0_boolean valid[ %d ];\n" "  char *name;\n" "  char longname[BUFFER_SIZE/4];\n" "  void set_self( const char *n, int os);\n" "  void set_self_2( const char *n, const char *n2, int os);\n" "  void set_self_ar( const char *n, const char *n2, int os);\n" "  %s (const char *n, int os): current_size(0), max_size(0) { set_self(n, os); };\n" "  %s ( void ): current_size(0), max_size(0) {};\n" "  virtual ~%s ();\n", mu_name,	/* class name */
	    elementtype->generate_code(),	/* array elt type */
	    maximum_size,	/* array size */
	    maximum_size,	/* array size */
	    mu_name,		/* name for first constructor */
	    /* maximum_size,  /* max current size */
	    /* CeilLog2(maximum_size+2),  /* max current size */
	    mu_name,		/* name for second constructor */
	    /* maximum_size,  /* max current size */
	    /* CeilLog2(maximum_size+2),  /* max current size */
	    mu_name);		/* destructor name */

    /* no range-checked operator [] */
    fprintf(codefile,
	    "  %s& operator[] (int index) /* const */\n"
	    "  {\n"
	    "    if ((index >= 0) && (index <= %d) && valid[index].value())\n"
	    "      return array[ index ];\n"
	    "    else {\n"
	    "      Error.Error(\"Internal Error::%%d not in index range of %%s.\", index, name);\n"
	    "      return array[0];\n"
	    "    }\n"
	    "  };\n", elementtype->generate_code(), maximum_size - 1);

    /* and an operator =. */
    generate_assign();
/*    if (elementtype->issimple()) 
      fprintf(codefile, 
	  "  %s& operator= (const %s& from)\n"
	  "  {\n"
	  "    int i;\n"
	  "    for (i = 0; i < %d; i++)\n"
	  "      if (from.array[i].isundefined() )\n"
	  "	array[i].undefine();\n"
	  "      else\n"
	  "	array[i] = from.array[i];\n"
	  "    for (i = 0; i < %d; i++)\n"
	  "      valid[i].value(from.valid[i].value());\n"
	  "    current_size = from.get_current_size();\n"
	  "    return *this;\n"
	  "  }\n\n",
	  mu_name,
	  mu_name,
	  maximum_size,
	  maximum_size);
    else
      fprintf(codefile, 
	  "  %s& operator= (const %s& from)\n"
	  "  {\n"
	  "    for (int i = 0; i < %d; i++)\n"
	  "      {\n"
	  "	array[i] = from.array[i];\n"
	  "	valid[i] = from.valid[i];\n"
	  "      }\n"
	  "    current_size = from.get_current_size();\n"
	  "    return *this;\n"
	  "  }\n\n",
	  mu_name,
	  mu_name,
	  maximum_size); 
*/

    /* comparsion function */
    fprintf(codefile,
	    "friend int CompareWeight(%s& a, %s& b)\n"
	    "  {\n"
	    "    return 0;\n" "  }\n", mu_name, mu_name, maximum_size);

    /* comparsion function */
    fprintf(codefile,
	    "friend int Compare(%s& a, %s& b)\n"
	    "  {\n"
	    "    int w;\n"
	    "    for (int i=0; i<%d; i++) {\n"
	    "      w = Compare(a.array[i], b.array[i]);\n"
	    "      if (w!=0) return w;\n"
	    "    }\n"
	    "    return 0;\n" "  }\n", mu_name, mu_name, maximum_size);

    /* declare permute() */
    theprog->symmetry.generate_symmetry_function_decl();

    /* standard functions:
     * clear(), undefine(), to_state(), from_state(). */
    fprintf(codefile,
	    "  void clear() { for (int i = 0; i < %d; i++) { array[i].undefine(); valid[i].value(FALSE); } current_size = 0; };\n\n"
	    "  void undefine() { for (int i = 0; i < %d; i++) { array[i].undefine(); valid[i].value(FALSE); } current_size = 0; };\n\n"
	    "  void reset() { for (int i = 0; i < %d; i++) { array[i].undefine(); valid[i].value(FALSE); } current_size = 0; };\n\n"
	    "  void to_state(state *thestate)\n"
	    "  {\n"
	    "    for (int i = 0; i < %d; i++)\n"
	    "     {\n"
	    "       array[i].to_state(thestate);\n"
	    "       valid[i].to_state(thestate);\n" "     }\n" "  };\n\n"
//       "  void from_state(state *thestate)\n"
//       "  {\n"
//       "    int i;\n"
//       "    for (i = 0; i < %d; i++)\n"
//       "     {\n"
//       "      array[i].from_state(thestate);\n"
//       "      valid[i].from_state(thestate);\n"
//       "     }\n"
//       "  };\n\n"
	    "  int get_current_size() const" "  {\n" "    int tmp = 0;\n" "    for (int i = 0; i < %d; i++)\n" "      if (valid[i].value()) tmp++;\n" "    return tmp;\n" "  };\n\n " "  void update_size()\n" "  {\n" "    current_size = 0;\n" "    for (int i = 0; i < %d; i++)\n" "      if (valid[i].value()) current_size++;\n" "    if (max_size<current_size) max_size = current_size;\n" "  };\n\n ", maximum_size,	/* body of clear */
	    maximum_size,	/* body of undefine */
	    maximum_size,	/* body of reset */
	    maximum_size,	/* body of to_state */
//       maximum_size, /* body of from_state */
	    maximum_size,	/* body of get_current_size */
	    maximum_size	/* body of update_size */
	);

    fprintf(codefile, "  inline bool in(const %s_id& id)\n"
	    // "  { if (current_size>id) return TRUE; else return FALSE; }\n",
	    "  { return valid[(int)id].value(); }\n",	// Uli 10-98
	    mu_name);

    /* compact print function */
    // Uli: print() function has to be used because of Undefined value
    if (FALSE)			// (elementtype->issimple())
      fprintf(codefile, "  void print()\n" "  {\n" "    cout << name << \"[]: \\t\";\n" "    for (int i = 0; i < %d; i++)\n" "      if (valid[i].value())\n" "	cout << array[i] << '\\t';\n" "      else\n" "	cout << '-' << '\\t';\n" "  cout << \"\\n\";\n" "  }\n\n", maximum_size	/* for */
	  );
    else
      fprintf(codefile, "  void print()\n" "  {\n" "    for (int i = 0; i < %d; i++)\n" "      if (valid[i].value())\n" "	array[i].print();\n" "  };\n\n", maximum_size	/* for */
	  );

    fprintf(codefile,
	    "  void print_statistic()\n"
	    "  {\n"
	    "    cout << \"\tThe maximum size for the multiset \\\"\" \n"
	    "	 << name << \"\\\" is: \" << max_size << \".\\n\"; \n"
	    "  };\n");
    fprintf(codefile,
	    "  void print_diff(state *prevstate)\n"
	    "  {\n"
	    "    bool prevvalid;\n"
	    "    static state temp;\n"
	    "    StateCopy(&temp, workingstate);\n"
	    "    for (int i = 0; i < %d; i++)\n"
	    "      {\n"
	    "	StateCopy(workingstate, prevstate);\n"
	    "	prevvalid = valid[i].value();\n"
	    "	StateCopy(workingstate, &temp);\n"
	    "	if (prevvalid && !valid[i].value())\n"
	    "	  array[i].print();\n"
	    "	if (!prevvalid && valid[i].value())\n"
	    "	  array[i].print();\n"
	    "	if (prevvalid && valid[i].value())\n"
	    "	  array[i].print_diff(prevstate);\n"
	    "      }\n" "  };\n", maximum_size);

    fprintf(codefile,
	    "  int multisetadd(const %s &element)\n"
	    "  {\n"
	    "    update_size();\n"
	    "    if (current_size >= %d) Error.Error(\"Maximum size of MultiSet (%%s) exceeded.\",name);\n"
	    "    int i;\n"
	    "    for (i = 0; i < %d; i++)\n"
	    "      if (!valid[i].value())\n"
	    "	{\n"
	    "	  array[i] = element;\n"
	    "	  valid[i].value(TRUE);\n"
	    "	  break;\n"
	    "	}\n"
	    "    current_size++;\n"
	    "    return i;\n"
	    "  };\n",
	    elementtype->generate_code(), maximum_size, maximum_size);
    fprintf(codefile, "  void multisetremove(const %s_id &id)\n" "  {\n" "    update_size();\n" "    if (!valid[(int)id].value()) Error.Error(\"Internal Error: Illegal Multiset element selected.\");\n"	// Uli 10-98
	    "    valid[(int)id].value(FALSE);\n"
	    "    array[(int)id].undefine();\n" "    current_size--;\n"
	    // "    id.undefine();\n"   // Uli: not necessary since valid[]
	    //      is checked
	    "  };\n", mu_name);

    fprintf(codefile,
	    "  void MultisetSort()\n"
	    "  {\n"
	    "    static %s temp;\n"
	    "\n"
	    "    // compact\n"
	    "    int i,j;\n"
	    "    for (i = 0, j = 0; i < %d; i++)\n"
	    "      if (valid[i].value())\n"
	    "	{\n"
	    "	  if (j!=i)\n"
	    "	    array[j++] = array[i];\n"
	    "	  else\n"
	    "	    j++;\n"
	    "	}\n"
	    "    if (j != current_size) current_size = j;\n"
	    "    for (i = j; i < %d; i++)\n"
	    "      array[i].undefine();\n"
	    "    for (i = 0; i < j; i++)\n"
	    "      valid[i].value(TRUE);\n"
	    "    for (i = j; i < %d; i++)\n"
	    "      valid[i].value(FALSE);\n"
	    "\n"
	    "    // bubble sort\n"
	    "    for (i = 0; i < current_size; i++)\n"
	    "      for (j = i+1; j < current_size; j++)\n"
	    "	if (Compare(array[i],array[j])>0)\n"
	    "	  {\n"
	    "	    temp = array[i];\n"
	    "	    array[i] = array[j];\n"
	    "	    array[j] = temp;\n"
	    "	  }\n"
	    "  }\n",
	    elementtype->generate_code
	    (), maximum_size, maximum_size, maximum_size);


    // declare procedures for all multisetcount
    if (msclist != NULL)
      msclist->generate_decl(this);

    // declare procedures for all multisetremove
    if (msrlist != NULL)
      msrlist->generate_decl(this);


    /* end class definition */
    fprintf(codefile, "};\n\n");

    /* write the set_self functions. */
    fprintf(codefile,
	    "  void %s::set_self_ar( const char *n1, const char *n2, int os ) {\n"
	    "    if (n1 == NULL) {set_self(NULL, 0); return;}\n"
	    "    int l1 = strlen(n1), l2 = strlen(n2);\n"
	    "    strcpy( longname, n1 );\n"
	    "    longname[l1] = '[';\n"
	    "    strcpy( longname+l1+1, n2 );\n"
	    "    longname[l1+l2+1] = ']';\n"
	    "    longname[l1+l2+2] = 0;\n"
	    "    set_self( longname, os );\n"
	    "  };\n"
	    "  void %s::set_self_2( const char *n1, const char *n2, int os ) {\n"
	    "    if (n1 == NULL) {set_self(NULL, 0); return;}\n"
	    "    strcpy( longname, n1 );\n"
	    "    strcat( longname, n2 );\n"
	    "    set_self( longname, os );\n" "  };\n", mu_name, mu_name);
    fprintf(codefile,
	    "void %s::set_self( const char *n, int os)\n"
	    "{\n"
	    "  int i,k;\n" 
	    "  name = (char *)n;\n" 
	    "  for(i = 0; i < %d; i++)\n"
	    /* ANOTHER EVIL TSPRINTF! */
	    // Uli: this might have to be changed in a similar fashion as
	    //      at LABEL1
	    "    if (n) array[i].set_self(tsprintf(\"%%s{%%d}\", n,i), i * %d + os); else array[i].set_self(NULL, 0);\n" "  k = os + i * %d;\n" "  for(i = 0; i < %d; i++)\n", mu_name,	/* first line of format */
	    maximum_size,	/* for loop bound */
	    elementtype->getbitsalloc(),	/* second arg to set_self */
	    elementtype->getbitsalloc(),	/* second arg to set_self */
	    maximum_size);	/* for loop bound */
    if (!args->no_compression)
      fprintf(codefile,
	      "    valid[i].set_self(\"\", i * 2 + k);\n" "};\n");
    else
      fprintf(codefile,
	      "    valid[i].set_self(\"\", i * 8 + k);\n" "};\n");

    fprintf(codefile,
	    /* DELETE PROBLEM */// Uli: no delete since there in no new
	    "%s::~%s()\n" "{\n"
//	    "  if (name) delete [] name;\n"
	    // "  for(int i = 0; i < %d; i++)\n"
	    // "    delete[ OLD_GPP(strlen(array[i].name) +1) ] array[i].name; // Should be delete[] \n"
	    // "  delete[ OLD_GPP(strlen(current_size[i].name) +1) ] current_size.name; // Should be delete[] \n"
	    "}\n", mu_name, mu_name, maximum_size);

    // declare procedures for all multisetcount
    if (msclist != NULL)
      msclist->generate_procedure();

    // declare procedures for all multisetremove
    if (msrlist != NULL)
      msrlist->generate_procedure();

    fprintf(codefile, "/*** end multiset declaration ***/\n");
    fprintf(codefile, "%s %s_undefined_var;\n\n", mu_name, mu_name);
    declared = TRUE;
  }
  return "ERROR!";
}
 //meiyong
void multisetcountlist::generate_decl(multisettypedecl * mset)
{
  if (next != NULL)
    next->generate_decl(mset);
  mscount->generate_decl(mset);
}
 //meiyong
void multisetremovelist::generate_decl(multisettypedecl * mset)
{
  if (next != NULL)
    next->generate_decl(mset);
  msremove->generate_decl(mset);
}
 //meiyong
void multisetcountlist::generate_procedure()
{
  if (next != NULL)
    next->generate_procedure();
  mscount->generate_procedure();
}
 //meiyong
void multisetremovelist::generate_procedure()
{
  if (next != NULL)
    next->generate_procedure();
  msremove->generate_procedure();
}

 /********************
   code for recordtypedecl
  ********************/
//ctf
const char *recordtypedecl::generate_decl()
{
  ste *f;
  if (!declared) {
    if (name == NULL) {
      name = tsprintf("record_%nd", tNum);
      //mu_name = tsprintf("%s", name);
    };
fprintf(codefile, "\n");
writeblank();
fprintf(codefile, "%s : record\n",name);
blankadd();
for (f = fields; f != NULL; f = f->getnext()){
    	writeblank();
		fprintf(codefile, "%s : %s;\n",
	      f->getvalue()->generate_code(),f->getvalue()->gettype()->generate_code());
}
blankred();
//fseek(codefile,0, SEEK_CUR);
writeblank();
fprintf(codefile, "end;\n");
    declared = TRUE;
  }
  return "ERROR!";
}

 /********************
   code for scalarsettypedecl
   ********************/
   //add926
void make_scalarset_idvalues(ste * idvalues, int size, bool named)
{
 /* if (size > 1)
    make_scalarset_idvalues(idvalues->next, size - 1, named);
  if (named) {
    fprintf(codefile, "\"%s\",", idvalues->getname()->getname());
  } else {
    char *c = idvalues->getname()->getname();
    while (*c != '_')
      c++;
    c++;
    fprintf(codefile, ",\"%s\"", c);
  }
  */
  fprintf(codefile, "%s, ",idvalues->getname()->getname());
}
   //add 26
const char *scalarsettypedecl::generate_decl()
{
 
  if (!declared)
	{
		if (name == NULL) 
		{
		  name = tsprintf("_scalarset_%d", tNum);
		  mu_name = tsprintf("mu_%s", name);
		}
		fprintf(codefile, "%s : scalarset(%d);\n",name,right-left+1);
		declared = TRUE;
	}
  return "ERROR!";
}

/********************
  code for uniontypedecl
  ********************/
  //add926
void make_union_idvalues(stelist * unionmembers)
{
  if (unionmembers->next != NULL)
    make_union_idvalues(unionmembers->next);

  if (((typedecl *) unionmembers->s->getvalue())->gettypeclass() ==
      typedecl::Scalarset)
	  {
		  /*make_scalarset_idvalues(((scalarsettypedecl *)
			     unionmembers->s->getvalue())->getidvalues(),
			    unionmembers->s->getvalue()->getsize(), TRUE);
				*/
			fprintf(codefile, "%s, ", unionmembers->s->getname()->getname());	
				
	  }
  else if (((typedecl *) unionmembers->s->getvalue())->gettypeclass() ==
	   typedecl::Enum)
	   {
		   fprintf(codefile, "enum{");
			make_enum_idvalues(((enumtypedecl *)
					unionmembers->s->getvalue())->getidvalues(),
					   (typedecl *) unionmembers->s->getvalue());
			fseek(codefile,-1, SEEK_CUR);		   
		   fprintf(codefile, "}, ");		   
	   }
  else
    Error.Error("funny element in union");
}

// int make_assign_union_values(stelist * unionmembers)
// {
//   int base = 0;
//   if (unionmembers->next != NULL)
//       base = make_assign_union_values(unionmembers->next);
//   
//   typedecl *t= (typedecl *) unionmembers->s->getvalue();
//   fprintf(codefile,
//      "    if ( ( val >= %d ) && ( val <= %d ) ) {\n"
//   //       "      defined = TRUE;\n"
//      "      initialized = TRUE;\n"
//      "      return value(val - %d);\n"
//      "    }\n",
//      t->getleft(),
//      t->getright(),
//      t->getleft() - base);
//   return base + t->getsize();
// }  
//meiyong
int make_union_indexval(stelist * unionmembers)
{
  int base = 0;
  if (unionmembers->next != NULL)
    base = make_union_indexval(unionmembers->next);

  typedecl *t = (typedecl *) unionmembers->s->getvalue();
  fprintf(codefile,
	  "    if ((value() >= %d) && (value() <= %d))"
	  " return (value() - %d);\n",
	  t->getleft(), t->getright(), t->getleft() - base);
  return base + t->getsize();
}
//meiyong
int make_bit_compacted_value_assign(stelist * unionmembers)
{
  int base = 0;
  if (unionmembers->next != NULL)
    base = make_bit_compacted_value_assign(unionmembers->next);

  typedecl *t = (typedecl *) unionmembers->s->getvalue();
  fprintf(codefile,
	  "    if ((val >= %d) && (val <= %d))"
	  " return (mu__byte::value(val-%d)+%d);\n",
	  t->getleft(),
	  t->getright(), t->getleft() - base, t->getleft() - base);
  return base + t->getsize();
}
//meiyong
int make_union_unionassign(stelist * unionmembers)
{
  int base = 0;
  if (unionmembers->next != NULL)
    base = make_union_unionassign(unionmembers->next);

  typedecl *t = (typedecl *) unionmembers->s->getvalue();
  fprintf(codefile,
	  "    if (val >= %d && val <= %d) return value(val+%d);\n",
	  // Uli: return added
	  base, base + t->getsize() - 1, t->getleft() - base);
  return base + t->getsize();
}
//meiyong
int make_bit_compacted_value(stelist * unionmembers)
{
  int base = 0;
  if (unionmembers->next != NULL)
    base = make_bit_compacted_value(unionmembers->next);

  typedecl *t = (typedecl *) unionmembers->s->getvalue();
  fprintf(codefile,
	  "    if (val <= %d) return val+%d;\n",
	  base + t->getsize() - 1, t->getleft() - base);
  return base + t->getsize();
}

// int make_reference_union_values(stelist * unionmembers)
// {
//   int base = 0;
//   if (unionmembers->next != NULL)
//       base = make_reference_union_values(unionmembers->next);
//   typedecl *t= (typedecl *) unionmembers->s->getvalue();
//   fprintf(codefile,
//      "    if ( ( val >= %d ) && ( val <= %d ) )\n"
//      "      return val + %d;\n",
//      base,
//      base + t->getsize() - 1,
//      t->getleft() - base);
//   return base + t->getsize();
// }  
//add 926
const char *uniontypedecl::generate_decl()
{

   if (!declared) 
   {
		if (name == NULL) 
		{
		  name = tsprintf("_union_%d", tNum);
		}
		fprintf(codefile, "\n");
		writeblank();
		fprintf(codefile, "%s : union {",name);
		make_union_idvalues(unionmembers);
		fseek(codefile,-2, SEEK_CUR);
		fprintf(codefile, "};\n",name);
		declared = TRUE;
	}
	return "ERROR!";
}

/********************
  code for constdecl
 ********************/
const char *constdecl::generate_decl()
{
  if (!declared) {
    //if (type_equal(type, realtype))	// AP: real constant's declaration
    //fprintf(codefile, "const double %s = %+le;\n", mu_name, rvalue);
    //else
      if(type->getleft() == 0)
	  {
		  fprintf(codefile, "%s : %d;\n",name, value);
	  }
    declared = TRUE;
  }
  return "ERROR!";
}


/********************
  code for vardecl
 ********************/
 //ctf
 int num=0;
const char *vardecl::generate_decl()
{
	if(lflag == 1)
	{
		declared = 0;
	}
if (!declared) {
fprintf(codefile, "%s : %s;\n",
generate_code(), gettype()->name);
num++;
       
    declared = TRUE;
  }

  return "ERROR!";
}

/********************
  code for aliasdecl
 ********************/
//ctf zanshimeiyong
const char *aliasdecl::generate_decl()
{
  if (!declared) {
    if (!ref->islvalue() && ref->gettype()->issimple()) {
      if (type_equal(ref->gettype(), realtype))
	fprintf(codefile,
		"  const double %s = %s;\n", mu_name,
		ref->generate_code());
      else
	fprintf(codefile,
		/* BUG: BOGUS CONST INT */
		/* is this fixed adding  ref->gettype()->issimple() */
		"  const int %s = %s;\n", mu_name, ref->generate_code());
    } else 
	{
      fprintf(codefile, "%s : ",name);
		  ref->generate_code();
    }
  }
  return "ERROR!";
}

/********************
  code for choosedecl
 ********************/
 //meiyong
const char *choosedecl::generate_decl()
/* Should never actually get called. */
{
  Error.Error
      ("Internal: choosedecl::generate_decl() should not have been called.");
  return "ERROR!";
}

/********************
  code for quantdecl
 ********************/
 //ctf 
const char *quantdecl::generate_decl()
/* Should never actually get called. */
{
  Error.Error
      ("Internal: quantdecl::generate_decl() should not have been called.");
  return "ERROR!";
}
int make_f;
char *f=" ";
void quantdecl::make_for()
{
  if(make_f==1){
    fprintf(codefile,"forall %s : %s do",name,type->name);forallnum++;
  }
  else if(make_f == 10)
  {
    fprintf(codefile,"exists %s : %s do",name,type->name);forallnum++;
  }
  else
  { 
		fprintf(codefile,"for %s : %s do\n",name,type->name);forallnum++;
  }
  declared = TRUE;
}

/********************
  code for parameter
 ********************/
 //meiyong set
const char *param::generate_decl()
{
  Error.Error("Internal: param::generate_decl()");
  return "ERROR!";
}

const char *varparam::generate_decl()
{
  if (!declared) {
    fprintf(codefile, "%s& %s", type->generate_code(), mu_name);
    declared = TRUE;
  }
  return "ERROR!";
}

const char *valparam::generate_decl()
{
  if (!declared) {
    fprintf(codefile, "%s %s", type->generate_code(), mu_name);
    declared = TRUE;
  }
  return "ERROR!";
}

/* We have to do some skanky workarounds here;
 * CC won't let us declare our smart operator [] as
 * const, but if we don't, we can't use operator [] for
 * for a constant array.  So we work around this by
 * dropping the constant for a const array parameter.
 *
 * Furthermore, since a const record can include a const
 * array, we need to drop the const for records, too.
 * This is okay, since we\'ve checked in the Murphi
 * semantic-checking, and we know that this array isn\'t
 * modified, and we know that no conversion will be involved,
 * since Murphi doesn\'t allow conversion among aggregate
 * types.
 *
 * We do need the const for simple types, since otherwise,
 * we won\'t get any automatic conversion from C++.
 */
const char *constparam::generate_decl()
{
  if (!declared) {
    if (type->issimple())
      fprintf(codefile, "const %s& %s", type->generate_code(), mu_name);
    else
      fprintf(codefile, "%s& %s", type->generate_code(), mu_name);

    declared = TRUE;
  }
  return "ERROR!";
}

/********************
  code for procdecl
 ********************/
 //meiyong
const char *procdecl::generate_decl()
{
  if (!declared) {
    if (!extern_def) {
      /* the declaration. */
      fprintf(codefile, "void %s(", mu_name);

      /* formal parameter list */
      for (ste * p = params; p != NULL; p = p->getnext()) {
	p->getvalue()->generate_decl();
	if (p->getnext() == NULL)
	  break;
	fprintf(codefile, ", ");
      }
      fprintf(codefile, ")\n" "{\n");

      /* the locals. */
      decls->generate_decls();

      /* the statements. */
      for (stmt * s = body; s != NULL; s = s->next) {
	s->generate_code();
      }

      fprintf(codefile, "};\n");

      fprintf(codefile, "/*** end procedure declaration ***/\n\n");

      declared = TRUE;
    } else if (include_file_ext != NULL)
      fprintf(codefile, "\n#include \"%s\"\n\n", include_file_ext);
  }
  return "ERROR!";
}

/********************
  code for funcdecl
 ********************/

/* BUG: check for return everywhere? */
/* Norris: fixed by adding an error at the very end... so that user will
   know and go back and fix the function */
 //meiyong
const char *funcdecl::generate_decl()
{
  if (!declared) {
    if (!extern_def) {
      /* the declaration. */
      fprintf(codefile, "%s %s(", returntype->generate_code(), mu_name);
      /* formal parameters */
      for (ste * p = params; p != NULL; p = p->getnext()) {
	p->getvalue()->generate_decl();
	if (p->getnext() == NULL)
	  break;
	fprintf(codefile, ",");
      }
      fprintf(codefile, ")\n" "{\n");

      /* the locals. */
      decls->generate_decls();

      /* the statements. */
      for (stmt * s = body; s != NULL; s = s->next) {
	s->generate_code();
      }

      fprintf(codefile,
	      "	Error.Error(\"The end of function %s reached without returning values.\");\n",
	      name);

      fprintf(codefile, "};\n");

      fprintf(codefile, "/*** end function declaration ***/\n\n");

      declared = TRUE;
    } else if (include_file_ext != NULL)
      fprintf(codefile, "\n#include \"%s\"\n\n", include_file_ext);
  }
  return "ERROR!";
}

/********************
  code related to expression
  -- 
  -- expr
  -- boolexpr
  -- -- notexpr
  -- -- equalexpr
  -- -- compexpr
  -- arithexpr
  -- -- unexpr
  -- -- mulexpr
  -- condexpr
  -- quantexpr
  -- designator
  -- exprlist
  -- funccall
 ********************/

/********************
  code for expr
 ********************/
const char *expr::generate_code()
{
  if (constval)
  {
	 // if (type_equal(type, realtype))
	 // {
	//	  fprintf(codefile,"%le", rvalue);
    //  return "ERROR!";	// AP: value of a real constant
	//  }
    //else
	//{
		fprintf(codefile,"%d", value);
      return "ERROR!";
	//}
  }
  else {
    Error.Error
	("Internal: a basic expression that wasn't a constant called expr::generate_code().");
    return "ERROR!";
  }
}

//IM: for math functions
//meiyong
const char *mathexpr::generate_code()
{
  if (constval)
    return tsprintf("%le", rvalue);
  switch (getfuntype()) {
  case mylog:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", log(arg1->getrvalue()));
	else
	  return tsprintf("%le", log(arg1->getvalue()));
      } else
	return tsprintf("log((double)%s)", arg1->generate_code());
      break;
    }
  case mylog10:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", log10(arg1->getrvalue()));
	else
	  return tsprintf("%le", log10(arg1->getvalue()));
      } else
	return tsprintf("log10((double)%s)", arg1->generate_code());
      break;
    }
  case myexp:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", exp(arg1->getrvalue()));
	else
	  return tsprintf("%le", exp(arg1->getvalue()));
      } else
	return tsprintf("exp((double)%s)", arg1->generate_code());
      break;
    }
  case mysin:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", sin(arg1->getrvalue()));
	else
	  return tsprintf("%le", sin(arg1->getvalue()));
      } else
	return tsprintf("sin((double)%s)", arg1->generate_code());
      break;
    }
  case mycos:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", cos(arg1->getrvalue()));
	else
	  return tsprintf("%le", cos(arg1->getvalue()));
      } else
	return tsprintf("cos((double)%s)", arg1->generate_code());
      break;
    }
  case mytan:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", tan(arg1->getrvalue()));
	else
	  return tsprintf("%le", tan(arg1->getvalue()));
      } else
	return tsprintf("tan((double)%s)", arg1->generate_code());
      break;
    }
  case myfabs:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", fabs(arg1->getrvalue()));
	else
	  return tsprintf("%le", fabs(arg1->getvalue()));
      } else
	return tsprintf("fabs((double)%s)", arg1->generate_code());
      break;
    }
  case myfloor:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", floor(arg1->getrvalue()));
	else
	  return tsprintf("%le", floor(arg1->getvalue()));
      } else
	return tsprintf("floor((double)%s)", arg1->generate_code());
      break;
    }
  case myceil:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", ceil(arg1->getrvalue()));
	else
	  return tsprintf("%le", ceil(arg1->getvalue()));
      } else
	return tsprintf("ceil((double)%s)", arg1->generate_code());
      break;
    }
  case mysqrt:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", sqrt(arg1->getrvalue()));
	else
	  return tsprintf("%le", sqrt(arg1->getvalue()));
      } else
	return tsprintf("sqrt((double)%s)", arg1->generate_code());
      break;
    }
  case myfmod:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype)) {
	  if (type_equal(arg2->gettype(), realtype))
	    return tsprintf("%le",
			    fmod(arg1->getrvalue(), arg2->getrvalue()));
	  else
	    return tsprintf("%le",
			    fmod(arg1->getrvalue(), arg2->getvalue()));
	} else {
	  if (type_equal(arg2->gettype(), realtype))
	    return tsprintf("%le",
			    fmod(arg1->getvalue(), arg2->getrvalue()));
	  else
	    return tsprintf("%le",
			    fmod(arg1->getvalue(), arg2->getvalue()));
	}
      } else
	return tsprintf("fmod((double)%s,(double)%s)",
			arg1->generate_code(), arg2->generate_code());
      break;
    }
  case mypow:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype)) {
	  if (type_equal(arg2->gettype(), realtype))
	    return tsprintf("%le",
			    pow(arg1->getrvalue(), arg2->getrvalue()));
	  else
	    return tsprintf("%le",
			    pow(arg1->getrvalue(), arg2->getvalue()));
	} else {
	  if (type_equal(arg2->gettype(), realtype))
	    return tsprintf("%le",
			    pow(arg1->getvalue(), arg2->getrvalue()));
	  else
	    return tsprintf("%le",
			    pow(arg1->getvalue(), arg2->getvalue()));
	}
      } else
	return tsprintf("pow((double)%s,(double)%s)",
			arg1->generate_code(), arg2->generate_code());
      break;
    }
  case myasin:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", asin(arg1->getrvalue()));
	else
	  return tsprintf("%le", asin(arg1->getvalue()));
      } else
	return tsprintf("asin((double)%s)", arg1->generate_code());
      break;
    }
  case myacos:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", acos(arg1->getrvalue()));
	else
	  return tsprintf("%le", acos(arg1->getvalue()));
      } else
	return tsprintf("acos((double)%s)", arg1->generate_code());
      break;
    }
  case myatan:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", atan(arg1->getrvalue()));
	else
	  return tsprintf("%le", atan(arg1->getvalue()));
      } else
	return tsprintf("atan((double)%s)", arg1->generate_code());
      break;
    }
  case mysinh:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", sinh(arg1->getrvalue()));
	else
	  return tsprintf("%le", sinh(arg1->getvalue()));
      } else
	return tsprintf("sinh((double)%s)", arg1->generate_code());
      break;
    }
  case mycosh:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", cosh(arg1->getrvalue()));
	else
	  return tsprintf("%le", cosh(arg1->getvalue()));
      } else
	return tsprintf("cosh((double)%s)", arg1->generate_code());
      break;
    }
  case mytanh:
    {
      if (constval) {
	if (type_equal(arg1->gettype(), realtype))
	  return tsprintf("%le", tanh(arg1->getrvalue()));
	else
	  return tsprintf("%le", tanh(arg1->getvalue()));
      } else
	return tsprintf("tanh((double)%s)", arg1->generate_code());
      break;
    }
  }
}

/********************
  code for boolexpr
 ********************/
const char *boolexpr::generate_code()
{
	if((ruleflag != 1 | formark ==1)&condflag == 0)
	{
		if (constval)
			return tsprintf("%d", value);
		else {
			int num = new_int();
			char *temp = tsprintf("boolexpr_n%d", num);
		// fprintf(codefile, "bool %s;\n", temp);
		
			switch (op) {
			case IMPLIES:
			fprintf(codefile,"(");
		left->generate_code();
		fprintf(codefile," ->\n");
		writeblank();
		right->generate_code();
		fprintf(codefile,")");  
			  break;
			case '|':
		fprintf(codefile,"(");       
		left->generate_code();
		fprintf(codefile," |\n");
		writeblank();
		right->generate_code();
		fprintf(codefile,")");   

			  break;
			case '&':
		fprintf(codefile,"(");             
		left->generate_code();
		fprintf(codefile," &\n");
		writeblank();
		right->generate_code();
		fprintf(codefile,")");   

			  break;
			default:
			  Error.Error
			  ("Internal: funky value for op in boolexpr::generate_code()");
			  return "ERROR!";
			  break;
			}
		  }
	}
	else if((formark ==1)&(ruleflag == 1))
	{
				if (constval)
			return tsprintf("%d", value);
		else {
			int num = new_int();
			char *temp = tsprintf("boolexpr_n%d", num);
		// fprintf(codefile, "bool %s;\n", temp);
		
			switch (op) {
			case IMPLIES:
			//fprintf(codefile,"("); 
		left->generate_code();
		fprintf(codefile," ->\n");
		andflag = 1;
		right->generate_code();
		andflag =0;
		//fprintf(codefile,")");  
			  break;
			case '|':
		//fprintf(codefile,"(");       
		left->generate_code();
		fprintf(codefile," |\n");
		andflag = 1;
		right->generate_code();
		andflag = 0;
		//fprintf(codefile,")");   

			  break;
			case '&':
		//fprintf(codefile,"(");             
		left->generate_code();
		fprintf(codefile," &\n");
		andflag = 1;
		right->generate_code();
		andflag = 0;
		//fprintf(codefile,")");   

			  break;
			default:
			  Error.Error
			  ("Internal: funky value for op in boolexpr::generate_code()");
			  return "ERROR!";
			  break;
			}
		  }
	}
	else 
	{
		if (constval)
			return tsprintf("%d", value);
		else {
			int num = new_int();
			char *temp = tsprintf("boolexpr_n%d", num);
		// fprintf(codefile, "bool %s;\n", temp);
		
			switch (op) {
			case IMPLIES:
			if(flagor == 1)
			{
				fprintf(codefile,"!");       
				left->generate_code();
				//fprintf(codefile,"");  	
			}
			else if(flagor ==0)
			{
				//fprintf(codefile,"(");       
				right->generate_code();
				//fprintf(codefile,")");  
			}
			else
			{}

			  break;
			  
			case '|':
			if(flagor == 1)
			{
				//fprintf(codefile,"(");       
				right->generate_code();
				//fprintf(codefile,")");  	
			}
			else if(flagor ==0)
			{
				//fprintf(codefile,"(");       
				left->generate_code();
				//fprintf(codefile,")");  
			}
			else
			{}

			  break;
			case '&':
		//fprintf(codefile,"(");
		andflag = 1;
		left->generate_code();
		andflag = 0;
		fprintf(codefile," &\n");
		andflag = 1;
		right->generate_code();
		andflag = 0;
		//fprintf(codefile,")");   

			  break;
			default:
			  Error.Error
			  ("Internal: funky value for op in boolexpr::generate_code()");
			  return "ERROR!";
			  break;
			}
		  }
	}
	
  return "ERROR";
}

/********************
  code for notexpr
 ********************/
 //ctf
const char *notexpr::generate_code()
{
	if(invflag ==1)
	{
		fprintf(codefile,"!");
		left->generate_code();
	}
	else
	{
		andflag = 0;
		writeblank();
		fprintf(codefile,"!");
		left->generate_code();
	}
	return "ERROR";
}

/********************
  code for equalexpr
 ********************/
 //ctf equal bug
const char *equalexpr::generate_code()
{
  andflag = 0;
  if(invflag == 1)
  {
	 if (constval)
		return tsprintf("%d", value);
	  else {
		  switch (op) {
		case '=':
			left->generate_code();
		fprintf(codefile," = ");
		right->generate_code();
		  return "ERROR!";
		  break;
		case NEQ:
			left->generate_code();
		fprintf(codefile," != ");
		right->generate_code();
		  return "ERROR!";
		  break;
		default:
		  Error.Error
		  ("Internal: exciting value for op in equalexpr::generate_code().");
		  return "ERROR!";
		  break;
		}
	  } 
  }
  else
  {
	  if (constval)
		return tsprintf("%d", value);
	  else {
		  switch (op) {
		case '=':
		if(formark != 1|isforall2 ==1)
		{
			writeblank();
		}
			left->generate_code();
		fprintf(codefile," = ");
		right->generate_code();
		  return "ERROR!";
		  break;
		case NEQ:
		if(formark != 1|isforall2 ==1)
		{
			writeblank();
		}
			left->generate_code();
		fprintf(codefile," != ");
		right->generate_code();
		  return "ERROR!";
		  break;
		default:
		  Error.Error
		  ("Internal: exciting value for op in equalexpr::generate_code().");
		  return "ERROR!";
		  break;
		}
	  }
  }
  
  return "ERROR";
}

/********************
  code for compexpr
 ********************/
 //ctf
const char *compexpr::generate_code()
{
  if (constval)
  {
	fprintf(codefile,"%d",value);
    return "ERROR!";
  }
  else {
    switch (op) {
    case '<':
	{
		  left->generate_code();
			 fprintf(codefile," < ");
			 right->generate_code();
	}
      return "ERROR!";
    case LEQ:
	{
		  left->generate_code();
			 fprintf(codefile," <= ");
			 right->generate_code();
	}
      return "ERROR!";
    case '>':
	{
		  left->generate_code();
			 fprintf(codefile," > ");
			 right->generate_code();
	}
      return "ERROR!";
    case GEQ:
	{
      left->generate_code();
			 fprintf(codefile," >= ");
			 right->generate_code();
	}		 
	return "ERROR!";
    default:
      Error.Error("Internal: odd value in compexpr::generate_code()");
      return "ERROR!";
    }
  }
}

/********************
  code for arithexpr
 ********************/
 //ctf bug
const char *arithexpr::generate_code()
{
  if (constval)
  { 
	if (type_equal(type, realtype))
		{
			fprintf(codefile,"%le", rvalue);
      return "ERROR!";	// AP: value of a real arithmetic expression (+,-)
		}
    else
	{
		fprintf(codefile,"%d",value);
      return "ERROR!";
	}
  }
  else {
    switch (op) {
    case '+':
	{
		left->generate_code();
		fprintf(codefile," + ");
				right->generate_code();
	}
      return "ERROR!";
    case '-':
				left->generate_code();
		fprintf(codefile," - ");
				right->generate_code();
	            
	
      return "ERROR!";
    default:
      Error.Error("Internal: bad operator in arithexpr::generate_code()");
      return "ERROR!";
    }
  }
};

/********************
  code for unexpr
 ********************/
const char *unexpr::generate_code()
{
   if (constval)
  { 
	if (type_equal(type, realtype))
		{
			fprintf(codefile,"%le", rvalue);
      return "ERROR!";	// AP: value of a real arithmetic expression (+,-)
		}
    else
	{
		fprintf(codefile,"%d",value);
      return "ERROR!";
	}
  }
  else {
    switch (op) {
    case '+':
	left->generate_code();
      return  "ERROR!";
    case '-':
	fprintf(codefile,"("); 
	fprintf(codefile," -");
	left->generate_code();
	fprintf(codefile,")"); 
      return "ERROR!";
    default:
      Error.Error("Internal: bad operator in arithexpr::generate_code()");
      return "ERROR!";
    }
  }
};

/********************
  code for mulexpr
 ********************/
const char *mulexpr::generate_code()
{
  if (constval)
  { 
	if (type_equal(type, realtype))
		{
			fprintf(codefile,"%le", rvalue);
      return "ERROR!";	// AP: value of a real arithmetic expression (+,-)
		}
    else
	{
		fprintf(codefile,"%d",value);
      return "ERROR!";
	}
  }
  else {
    switch (op) {
    case '*':
	left->generate_code();
	fprintf(codefile," * ");
	right->generate_code();
      return "ERROR!";
    case '/':
	left->generate_code();
	fprintf(codefile," / ");
	right->generate_code();
      return "ERROR!";
    case '%':
	left->generate_code();
	fprintf(codefile," %% ");
	right->generate_code();
      return "ERROR!";
    default:
      Error.Error("Internal: bad operator in mulexpr::generate_code()");
      return "ERROR!";
    }
  }
}

/********************
  code for condexpr
 ********************/
const char *condexpr::generate_code()
{
	fprintf(codefile," ( ");test->generate_code();fprintf(codefile," ) ");
	fprintf(codefile," ? ");
	fprintf(codefile," ( ");left->generate_code();fprintf(codefile," ) ");
	fprintf(codefile," : ");
	fprintf(codefile," ( ");right->generate_code();fprintf(codefile," ) ");
  return "ERROR!";
}

/********************
  code for quantexpr
 ********************/

void make_quant_fors(ste * quants)
{
  if (quants != NULL && quants->getvalue()->getclass() == decl::Quant) {
	
    make_quant_fors(quants->getnext());
    ((quantdecl *) quants->getvalue())->make_for();
  }
}
//neiyong
void make_quant_closes(ste * quants)
{
  if (quants != NULL && quants->getvalue()->getclass() == decl::Quant) {
    make_quant_closes(quants->getnext());
    if(make_f==1)
      fprintf(codefile,")");
    else
      fprintf(codefile, "[paramdef \"%s\" \"%s\"])",((quantdecl *) quants->getvalue())->name, ((quantdecl *) quants->getvalue())->type->name);

  }
}

const char *quantexpr::generate_code()
{
	if(andflag ==1)
	{
		writeblank();
		andflag = 0;
	}
	isforall2 = 1;
  int num = new_int();
 // char *temp;
  bool isforall = ((op == FORALL) ? TRUE : FALSE);
  //strcpy(temp,"");
  int o = forallnum;
  if (isforall)
  {make_f=1;}
  else
	{make_f = 10;}
  formark =1;
  make_quant_fors(parameter);
  fprintf(codefile, "\n");
  blankadd();
  if(invflag == 1)
  {
	  writeblank();
  }
  left->generate_code();
  blankred();
  fprintf(codefile, "\n");
  writeblank();
  for(;forallnum > o;forallnum--)
  {fprintf(codefile, "end ");}
fseek(codefile,-1, SEEK_CUR);
formark =0;
isforall2 = 0;
//fprintf(codefile, "\n");
//forallnum = 0;
  return "Error!";
}


/********************
  code for designator
 ********************/
 //ctf startstate body2
int f_s;
bool b=false;
const char *designator::generate_code()
{
	if(andflag == 1)
	{
		writeblank();
		andflag =0;
	}
  switch (dclass) {
  case Base: {
      fprintf(codefile,"%s",origin->getvalue()->generate_code());
    break;
  
}
  case ArrayRef:{
	  left->generate_code();
	  fprintf(codefile,"[");
	  arrayref->generate_code();
	  fprintf(codefile,"]");
    break;
}
  case FieldRef:{
left->generate_code();
fprintf(codefile,".");
fprintf(codefile,"%s",fieldref->getvalue()->name);
    break;
}
  default:
    Error.Error
	("Internal: Strange and mysterious values for designator::dclass.");
    return "ERROR!";
    break;
  }
return "ERROR!";  
}

/********************
  code for exprlist
 ********************/
 //meiyong
const char *exprlist::generate_code(const char *name, ste * formals)
{
  exprlist *ex = this;
  if (this == NULL) {
    // exprlist_buffer_end = exprlist_buffer;
    return "ERROR!";
  } else {
    char *exprlist_buffer = new char[BUFFER_SIZE];
    char *exprlist_buffer_end = exprlist_buffer;
    for (ex = this; formals != NULL && ex != NULL;
	 formals = formals->getnext(), ex = ex->next) {
      param *f = (param *) formals->getvalue();
      if (!ex->undefined) {
	if (f->gettype() != ex->e->gettype() &&
	    ((ex->e->gettype()->gettypeclass() == typedecl::Range
	      && ((f->gettype()->gettype() == ex->e->gettype()->gettype())
		  || (type_equal(f->gettype(), realtype)))
	     )
	     ||
	     ((ex->e->gettype()->gettypeclass() == typedecl::Scalarset
	       || ex->e->gettype()->gettypeclass() == typedecl::Enum)
	      && f->gettype()->gettypeclass() == typedecl::Union)
	     ||
	     (ex->e->gettype()->gettypeclass() == typedecl::Union
	      && (f->gettype()->gettypeclass() == typedecl::Scalarset
		  || f->gettype()->gettypeclass() == typedecl::Enum))
	    )
	    )
	  sprintf(exprlist_buffer_end, ", (int)%s",
		  ex->e->generate_code());
	else if (f->gettype() != ex->e->gettype()
		 && (type_equal(ex->e->gettype(), realtype)
		     && f->gettype()->gettype() ==
		     ex->e->gettype()->gettype()))
	  sprintf(exprlist_buffer_end, ", (double)%s",
		  ex->e->generate_code());
	else
	  sprintf(exprlist_buffer_end, ", %s", ex->e->generate_code());
      } else {
	sprintf(exprlist_buffer_end, ", %s_undefined_var",
		f->gettype()->generate_code());
      }
      exprlist_buffer_end += strlen(exprlist_buffer_end);
    }
    if (strlen(exprlist_buffer) > BUFFER_SIZE)
      Error.Error("Internal: Buffer size for expression list overflow.\n"
		  "	  Please increase BUFFER_SIZE in /src/mu.h");
    return (exprlist_buffer + 2);	// + 2 to skip the leading comma and space
    /* BUG: Aargh! We can\'t delete the buffer! */
  }
}

// char *exprlist::generate_code()
// {
//   exprlist *ex = this;
//   if (this == NULL ) {
//     // exprlist_buffer_end = exprlist_buffer;
//     return "ERROR!";
//   }
//   else {
//     char *exprlist_buffer = new char[BUFFER_SIZE];
//     char *exprlist_buffer_end = exprlist_buffer;
//     for (ex = this; ex != NULL; ex = ex->next) {
//       sprintf(exprlist_buffer_end, ", %s", ex->e->generate_code() );
//       exprlist_buffer_end += strlen(exprlist_buffer_end);
//     }
//     return ( exprlist_buffer + 2); // + 2 to skip the leading comma and space
//     /* BUG: Aargh! We can\'t delete the buffer! */
//     }
// }

/********************
  code for funccall
 ********************/
/* BUG: Caution: is there any way the generated statement can end up in
   the middle of an expression? */
//meiyong
const char *funccall::generate_code()
{
  funcdecl *f = (funcdecl *) func->getvalue();
  return tsprintf("%s( %s )",
		  //im: for imported functions, "mu_" does not have to be prefixed to the function name
		  f->extern_def ? &(func->
				    getvalue()->generate_code())[3] :
		  func->getvalue()->generate_code(),
		  actuals !=
		  NULL ? actuals->generate_code(func->getname()->getname(),
						f->params) : "");
}

// char *funccall::generate_code()
// {
//   return tsprintf("%s( %s )",
//      func->getvalue()->generate_code(),
//      actuals != NULL ? actuals->generate_code() : "");
// }

/********************
  code for isundefined
  ********************/
  //meiyong
const char *isundefined::generate_code()
{
  fprintf(codefile,"undefine ");
  left->generate_code();
  fprintf(codefile,";\n");
  return "ERROR!"; 
}

/********************
  code for ismember
  ********************/
  //meiyong
const char *ismember::generate_code()
{
  return tsprintf("(%s>=%d && %s<=%d)",
		  left->generate_code(), t->getleft(),
		  left->generate_code(), t->getright());
}

/********************
  code for multisetcount
  ********************/
  //meiyong
void multisetcount::generate_decl(multisettypedecl * mset)
{
/*
  if (mset == set->gettype())
    {
      fprintf(codefile,"int multisetcount%d();\n",
	  multisetcount_num
	  );
    }
    */
}

void multisetcount::generate_procedure()
{
}

const char *multisetcount::generate_code()
{
  /* set->gettype()->getelementtype()->generate_code(), /* element type */
  /* set->gettype()->generate_code(), /* multiset type */
  /*  multisetcount_num,               /* procedure number */
  int num = new_int();
  char *temp = tsprintf("mu__intexpr%d", num);
  fprintf(codefile, "/*** begin multisetcount %d declaration ***/\n",
	  multisetcount_num);
  fprintf(codefile, "  int %s = 0;\n", temp);

  fprintf(codefile, "  {\n" "  %s_id %s;\n" "  for (%s = 0; ; %s=%s+1)\n" "    {\n" "      if (%s.valid[(int)%s].value())\n"	// Uli 10-98
	  "	{\n", set->gettype()->generate_code(),	/* multiset type */
	  index->getvalue()->generate_code(),	/* index name */
	  index->getvalue()->generate_code(),	/* index name */
	  index->getvalue()->generate_code(),	/* index name */
	  index->getvalue()->generate_code(),	/* index name */
	  set->generate_code(),	/* multiset variable name */
	  index->getvalue()->generate_code()	/* index name */
      );
  fprintf(codefile, "	  if ( %s ) %s++;\n" "	}\n" "      if (%s == %d-1) break;\n" "    }\n" "  }\n", filter->generate_code(),	/* bool expression */
	  temp, index->getvalue()->generate_code(),	/* index name */
	  ((multisettypedecl *) set->gettype())->getindexsize()	/* max size */
      );
  fprintf(codefile, "/*** end multisetcount %d declaration ***/\n",
	  multisetcount_num);
  return tsprintf("%s", temp);
}

/********************
  code related to stmt
  --
  -- stmt
  -- assignment
  -- whilestmt
  -- ifstmt
  -- caselist
  -- switchstmt
  -- forstmt
  -- proccall
  -- clearstmt
  -- errorstmt
  -- assertstmt
  -- putstmt
  -- alias
  -- aliasstmt
  -- returnstmt
 ********************/

/********************
  code for stmt
 ********************/
 //meiyong
const char *stmt::generate_code()
{
  /* There now is the null statement--
   * it is legal to call stmt::generate_code();
   * it must be the null statement, so it just does nothing.
   */
  /*  Error.Error("Internal: stmt::generate_code() should never have been called."); */
  return "ERROR!";
}

/********************
  code for assignment
 ********************/
 //ctf startstate body
const char *assignment::generate_code()
{

target->generate_code();	
fprintf(codefile," := ");
src->generate_code();
fprintf(codefile,";\n");	

  return "ERROR!";
}

/********************
  code for whilestmt
 ********************/
  //meiyong
const char *whilestmt::generate_code()
{
  char *counter = tsprintf("mu__counter_%d", new_int());
  char *while_expr = tsprintf("mu__while_expr_%d", new_int());

  // Uli: a "goto" to exit the while loop seemed to cause problems on some
  //      compilers when there were local variables

  // set mu__while_expr<n> to the value of the expr
  fprintf(codefile,
	  "{\n"
	  "  bool %s;"
	  "  %s = %s;\n", while_expr, while_expr, test->generate_code());

  fprintf(codefile,
	  "int %s = 0;\n"
	  "while (%s) {\n"
	  "if ( ++%s > args->loopmax.value )\n"
	  "  Error.Error(\"Too many iterations in while loop.\");\n",
	  counter, while_expr, counter);

  // nest a block so that the code within the loop
  // can generate variables if it needs to.
  fprintf(codefile, "{\n");

  for (stmt * s = body; s != NULL; s = s->next)
    s->generate_code();

  fprintf(codefile, "};\n");

  // set mu__while_expr<n> to the value of the expr
  // before the C++ while checks the variable.
  fprintf(codefile, "%s = %s;\n", while_expr, test->generate_code());

  fprintf(codefile, "}\n" "};\n");

  return "ERROR!";
}

/********************
  code for ifstmt
 ********************/
const char *ifstmt::generate_code()
{

  if(formark == 1)
  {
	fprintf(codefile, "if (");
	test->generate_code();
	fprintf(codefile, ") then\n");
	blankadd();
	for (stmt * s = body; s != NULL; s = s->next)
	{
		writeblank();
		s->generate_code();
	}
	blankred();
	if (elsecode != NULL)
	{
		writeblank();
		fprintf(codefile, "else\n");
		blankadd();
		for (stmt * s = elsecode; s != NULL; s = s->next)
		{
			writeblank();
			s->generate_code();
		}
		blankred();
	}
	writeblank();
    fprintf(codefile, "end;\n"); 
  }
  else if (isdecleared == 1)
  {
	  fseek(codefile,-2, SEEK_CUR);
	 for (stmt * s = body; s != NULL; s = s->next)
	 {
		 writeblank();
		 s->generate_code();
	 } 

  }
  else if(isdecleared == 0)
  {
	  fseek(codefile,-2, SEEK_CUR);
	for (stmt * s = elsecode; s != NULL; s = s->next)
     { 
		writeblank();
		s->generate_code();
	 }
  }
  else{}

  return "ERROR!";
}

/********************
  code for caselist
 ********************/
const char *caselist::generate_code()
{
  for (exprlist * v = values; v != NULL; v = v->next)
    fprintf(codefile, "case %s:\n", v->e->generate_code());

  for (stmt * b = body; b != NULL; b = b->next)
    b->generate_code();
  fprintf(codefile, "break;\n");
  return "ERROR!";
}

/********************
  code for switchstmt
 ********************/
const char *switchstmt::generate_code()
{
  fprintf(codefile, "switch ((int) %s) {\n", switchexpr->generate_code());
  /* The explicit cast seems to be necessary to allow things like
   * switch arr[i]... */
  for (caselist * c = cases; c != NULL; c = c->next)
    c->generate_code();
  if (elsecode != NULL) {
    fprintf(codefile, "default:\n");

    for (stmt * b = elsecode; b != NULL; b = b->next)
      b->generate_code();

    fprintf(codefile, "break;\n");
  }
  fprintf(codefile, "}\n");
  return "ERROR!";
}

/********************
  code for forstmt
 ********************/
const char *forstmt::generate_code()
{
 // fprintf(codefile, "{\n");
  make_f=2;
  formark = 1;
  int o = forallnum;
  make_quant_fors(index);
  blankadd();
  //printf(codefile,"%s : %s ",(index->getvalue())->name,((quantdecl *)index->getvalue())->type->name);
  //fprintf(codefile,"Do \n ");
  for (stmt * b = body; b != NULL; b = b->next){
    writeblank();
	b->generate_code();
  }
  blankred();
  for(;forallnum > o;forallnum--)
  {
	  writeblank();
	  fprintf(codefile, "end;\n");
	}
//fprintf(codefile, "\n");
//forallnum = 0;
  formark = 0;
  return "ERROR!";
}

/********************
  code for proccall
 ********************/
const char *proccall::generate_code()
{
  procdecl *p = (procdecl *) procedure->getvalue();
  fprintf(codefile, "%s ( %s );\n",
	  //im: for imported procedures, "mu_" does not have to be prefixed to the function name
	  p->extern_def ? &(procedure->
			    getvalue()->generate_code())[3] : procedure->
	  getvalue()->generate_code(),
	  actuals !=
	  NULL ? actuals->generate_code(procedure->getname()->getname(),
					p->params) : "");
  return "ERROR!";
}

// char *proccall::generate_code()
// {
//   fprintf(codefile,"%s ( %s );\n",
//    procedure->getvalue()->generate_code(),
//    actuals != NULL ? actuals->generate_code() : "" );
//   return "ERROR!";
// }

/********************
  code for clearstmt
 ********************/
const char *clearstmt::generate_code()
{
  // Gotta figure this one out--
  // current best idea: give every object a clear method.
 fprintf(codefile, "clear ");
  target->generate_code();
  fprintf(codefile, ";\n");
  return "ERROR!";
}

/********************
  code for undefinestmt
  ********************/
const char *undefinestmt::generate_code()
{
  fprintf(codefile, "undefine ");
  target->generate_code();
  fprintf(codefile, ";\n");
  return "ERROR!";
}

/********************
  code for multisetaddstmt
  ********************/
const char *multisetaddstmt::generate_code()
{
  fprintf(codefile, "%s.multisetadd(%s);\n",
	  target->generate_code(), element->generate_code());
  return "ERROR!";
}

/********************
  code for multisetremovestmt
  ********************/
void multisetremovestmt::generate_decl(multisettypedecl * mset)
{
/*
  if (mset == target->gettype())
    {
      fprintf(codefile,"void multisetremove%d();\n",
	  multisetremove_num
	  );
    }
    */
}

void multisetremovestmt::generate_procedure()
{
}

const char *multisetremovestmt::generate_code()
{
  if (matchingchoose) {
    fprintf(codefile, "%s.multisetremove(%s);\n",
	    target->generate_code(), criterion->generate_code());
  } else {
    int num = new_int();
    char *temp = tsprintf("mu__idexpr%d", num);
    fprintf(codefile, "/*** end multisetremove %d declaration ***/\n",
	    multisetremove_num);
    fprintf(codefile, "  %s_id %s;\n", target->gettype()->generate_code(),	/* multiset type */
	    temp);

    fprintf(codefile, "  %s_id %s;\n" "  for (%s = 0; ; %s=%s+1)\n" "    {\n" "      if (%s.valid[(int)%s].value())\n"	// Uli 01-99
	    "	{\n", target->gettype()->generate_code(),	/* multiset type */
	    index->getvalue()->generate_code(),	/* index name */
	    index->getvalue()->generate_code(),	/* index name */
	    index->getvalue()->generate_code(),	/* index name */
	    index->getvalue()->generate_code(),	/* index name */
	    target->generate_code(),	/* multiset variable name */
	    index->getvalue()->generate_code()	/* index name */
	);
    fprintf(codefile, "	  if ( %s ) { %s = %s; %s.multisetremove(%s); };\n" "	}\n" "      if (%s == %d-1) break;\n" "    }\n", criterion->generate_code(),	/* bool expression */
	    temp, index->getvalue()->generate_code(),	/* index name */
	    target->generate_code(),	/* multiset variable name */
	    temp, index->getvalue()->generate_code(),	/* index name */
	    ((multisettypedecl *) target->gettype())->getindexsize()	/* max size */
	);
    fprintf(codefile, "/*** end multisetremove %d declaration ***/\n",
	    multisetremove_num);
  }

  return "ERROR!";
}

/********************
  code for errorstmt
 ********************/
const char *errorstmt::generate_code()
{
  fprintf(codefile, "Error.Error(\"Error: %s\");\n", string);
  return "ERROR!";
}

/********************
  code for assertstmt
 ********************/
const char *assertstmt::generate_code()
{
  fprintf(codefile,
	  "if ( !(%s) ) Error.Error(\"Assertion failed: %s\");\n",
	  test->generate_code(), string);
  return "ERROR!";
}

/********************
  code for putstmt
 ********************/
const char *putstmt::generate_code()
{
  if (putexpr != NULL) {
    if (putexpr->islvalue())
      fprintf(codefile, "%s.print();\n", putexpr->generate_code());
    else
      fprintf(codefile, "cout << ( %s );\n", putexpr->generate_code());
  } else {
    fprintf(codefile, "cout << \"%s\";\n", putstring);
  }
  return "ERROR!";
}

/********************
  code for alias
 ********************/
const char *alias::generate_code()
     /* not used right now. */
{
  return "ERROR!";
}

/********************
  code for aliasstmt
 ********************/
const char *aliasstmt::generate_code()
{
  fprintf(codefile, "{\n");
  aliases->generate_decls();
  for (stmt * b = body; b != NULL; b = b->next)
    b->generate_code();
  fprintf(codefile, "}\n");
  return "ERROR!";
}

/********************
  code for returnstmt
 ********************/
const char *returnstmt::generate_code()
{
  // Uli: the return expression is not converted to int. Therefore, the
  // copy constructor is used to create a temporary object for the return
  // expression. Advantage: complex types can be returned.
  // (no change in this routine)
  fprintf(codefile, "return %s;\n",
	  retexpr != NULL ? retexpr->generate_code() : "");

//  if (retexpr) fprintf(codefile,"return %s;\n", retexpr->generate_code());
//  else fprintf(codefile, "return;\n");
  return "ERROR!";
}

/********************
  code related to rules
 ********************/
static char rule_param_buffer[BUFFER_SIZE];
static ste *stequants[MAXSCOPES];	/* We can\'t have more enclosing rulesets than scopes. */
static int numquants = 0;
static char namequants[BUFFER_SIZE];
static char quantactuals[BUFFER_SIZE];

/********************
  aux_generate_rule_params
  -- extract "Quant" from enclosure and generate the string for it
  -- i.e. the string to be placed in condition/rule function 
  -- formal
 ********************/
// no longer used
static char *aux_generate_rule_params(ste * enclosures)
/* returns a pointer to the '\0' at the end of the string in
 * rule_param_buffer. */
{
  char *temp;
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias)) {
    temp = aux_generate_rule_params(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Quant)
      sprintf(temp,
	      ", const %s &%s",
	      enclosures->getvalue()->gettype()->generate_code(),
	      enclosures->getvalue()->generate_code());
    return (temp + strlen(temp));
  } else
    return rule_param_buffer;
}

/********************
  generate_rule_params
  -- initialize buffer "rule_param_buffer
  -- and call aux_generate_rule_params
  -- to return the appropriate string
  -- i.e. the string to be placed in condition/rule function 
  -- formal
 ********************/

static char *generate_rule_params(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  int i = 0;
  for (i = 0; rule_param_buffer[i] != '\0' && i < BUFFER_SIZE; i++)
    rule_param_buffer[i] = '\0';
  aux_generate_rule_params(enclosures);
  return (rule_param_buffer + 1);	/* skip the leading comma. */
}

/********************
  generate_rule_params_assignment
 ********************/
// void generate_rule_params_assignment_union(ste *enclosures)
// {
//         stelist * t;
//         typedecl * d;  
//         int thisright = enclosures->getvalue()->gettype()->getsize()-1;
//         int thisleft;
// 
//         for(t=((uniontypedecl *)indextype)->getunionmembers();
//             t!= NULL; t=t->next)
//           {
//             d = (typedecl *)t->s->getvalue();
//             thisleft = thisright - d->getsize() + 1;
// 
//   fprintf(codefile,
//    "    if (int_
//    "    %s_id %s = (r %% %d) + %d;\n"
//    ((multisetidtypedecl *)enclosures->getvalue()->gettype())
//    ->getparenttype()->generate_code(),
//    enclosures->getvalue()->gettype()->getleft(),
//    );
// 
// 
// 
// //       for (i=thisleft; i<=thisright; i++)
//      for (i=d->getleft(); i<=d->getright(); i++)
//      for (e = elt; e!=NULL; e=e->next)
//        ret = new charlist(tsprintf("[%d]%s",i, e->string), e->e, ret);
//             thisright= thisleft - 1;
//           }
//   
// }
int e=0;
void generate_rule_params_assignment(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) 
	{
    generate_rule_params_assignment(enclosures->getnext());
        fprintf(codefile, "%s : %s; ", enclosures->getvalue()->name, enclosures->getvalue()->gettype()->name);
    }
}

void generate_rule_params_simple_assignment(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_simple_assignment(enclosures->getnext());
    if (enclosures->getvalue()->gettype()->gettypeclass() ==
	typedecl::Union) {
      if (enclosures->getvalue()->getclass() == decl::Choose)
	fprintf(codefile,
		"    %s.unionassign( r %% %d );\n"
		"    r = r / %d;\n",
		enclosures->getvalue()->generate_code(),
		enclosures->getvalue()->gettype()->getsize(),
		enclosures->getvalue()->gettype()->getsize()
	    );
      if (enclosures->getvalue()->getclass() == decl::Quant)
	fprintf(codefile,
		"    %s.unionassign(r %% %d);\n"
		"    r = r / %d;\n",
		enclosures->getvalue()->generate_code(),
		enclosures->getvalue()->gettype()->getsize(),
		enclosures->getvalue()->gettype()->getsize()
	    );
    } else {
      if (enclosures->getvalue()->getclass() == decl::Choose)
	fprintf(codefile,
		"    %s.value((r %% %d) + %d);\n"
		"    r = r / %d;\n",
		enclosures->getvalue()->generate_code(),
		enclosures->getvalue()->gettype()->getsize(),
		enclosures->getvalue()->gettype()->getleft(),
		enclosures->getvalue()->gettype()->getsize()
	    );
      if (enclosures->getvalue()->getclass() == decl::Quant)
	fprintf(codefile,
		"    %s.value((r %% %d) + %d);\n"
		"    r = r / %d;\n",
		enclosures->getvalue()->generate_code(),
		enclosures->getvalue()->gettype()->getsize(),
		enclosures->getvalue()->gettype()->getleft(),
		enclosures->getvalue()->gettype()->getsize()
	    );
    }
  }
}

void generate_rule_params_choose(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_choose(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Choose)
      fprintf(codefile, "  if (!%s.in(%s)) { return FALSE; }\n",
	      ((multisetidtypedecl *) enclosures->getvalue()->gettype())
	      ->getparentname(), enclosures->getvalue()->mu_name);
  }
}

void generate_rule_params_choose_exist(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_choose_exist(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Choose)
      fprintf(codefile, "&& %s.value()<%d ",
	      enclosures->getvalue()->mu_name,
	      enclosures->getvalue()->gettype()->getsize()
	  );
  }
}


void generate_rule_params_choose_next(ste * enclosures, unsigned end)
// Uli: unsigned short -> unsigned
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_choose(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Choose)
      fprintf(codefile, "	    if (!%s.in(%s)) { return %d; }\n",
	      ((multisetidtypedecl *) enclosures->getvalue()->gettype())
	      ->getparentname(), enclosures->getvalue()->mu_name, end);
  }
}

void generate_rule_params_choose_all_in(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_choose_all_in(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Choose)
      fprintf(codefile, "&& %s.in(%s)",
	      ((multisetidtypedecl *) enclosures->getvalue()->gettype())
	      ->getparentname(), enclosures->getvalue()->mu_name);
  }
}

void generate_rule_params_printf(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_printf(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Quant ||
	enclosures->getvalue()->getclass() == decl::Choose)
      fprintf(codefile, ", %s:%%s", enclosures->getvalue()->name);
  }
}



void generate_rule_params_name(ste * enclosures)
/* assumes that enclosures is a pointer to a list of ste\'s,
 * with ruleset parameters and aliases at the front. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_params_name(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Quant ||
	enclosures->getvalue()->getclass() == decl::Choose)
      fprintf(codefile,
	      ", %s.Name()", enclosures->getvalue()->generate_code()
	  );
  }
}

/********************
  generate_rule_aliases
  -- extract "Alias" from enclosure and generate the code for it
 ********************/
 //ctf Aliases
static const char *generate_rule_aliases(ste * enclosures)
/* generate alias declarations for the rule. */
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    generate_rule_aliases(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Alias)
	{
		enclosures->getvalue()->generate_decl();
		fprintf(codefile,";\n");
	}
	
    return "ERROR!";
  } else
    return "ERROR!";
}

/********************
  enroll_quants
  -- enter each "Quant" enclosure, i.e. ruleset, into
  -- the list "stequants" for easy recursion to find every
  -- instance of a ruleset
 ********************/
static void enroll_quants(ste * enclosures)
{
  if (enclosures != NULL &&
      (enclosures->getvalue()->getclass() == decl::Quant ||
       enclosures->getvalue()->getclass() == decl::Alias ||
       enclosures->getvalue()->getclass() == decl::Choose)) {
    enroll_quants(enclosures->getnext());
    if (enclosures->getvalue()->getclass() == decl::Quant ||
	enclosures->getvalue()->getclass() == decl::Choose) {
      if (numquants >= MAXSCOPES) {
	Error.FatalError
	    ("Current implementation only allows %d nested rulesets.",
	     MAXSCOPES);
      }
      stequants[numquants] = enclosures;
      numquants++;
    }
  } else {
    numquants = 0;
  }
}

/********************
  static void generate_rules_aux(...)
  -- called by generate_rules
  --
  -- generate every instance of a ruleset, by recursively
  -- going down the list of enclosure
  -- 
  -- done recursively because the cost of this program isn\'t that huge,
  -- and recursion is much easier for me to understand. 
 ********************/
static void
generate_rules_aux(int quantindex,
		   char *namequants_end,
		   char *quantactuals_end, simplerule * therule)
{
  rulerec *rr;
  int rule_int = new_int();
  char *condname;
  char *rulename;
  if (quantindex >= numquants) {
    /* generate the code for the rule. */
    /* and enroll it into appropriate list */
    if (therule->condition != NULL) {
      condname = tsprintf("mu__condition_%d", rule_int);
      fprintf(codefile, "bool %s() // Condition for Rule \"%s%s\"\n" "{\n" "  return %s(%s );\n" "}\n\n", condname, therule->name, namequants, therule->condname, quantactuals + 1);	/* + 1 to skip the leading comma. */
    } else
      condname = NULL;
    if (therule->body != NULL) {
      rulename = tsprintf("mu__rule_%d", rule_int);
      fprintf(codefile, "void %s() // Action for Rule \"%s%s\"\n" "{\n" "  %s(%s );\n" "};\n\n", rulename, therule->name, namequants, therule->rulename, quantactuals + 1);	/* + 1 to skip the leading comma. */
    } else
      rulename = NULL;

    /* install it into the appropriate list. */
    rr = new rulerec(tsprintf("%s%s", therule->name, namequants),
		     condname, rulename);
    switch (therule->getclass()) {
    case rule::Simple:
      rr->next = theprog->rulelist;
      theprog->rulelist = rr;
      break;
    case rule::Startstate:	/* This function seems not to be called on start states! */
      rr->next = theprog->startstatelist;
      theprog->startstatelist = rr;
      break;
    case rule::Invar:
      rr->next = theprog->invariantlist;
      theprog->invariantlist = rr;
      break;
    default:
      Error.Error
	  ("Internal: Exciting value for therule->getclass() in generate_rules_aux.");
      break;
    }
  } else {
    /* do some more recursion. */
    int i;
    char *names_end, *actuals_end;
    quantdecl *quant = (quantdecl *) stequants[quantindex]->getvalue();
    if (quant->left != NULL) {
      for (i = quant->left->getvalue(); i <= quant->right->getvalue();
	   i += quant->by) {
	sprintf(namequants_end, ", %s:%d", quant->name, i);
	names_end = namequants_end + strlen(namequants_end);
	sprintf(quantactuals_end, ", %d", i);
	actuals_end = quantactuals_end + strlen(quantactuals_end);
	generate_rules_aux(quantindex + 1, names_end, actuals_end,
			   therule);
      }
    } else {
// rlm wrote :
//     for( ste *s = ((enumtypedecl *) quant->gettype())->getidvalues();
//      s != NULL;
//      s = s->getnext() )
// spark : ( s!= NULL ) is not reached properly 
//   : ex. OMH.m with ruleset over enum type

      ste *s;
      stelist *t;
      typedecl *d;

      // put value or enum string to the rule name and parameter, according to type 

      // Enum
      if (quant->gettype()->gettypeclass() == typedecl::Enum
	  && quant->gettype() != booltype) {
	s = ((enumtypedecl *) quant->gettype())->getidvalues();
	for (i = quant->gettype()->getleft();
	     i <= quant->gettype()->getright(); i++) {
	  sprintf(namequants_end, ", %s:%s", quant->name,
		  s->getname()->getname());
	  sprintf(quantactuals_end, ", %s",
		  s->getvalue()->generate_code());
	  s = s->getnext();
	  names_end = namequants_end + strlen(namequants_end);
	  actuals_end = quantactuals_end + strlen(quantactuals_end);
	  generate_rules_aux(quantindex + 1, names_end, actuals_end,
			     therule);
	}
      } else if (quant->gettype() == booltype) {
	for (i = 0; i <= 1; i++) {
	  if (i == 0) {
	    sprintf(namequants_end, ", %s:false", quant->name);
	    sprintf(quantactuals_end, ", mu_false");
	  } else {
	    sprintf(namequants_end, ", %s:true", quant->name);
	    sprintf(quantactuals_end, ", mu_true");
	  }
	  names_end = namequants_end + strlen(namequants_end);
	  actuals_end = quantactuals_end + strlen(quantactuals_end);
	  generate_rules_aux(quantindex + 1, names_end, actuals_end,
			     therule);
	}
      }
      // Scalarset
      else if (quant->gettype()->gettypeclass() == typedecl::Scalarset) {
	s = ((scalarsettypedecl *) quant->gettype())->getidvalues();
	for (i = quant->gettype()->getleft();
	     i <= quant->gettype()->getright(); i++) {
	  sprintf(namequants_end, ", %s:%s", quant->name,
		  s->getname()->getname());
	  sprintf(quantactuals_end, ", %s",
		  s->getvalue()->generate_code());
	  s = s->getnext();
	  names_end = namequants_end + strlen(namequants_end);
	  actuals_end = quantactuals_end + strlen(quantactuals_end);
	  generate_rules_aux(quantindex + 1, names_end, actuals_end,
			     therule);
	}
      }
      // Union
      else if (quant->gettype()->gettypeclass() == typedecl::Union) {
	t = ((uniontypedecl *) quant->gettype())->getunionmembers();
	for (; t != NULL; t = t->next) {
	  d = (typedecl *) t->s->getvalue();
	  if (d->gettypeclass() == typedecl::Scalarset)
	    s = ((scalarsettypedecl *) d)->getidvalues();
	  else if (d->gettypeclass() == typedecl::Enum)
	    s = ((enumtypedecl *) d)->getidvalues();
	  else
	    Error.Error("Funny element in union");

	  for (i = d->getleft(); i <= d->getright(); i++) {
	    sprintf(namequants_end, ", %s:%s", quant->name,
		    s->getname()->getname());
	    sprintf(quantactuals_end, ", %s",
		    s->getvalue()->generate_code());
	    s = s->getnext();
	    names_end = namequants_end + strlen(namequants_end);
	    actuals_end = quantactuals_end + strlen(quantactuals_end);
	    generate_rules_aux(quantindex + 1, names_end, actuals_end,
			       therule);
	  }
	}
      }
      // subrange
      else {
	for (i = quant->gettype()->getleft();
	     i <= quant->gettype()->getright(); i++) {
	  sprintf(namequants_end, ", %s:%d", quant->name, i);
	  sprintf(quantactuals_end, ", %d", i);
	  names_end = namequants_end + strlen(namequants_end);
	  actuals_end = quantactuals_end + strlen(quantactuals_end);
	  generate_rules_aux(quantindex + 1, names_end, actuals_end,
			     therule);
	}
      }

    }
  }
}



/********************
  generate_rules
  -- creates the stub procedures for a rule/startstate/invariant/fairness
  -- and enrolls them in the list of rules.
  --
  -- i.e. create instances of rule/startstate/invariant
  -- by calling the main condition function and rule function
  -- corresponding to the rules
 ********************/
static void generate_rules(ste * enclosures, simplerule * therule)
{
  int i = 0;

  // set up quants[] array of quantdecl
  enroll_quants(enclosures);

  // initialize namequants[] and quantactuals[] to all \'\0\'
  for (i = 0; namequants[i] != '\0' && i < BUFFER_SIZE; i++)
    namequants[i] = '\0';
  for (i = 0; quantactuals[i] != '\0' && i < BUFFER_SIZE; i++)
    quantactuals[i] = '\0';

  // generate rules by calling to main rule with quantifier value
  generate_rules_aux(0, namequants, quantactuals, therule);

  fprintf(codefile, "/**** end rule declaration ****/\n\n");
}

/********************
  code for simplerule
  -- rules produce some code,
  -- but also update the rules/startst/invariant list.
 ********************/
const char *rule::generate_code()
{
  return "ERROR!";
}

/********************
  code for simplerule
 ********************/
 //ctf
const char *simplerule::generate_code()
{	
  return "ERROR!";
}
/********************
  code for startstate
 ********************/
//ctf
const char *startstate::generate_code()
{
	if(enclosures != NULL && (enclosures->getvalue()->getclass() == decl::Quant 
	|| enclosures->getvalue()->getclass() == decl::Alias))
	{
		fprintf(codefile, "ruleset  ");	  	  
		generate_rule_params_assignment(enclosures);
		fseek(codefile,-2, SEEK_CUR);
		fprintf(codefile, " do\n");	
	} 
  fprintf(codefile, "startstate\n");
 // fprintf(codefile, "Begin\n");
 blankadd();
  for (stmt * b = body; b != NULL; b = b->next){
  writeblank();
  b->generate_code();
  }
  blankred();
fprintf(codefile, "endstartstate;\n");
if(enclosures != NULL && (enclosures->getvalue()->getclass() == decl::Quant 
	|| enclosures->getvalue()->getclass() == decl::Alias))
{
	fprintf(codefile, "endruleset;\n");
}	
  return "ERROR!";
}

/********************
  code for invariant
 ********************/
const char *invariant::generate_code()
{
	if(enclosures != NULL && (enclosures->getvalue()->getclass() == decl::Quant 
|| enclosures->getvalue()->getclass() == decl::Alias))
	{
		fprintf(codefile, "ruleset  ");	  	  
		generate_rule_params_assignment(enclosures);
		fseek(codefile,-2, SEEK_CUR);
		fprintf(codefile, " do\n");	 
	}
  fprintf(codefile,"invariant \"%s\"\n",name);
  blankadd();
  writeblank();
condition->generate_code();
	blankred();

if(enclosures != NULL && (enclosures->getvalue()->getclass() == decl::Quant 
|| enclosures->getvalue()->getclass() == decl::Alias))
	{
		fprintf(codefile, "\nendruleset;\n");	
	}
	else
	{fprintf(codefile, ";\n\n");}
  return "ERROR!";
}

/********************
  code for pctl
 ********************/
//meiyong
void pctl::generate_atomic_subformulas(pctl * formula)
{
  if (formula == NULL)
    return;
  if (formula->pctltype == AP_PCTL) {
    fprintf(codefile, "bool mu_pctl_a_p%d()\n{\n", formula->code);
    fprintf(codefile, "return %s;\n}\n",
	    formula->atomic_proposition->generate_code());
  } else {
    generate_atomic_subformulas(formula->subformula1);
    generate_atomic_subformulas(formula->subformula2);
  }
}

const char *pctl::getstring(pctl_type t)
{
  switch (t) {
  case UNTIL_PCTL:
    return "UNTIL_PCTL";
  case NEXT_PCTL:
    return "NEXT_PCTL";
  case AP_PCTL:
    return "AP_PCTL";
  case AND_PCTL:
    return "AND_PCTL";
  case OR_PCTL:
    return "OR_PCTL";
  case IMPL_PCTL:
    return "IMPL_PCTL";
  case NOT_PCTL:
    return "NOT_PCTL";
  }
}

const char *pctl::getstring(pctl_ord o)
{
  switch (o) {
  case PCTL_L:
    return "PCTL_L";
  case PCTL_LEQ:
    return "PCTL_LEQ";
  case PCTL_G:
    return "PCTL_G";
  case PCTL_GEQ:
    return "PCTL_GEQ";
  }
}

void pctl::generate_non_atomic_subformulas(pctl * formula)
{
  if (formula == NULL)
    return;
  generate_non_atomic_subformulas(formula->subformula1);
  generate_non_atomic_subformulas(formula->subformula2);
  if (formula == this)
    fprintf(codefile, "const pctlformrec mu_pctl_formula = {\n");
  else
    fprintf(codefile, "const pctlformrec mu_pctl_formula%d = {\n",
	    formula->code);
  fprintf(codefile, "%s, ", getstring(formula->pctltype));
  if (formula->pctltype != AP_PCTL)
    fprintf(codefile, "NULL, ");
  else
    fprintf(codefile, "&mu_pctl_a_p%d, ", formula->code);
  if (formula->pctltype != NEXT_PCTL && formula->pctltype != UNTIL_PCTL)
    fprintf(codefile, "PCTL_L, 0.0, ");
  else
    fprintf(codefile, "%s, %lf, ", getstring(formula->op),
	    formula->prob_bound);
  fprintf(codefile, "%d, ", formula->until_bound);
  if (formula->subformula1 == NULL)
    fprintf(codefile, "NULL, ");
  else
    fprintf(codefile, "&mu_pctl_formula%d, ", formula->subformula1->code);
  if (formula->subformula2 == NULL)
    fprintf(codefile, "NULL");
  else
    fprintf(codefile, "&mu_pctl_formula%d", formula->subformula2->code);
  fprintf(codefile, "};\n");
}

/* considers top untils only; called only if the top formula is not an until */
unsigned pctl::num_top_untils(pctl * f, int ret)
{
  if (f->pctltype == UNTIL_PCTL)
    return ++ret;
  if (f->subformula1 != NULL)
    ret = num_top_untils(f->subformula1, ret);
  if (f->subformula2 != NULL)
    ret = num_top_untils(f->subformula2, ret);
  return ret;
}

/* considers top untils only; called only if the top formula is not an until */
int pctl::ret_top_untils(pctl * formula, unsigned *ret, int i)
{
  if (formula == NULL)
    return i;
  if (formula->pctltype == UNTIL_PCTL) {
    ret[i++] = formula->code;
    return i;
  }
  i = ret_top_untils(formula->subformula1, ret, i);
  i = ret_top_untils(formula->subformula2, ret, i);
  return i;
}

const char *pctl::generate_code()
{
  generate_atomic_subformulas(this);
  generate_non_atomic_subformulas(this);

  return "ERROR!";
}

/********************
  code for quantrule
 ********************/
const char *quantrule::generate_code()
{
  // generate each rule within the quantifier
  for (rule * r = rules; r != NULL; r = r->next)
    r->generate_code();
  return "ERROR!";
}

/********************
  code for chooserule
 ********************/
const char *chooserule::generate_code()
{
  // generate each rule within the quantifier
  for (rule * r = rules; r != NULL; r = r->next)
    r->generate_code();
  return "ERROR!";
}

/********************
  code for aliasrule
 ********************/
const char *aliasrule::generate_code()
{
  // generate each rule within the alias
  for (rule * r = rules; r != NULL; r = r->next)
    r->generate_code();
  return "ERROR!";
}

/******************************
  From here on is all functions that 'globally' affect the world.
 ******************************/

/* process a list of ste\'s in reverse order. */
//ctf
const char *ste::generate_decls()
{
  if (this != NULL) {
    if (next != NULL && next->scope == scope)
      next->generate_decls();
    if(value-> getclass ()==decl:: Const)
    {
		writeblank();
		value->generate_decl();
	}
  }
  return "ERROR!";
}
//change
const char * ste::generate_decls_type()
{
  if (this != NULL) {
    if (next != NULL && next->scope == scope)
      next->generate_decls_type();
  if(value->getclass()==decl:: Type)
  {
      writeblank();
	  value->generate_decl();
  }
  }
  return "ERROR!";
}

const char * ste::generate_decls_record()
{
  if (this != NULL) {
    if (next != NULL && next->scope == scope)
      next->generate_decls_record();
    if(value->getclass()==decl:: Type&& value->gettypeclass()==decl:: Record)
      value->generate_decl();
  }
  return "ERROR!";
}

const char * ste::generate_decls_var()
{
  if (this != NULL) {
    if (next != NULL && next->scope == scope)
      next->generate_decls_var();
    if(value->getclass ()==decl:: Var)
	{
		writeblank();
		value->generate_decl();
	}
  }
  return "ERROR!";
}


// char *ste::generate_alias_decls()
// {
//   if ( this != NULL ) {
//       value->generate_decl();
//       if ( next != NULL && next->scope == scope )
//  next->generate_decls();
//     }
//   return "ERROR!";
// }

typedef void (*varproc) (vardecl * var);

//meiyong 
void map_vars(ste * globals, varproc proc)
/* Calls proc for each variable in the list of declarations. */
{
  ste *next;
  if (globals != NULL) {
    next = globals->getnext();
    if (next != NULL && next->getscope() == globals->getscope())
      map_vars(next, proc);
    if (globals->getvalue()->getclass() == decl::Var) {
      (*proc) ((vardecl *) globals->getvalue());
    }
  }
}


/* The world::print() function prints out the state of every variable.
 * We have to make our own from the variable declarations. */
void make_print_world_aux(vardecl * var)
{
  fprintf(codefile, "  %s.print();\n", var->generate_code());
}

void make_print_world(ste * globals)
     /* done recursively. */
{
  fprintf(codefile,
	  "void world_class::print()\n"
	  "{\n"
	  "  static int num_calls = 0; /* to ward off recursive calls. */\n"
	  "  if ( num_calls == 0 ) {\n" "    num_calls++;\n");
  map_vars(globals, &make_print_world_aux);
  fprintf(codefile, "    num_calls--;\n" "}\n}\n");
}

/* The world::print_statistic() function prints out certain statistic of some variables.
 * We have to make our own from the variable declarations. */
void make_print_statistic_aux(vardecl * var)
{
  fprintf(codefile, "  %s.print_statistic();\n", var->generate_code());
}

void make_print_statistic(ste * globals)
     /* done recursively. */
{
  fprintf(codefile,
	  "void world_class::print_statistic()\n"
	  "{\n"
	  "  static int num_calls = 0; /* to ward off recursive calls. */\n"
	  "  if ( num_calls == 0 ) {\n" "    num_calls++;\n");
  map_vars(globals, &make_print_statistic_aux);
  fprintf(codefile, "    num_calls--;\n" "}\n}\n");
}

/* the world::clear() function clears every variable. */
void make_clear_aux(vardecl * var)
{
  fprintf(codefile, "  %s.clear();\n", var->generate_code());
}

void make_clear(ste * globals)
{
  fprintf(codefile, "void world_class::clear()\n" "{\n");
  map_vars(globals, &make_clear_aux);
  fprintf(codefile, "}\n");
}

/* the world::undefine() function resets every variable to an undefined state. */
void make_undefine_aux(vardecl * var)
{
  fprintf(codefile, "  %s.undefine();\n", var->generate_code());
}

void make_undefine(ste * globals)
{
  fprintf(codefile, "void world_class::undefine()\n" "{\n");
  map_vars(globals, &make_undefine_aux);
  fprintf(codefile, "}\n");
}

/* the world::reset() function resets every variable to an resetd state. */
void make_reset_aux(vardecl * var)
{
  fprintf(codefile, "  %s.reset();\n", var->generate_code());
}

void make_reset(ste * globals)
{
  fprintf(codefile, "void world_class::reset()\n" "{\n");
  map_vars(globals, &make_reset_aux);
  fprintf(codefile, "}\n");
}

/* the world::getstate() function returns a state
 * encoding the state of the world. */
void make_getstate_aux(vardecl * var)
{
  fprintf(codefile, "  %s.to_state( newstate );\n", var->generate_code());
}

void make_getstate(ste * globals)
{
  fprintf(codefile, "void world_class::to_state(state *newstate)\n{\n");
  // fprintf(codefile,"state *newstate = new state;\n");
  /* C++ doesn\'t know what a state looks like yet. Feh. */
  map_vars(globals, &make_getstate_aux);
  // fprintf(codefile,"return newstate;\n");
  fprintf(codefile, "}\n");
}

/* the world::setstate() function sets the world to the state recorded
 * in thestate. */
void make_setstate_aux(vardecl * var)
{
//  fprintf(codefile,"  %s.from_state(thestate);\n",
//    var->generate_code() );
}

void make_setstate(ste * globals)
{
  fprintf(codefile, "void world_class::setstate(state *thestate)\n{\n");
  map_vars(globals, &make_setstate_aux);
  fprintf(codefile, "}\n");
}


void make_print_diff_aux(vardecl * var)
{
  fprintf(codefile, "    %s.print_diff(prevstate);\n",
	  var->generate_code());
}

void make_print_diff(ste * globals)
{
  fprintf(codefile,
	  "void world_class::print_diff( state *prevstate )\n"
	  "{\n" "  if ( prevstate != NULL )\n" "  {\n");
  map_vars(globals, &make_print_diff_aux);
  fprintf(codefile, "  }\n");
  fprintf(codefile, "  else\n" "print();\n");
  fprintf(codefile, "}\n");
}


void make_world(ste * globals)
/* generate the world state. */
{
  make_clear(globals);
  make_undefine(globals);
  make_reset(globals);
  make_print_world(globals);
  make_print_statistic(globals);
  make_print_diff(globals);
  make_getstate(globals);
  make_setstate(globals);
}


/* Generate the global lists of rules.
 * since we can initialize arrays with a list
 * that ends in a comma, we do so here. */

int rulerec::print_rules()
{
  rulerec *r = this;
  int i = 0;
  if (r != NULL) {
    for (; r != NULL; r = r->next) {
    //  fprintf(codefile, "{\"%s\", ", r->rulename);
    //  if (r->conditionname == NULL)
//	fprintf(codefile, "NULL, ");
  //    else
//	fprintf(codefile, "&%s, ", r->conditionname);
  //    if (r->bodyname == NULL)
//	fprintf(codefile, "NULL, ");
  //    else
//	fprintf(codefile, "&%s, ", r->bodyname);
  //    fprintf(codefile, "},\n");
      i++;
    }
  } else {
  //  fprintf(codefile, "{ NULL, NULL, NULL, FALSE }");
  }
  return i;
}

int generate_invariants()
{
  int i = 0;
  simplerule *sr;
  invflag = 1;
  for (sr = invrule; sr != NULL;sr = sr->NextSimpleRule) {
		  sr->generate_code();
    }
	invflag = 0;
  return i;
}

int generate_startstates()
{
  int i = 0;
//startstate   
	if(startrule != NULL)
	{
		startrule->generate_code();
	}
	return i;
}

int generate_ruleset()
{
  int i = 0;
  simplerule *sr;
	simplerule *t;
  ruleflag = 1;
  for (sr = simplerule::SimpleRuleList; sr != NULL;) 
  {
	t = sr->NextSimpleRule;
    
	if (sr->getclass() == rule::Simple && sr != error_rule) 
	{
      sr->ifsearch(sr); 
	}
	else if (sr->getclass() == rule::Startstate)
	{
		startrule = sr;
    }
	else if (sr->getclass() == rule::Invar)
	{
		sr->NextSimpleRule = invrule;
		invrule = sr;
	}
	sr = t;
  }
  ruleflag = 0;
  return i;
}
//ctf add
void simplerule::ifsearch(simplerule *sr)
{
	stmt * b = body;
	if(b != NULL)			
	{
		b->ifsearch2(sr,b);	
		
	}
}


//new generate_code
const char *simplerule::generate_code(simplerule *sr)
{	
//generate ruleset 1
	  if(enclosures != NULL && (enclosures->getvalue()->getclass() == decl::Quant 
		|| enclosures->getvalue()->getclass() == decl::Alias))
	{
		fprintf(codefile, "ruleset  ");	  	  
		generate_rule_params_assignment(enclosures);
		fseek(codefile,-2, SEEK_CUR);
		fprintf(codefile, " do\n");	  
	}
		//generate rule	
			condition->takeno(&condition,0);
			sr->conditionsign();
			fprintf(codefile, "rule \"%s%d\"",name,rnum);
			fprintf(codefile, "\n");
			blankadd();
			//fprintf(codefile,"(");
			condflag = 1;
			condition->generate_code();
			condflag = 0;
			//fprintf(codefile,")");
			fprintf(codefile, "\n==>\n");
			lflag =1;
			locals->search_decls();
			if(cflag ==1)
			{
				fprintf(codefile, "Const\n");
				locals->generate_decls();
				cflag =0;
			}
			if(tflag ==1)
			{
				fprintf(codefile, "Type\n ");
				locals->generate_decls_type();
				tflag =0;
			}
			if(vflag ==1)
		    {
				fprintf(codefile, "Var \n");
				locals->generate_decls_var();
				vflag = 0;
			}
			lflag =0;
			fprintf(codefile, "Begin\n");
			for (stmt * b = body; b != NULL; b = b->next)
			{
				//fprintf(codefile, "      ");
				writeblank();
				b->generate_code();
			}
			blankred();
			fprintf(codefile, "endrule;\n");
			rnum++;
//generate ruleset 2
if(enclosures != NULL && (enclosures->getvalue()->getclass() == decl::Quant 
		|| enclosures->getvalue()->getclass() == decl::Alias))
	{
		fprintf(codefile, "endruleset;\n");	
	}
	fprintf(codefile, "\n");
  return "ERROR!";
}

void simplerule::addcondition(expr *test,int if_flag)
{
	if(if_flag == 1)
	{
		expr *conditionn = NULL;
		conditionn = new boolexpr('&',condition,test);
		condition = conditionn;
	}
	else if(if_flag ==0 )
	{
		expr *conditionn2 = NULL;
		expr *conditionn3 = NULL;
		conditionn2 = new notexpr(test);
		conditionn3 = new boolexpr('&',condition,conditionn2);
		condition = conditionn3;
	}
	else
	{}
}

//stmt add

//ifsearch1
void ifstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = body;
	stmt * s2 = ifn;
	stmt * s3 = NULL;
	Stack st1,st2;
	Copy(st,st1);
	Copy(st,st2);
	if(s1 == NULL)
	{}
	else
	{
		if(s2->next != NULL)
		{
			Push(st1,s2->next);
			Push(st2,s2->next);
		}
		isdecleared = 1;
		//use for add condition
		simplerule *sr1 = NULL;
		sr->copy(&sr1);
		sr1->addcondition(test,1);
		//add condition end
		s1->ifsearch1(sr1,s1,st1);
		
		isdecleared = 0;
		//use for add condition
		simplerule *sr2 = NULL;
		sr->copy(&sr2);
		sr2->addcondition(test,0);
		//add condition end
		if(elsecode == NULL)
		{
			Pop(st2,&s3);
			if(IsEmpty(st2))
			{
				s3->ifsearch2(sr2,s3);
			}
			else
			{
				s3->ifsearch1(sr2,s3,st2);
			}
		}
		else
		{
			elsecode->ifsearch1(sr2,elsecode,st2);
		}
	}
	

	
}
void stmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void assignment::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = ifn;	
	stmt * s2 = NULL;
	if(s1->next != NULL)
	{
		(s1->next)->ifsearch1(sr,s1->next,st);
	}
	else
	{
			Pop(st,&s2);
			if(IsEmpty(st))
			{
				s2->ifsearch2(sr,s2);
			}
			else
			{
				s2->ifsearch1(sr,s2,st);
			}
	}
}
void whilestmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = ifn;	
	stmt * s2 = NULL;
	if(s1->next != NULL)
	{
		(s1->next)->ifsearch1(sr,s1->next,st);
	}
	else
	{
			Pop(st,&s2);
			if(IsEmpty(st))
			{
				s2->ifsearch2(sr,s2);
			}
			else
			{
				s2->ifsearch1(sr,s2,st);
			}
	}
}
void switchstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = ifn;	
	stmt * s2 = NULL;
	if(s1->next != NULL)
	{
		(s1->next)->ifsearch1(sr,s1->next,st);
	}
	else
	{
			Pop(st,&s2);
			if(IsEmpty(st))
			{
				s2->ifsearch2(sr,s2);
			}
			else
			{
				s2->ifsearch1(sr,s2,st);
			}
	}
}
void forstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = ifn;	
	stmt * s2 = NULL;
	if(s1->next != NULL)
	{
		(s1->next)->ifsearch1(sr,s1->next,st);
	}
	else
	{
			Pop(st,&s2);
			if(IsEmpty(st))
			{
				s2->ifsearch2(sr,s2);
			}
			else
			{
				s2->ifsearch1(sr,s2,st);
			}
	}
}
void proccall::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void clearstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = ifn;	
	stmt * s2 = NULL;
	if(s1->next != NULL)
	{
		(s1->next)->ifsearch1(sr,s1->next,st);
	}
	else
	{
			Pop(st,&s2);
			if(IsEmpty(st))
			{
				s2->ifsearch2(sr,s2);
			}
			else
			{
				s2->ifsearch1(sr,s2,st);
			}
	}
}
void undefinestmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{
	stmt * s1 = ifn;	
	stmt * s2 = NULL;
	if(s1->next != NULL)
	{
		(s1->next)->ifsearch1(sr,s1->next,st);
	}
	else
	{
			Pop(st,&s2);
			if(IsEmpty(st))
			{
				s2->ifsearch2(sr,s2);
			}
			else
			{
				s2->ifsearch1(sr,s2,st);
			}
	}
}
void multisetaddstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void multisetremovestmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void errorstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void assertstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void putstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void aliasstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
void returnstmt::ifsearch1(simplerule *sr,stmt *ifn,Stack &st)
{}
//ifsearch1 end


//ifsearch2
void ifstmt::ifsearch2(simplerule *sr,stmt *ifn)
{
	stmt * s1 = body;
	stmt * s2 = ifn;
	Stack st1,st2;
	Init(st1);
	Init(st2);
	//1
	if(s1 == NULL){}
	else
	{
		//last code is if
		if(s2->next ==NULL)
		{
			if(elsecode == NULL)
			{	
				isdecleared =1;
				//use for add condition
				simplerule *sr1 = NULL;
				sr->copy(&sr1);
				sr1->addcondition(test,1);
				//add condition end
				s1->ifsearch2(sr1,s1);
				
				isdecleared = 0;
				//use for add condition
				simplerule *sr2 = NULL;
				sr->copy(&sr2);
				sr2->addcondition(test,0);
				//add condition end
				sr2->NextSimpleRule = NULL;
				for(simplerule *srf = sr2;srf != NULL;srf = srf->NextSimpleRule)
				{
					srf->generate_code(srf);					
				}

			}
			else
			{
				isdecleared =1;
				//use for add condition
				simplerule *sr3 = NULL;
				sr->copy(&sr3);
				sr3->addcondition(test,1);
				//add condition end
				s1->ifsearch2(sr3,s1);
				
				isdecleared = 0;
				//use for add condition
				simplerule *sr4 = NULL;
				sr->copy(&sr4);
				sr4->addcondition(test,0);
				//add condition end
				elsecode->ifsearch2(sr4,elsecode);
			}
		}
		else
		{
			isdecleared = 1;
			//use for add condition
			simplerule *sr5 = NULL;
			sr->copy(&sr5);
			sr5->addcondition(test,1);				
			//add condition end
			Push(st1,s2->next);
			s1->ifsearch1(sr5,s1,st1);
			
			isdecleared = 0;
			//use for add condition
			simplerule *sr6 = NULL;
			sr->copy(&sr6);
			sr6->addcondition(test,0);
			//add condition end
			if(elsecode != NULL)
			{
					Push(st2,s2->next);
					elsecode->ifsearch1(sr6,elsecode,st2);
			}
			else
			{		
				(s2->next)->ifsearch2(sr6,s2->next);
			}	
		}
	}

	}
void stmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void assignment::ifsearch2(simplerule *sr,stmt *ifn)
{
	stmt * s = ifn;	
	if(s->next == NULL)
	{
		sr->NextSimpleRule = NULL;
		for(simplerule *srf = sr;srf != NULL;srf = srf->NextSimpleRule)
		{
			srf->generate_code(srf);					
		}
	}
	else
	{
		(s->next)->ifsearch2(sr,s->next);
	}
}
void whilestmt::ifsearch2(simplerule *sr,stmt *ifn)
{
		stmt * s = ifn;	
	if(s->next == NULL)
	{
		sr->NextSimpleRule = NULL;
		for(simplerule *srf = sr;srf != NULL;srf = srf->NextSimpleRule)
		{
			srf->generate_code(srf);					
		}
	}
	else
	{
		(s->next)->ifsearch2(sr,s->next);
	}
}
void switchstmt::ifsearch2(simplerule *sr,stmt *ifn)
{
		stmt * s = ifn;	
	if(s->next == NULL)
	{
		sr->NextSimpleRule = NULL;
		for(simplerule *srf = sr;srf != NULL;srf = srf->NextSimpleRule)
		{
			srf->generate_code(srf);					
		}
	}
	else
	{
		(s->next)->ifsearch2(sr,s->next);
	}
}
void forstmt::ifsearch2(simplerule *sr,stmt *ifn)
{
		stmt * s = ifn;	
	if(s->next == NULL)
	{
		sr->NextSimpleRule = NULL;
		for(simplerule *srf = sr;srf != NULL;srf = srf->NextSimpleRule)
		{
			srf->generate_code(srf);					
		}
	}
	else
	{
		(s->next)->ifsearch2(sr,s->next);
	}
}
void proccall::ifsearch2(simplerule *sr,stmt *ifn)
{}
void clearstmt::ifsearch2(simplerule *sr,stmt *ifn)
{
	stmt * s = ifn;	
	if(s->next == NULL)
	{
		sr->NextSimpleRule = NULL;
		for(simplerule *srf = sr;srf != NULL;srf = srf->NextSimpleRule)
		{
			srf->generate_code(srf);					
		}
	}
	else
	{
		(s->next)->ifsearch2(sr,s->next);
	}
}
void undefinestmt::ifsearch2(simplerule *sr,stmt *ifn)
{
		stmt * s = ifn;	
	if(s->next == NULL)
	{
		sr->NextSimpleRule = NULL;
		for(simplerule *srf = sr;srf != NULL;srf = srf->NextSimpleRule)
		{
			srf->generate_code(srf);					
		}
	}
	else
	{
		(s->next)->ifsearch2(sr,s->next);
	}
}
void multisetaddstmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void multisetremovestmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void errorstmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void assertstmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void putstmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void aliasstmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
void returnstmt::ifsearch2(simplerule *sr,stmt *ifn)
{}
//ifsearch2 end
//copy 
void simplerule::copy(simplerule **srn)
{
  expr *conditionn = NULL;
  condition->copy(&conditionn);
  *srn = new simplerule(enclosures,conditionn,locals,body,priority);
  (*srn)->set_name(name);
}

void expr::copy(expr **exprn)
{
	(*exprn) = this;
}

void condexpr::copy(expr **exprn)
{
	expr *testn = NULL;
	test->copy(&testn);
	expr *leftn = NULL;
	left->copy(&leftn);
	expr *rightn = NULL;
	right->copy(&rightn);
	(*exprn) = new condexpr(testn,leftn,rightn);
}

void boolexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	expr *rightn = NULL;
	right->copy(&rightn);
	(*exprn) = new boolexpr(op,leftn,rightn,flagor);
}

void notexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	(*exprn) = new notexpr(leftn);
}

void compexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	expr *rightn = NULL;
	right->copy(&rightn);
	(*exprn) = new compexpr(op,leftn,rightn);
}

void equalexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	expr *rightn = NULL;
	right->copy(&rightn);
	(*exprn) = new equalexpr(op,leftn,rightn);
}

void arithexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	expr *rightn = NULL;
	right->copy(&rightn);
	(*exprn) = new arithexpr(op,leftn,rightn);
}


void unexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	(*exprn) = new unexpr(op,leftn);
}

void mulexpr::copy(expr **exprn)
{
	expr *leftn = NULL;
	left->copy(&leftn);
	expr *rightn = NULL;
	right->copy(&rightn);
	(*exprn) = new mulexpr(op,leftn,rightn);
}

void designator::copy(expr **exprn)
{
  (*exprn) = this;
}

void mathexpr::copy(expr **exprn)
{
  (*exprn) = this;
}

void unaryexpr::copy(expr **exprn)
{
  (*exprn) = this;
}

void binaryexpr::copy(expr **exprn)
{
  (*exprn) = this;
}

void quantexpr::copy(expr **exprn)
{
  (*exprn) = this;
}
void funccall::copy(expr **exprn)
{
	 (*exprn) = this;
}
void isundefined::copy(expr **exprn)
{
	 (*exprn) = this;
}
void ismember::copy(expr **exprn)
{
	 (*exprn) = this;
}
void multisetcount::copy(expr **exprn)
{
	 (*exprn) = this;
}

//sign
void simplerule::conditionsign()
{
	if(condition != NULL)
	{
		condition->sign(this);	
	}

}

void expr::sign(simplerule *sr)
{}

void condexpr::sign(simplerule *sr)
{
			left->sign(sr);
		right->sign(sr);
}

void boolexpr::sign(simplerule *sr)
{
	if(flagor == 100)
	{
		if(op == '|' || op == IMPLIES)
		{
			simplerule *temp = NULL;
			flagor = 1;
			simplerule *srn = NULL;
			sr->copy(&srn);
			right->sign(srn);
			
			temp = sr->NextSimpleRule;
			sr->NextSimpleRule = srn;
			srn->NextSimpleRule = temp;
			
			flagor = 0;
			left->sign(sr);
			
		}
		
		else
		{
			left->sign(sr);
			right->sign(sr);
		}
	}
}

void notexpr::sign(simplerule *sr)
{
	left->sign(sr);
}

void compexpr::sign(simplerule *sr)
{
			left->sign(sr);
		right->sign(sr);
}

void equalexpr::sign(simplerule *sr)
{
		left->sign(sr);
		right->sign(sr);	
}

void arithexpr::sign(simplerule *sr)
{
			left->sign(sr);
		right->sign(sr);
}

void unexpr::sign(simplerule *sr)
{
			left->sign(sr);
}

void mulexpr::sign(simplerule *sr)
{
			left->sign(sr);
		right->sign(sr);
}

void designator::sign(simplerule *sr)
{}

void mathexpr::sign(simplerule *sr)
{}

void unaryexpr::sign(simplerule *sr)
{}

void binaryexpr::sign(simplerule *sr)
{}

void quantexpr::sign(simplerule *sr)
{}

void funccall::sign(simplerule *sr)
{}
void isundefined::sign(simplerule *sr)
{}
void ismember::sign(simplerule *sr)
{}
void multisetcount::sign(simplerule *sr)
{}
//takeno start
void expr::takeno(expr **exprn,int flag)
{}
void condexpr::takeno(expr **exprn,int flag)
{}
void boolexpr::takeno(expr **exprn,int flag)
{
	expr *conditionn1 = NULL;
	expr *conditionn2 = NULL;
	if(flag ==1)
	{
		switch (op) 
		{
				case IMPLIES:
				conditionn1 = new notexpr(right);
				left->takeno(&left,0);
				conditionn1->takeno(&conditionn1,0);
				(*exprn) = new boolexpr('&',left,conditionn1);
				  break;
				case '|':
				conditionn1 = new notexpr(left);
				conditionn2 = new notexpr(right);
				conditionn1->takeno(&conditionn1,0);
				conditionn2->takeno(&conditionn2,0);
				(*exprn) = new boolexpr('&',conditionn1,conditionn2);
				  break;
				case '&':
				conditionn1 = new notexpr(left);
				conditionn2 = new notexpr(right);
				conditionn1->takeno(&conditionn1,0);
				conditionn2->takeno(&conditionn2,0);
				(*exprn) = new boolexpr('|',conditionn1,conditionn2); 

				  break;
				default:
				  Error.Error
				  ("Internal: funky value for op in boolexpr::generate_code()");
				  break;
		}
	}
	else
	{
		if(op == IMPLIES)
		{
			conditionn1 = new notexpr(left);
			conditionn1->takeno(&conditionn1,0);
			right->takeno(&right,0);
			(*exprn) = new boolexpr('|',conditionn1,right);
		}
		else
		{
			left->takeno(&left,0);
			right->takeno(&right,0);
		}
	}
}
void notexpr::takeno(expr **exprn,int flag)
{
	if(flag ==1)
	{
		left->takeno(&left,0);
		(*exprn) = left;
	}
	else
	{
		left->takeno(&left,1);
		(*exprn) = left;
	}
}
void compexpr::takeno(expr **exprn,int flag)
{
	if(flag == 1)	
	{
		switch (op) 
		{
			case '<':
				left->takeno(&left,0);
				right->takeno(&right,0);
				(*exprn) = new compexpr('>=',left,right);
				break;
			case LEQ:
				left->takeno(&left,0);
				right->takeno(&right,0);
				(*exprn) = new compexpr('>',left,right);
					break;
			case '>':
				left->takeno(&left,0);
				right->takeno(&right,0);
				(*exprn) = new compexpr('<=',left,right);
					break;
			case GEQ:
				left->takeno(&left,0);
				right->takeno(&right,0);
				(*exprn) = new compexpr('<',left,right);
					break;
			default:
			  Error.Error("Internal: odd value in compexpr::generate_code()");
					break;
		}
	}
	else
	{
		left->takeno(&left,0);
		right->takeno(&right,0);
	}
}

void equalexpr::takeno(expr **exprn,int flag)
{
	expr *conditionn1 = NULL;
	if(flag == 1)	
	{
		switch (op) 
		{
			case '=':

				left->takeno(&left,0);
				right->takeno(&right,0);
				conditionn1 = new equalexpr(NEQ,left,right);
				(*exprn) = conditionn1;
				break;
			case NEQ:

				left->takeno(&left,0);
				right->takeno(&right,0);
				conditionn1 = new equalexpr('=',left,right);
				(*exprn) = conditionn1;
					break;
			default:
			  Error.Error("Internal: odd value in compexpr::generate_code()");
					break;
		}
	}
	else
	{
		left->takeno(&left,0);
		right->takeno(&right,0);
	}
}

void arithexpr::takeno(expr **exprn,int flag)
{}

void unexpr::takeno(expr **exprn,int flag)
{}

void mulexpr::takeno(expr **exprn,int flag)
{}

void designator::takeno(expr **exprn,int flag)
{
	expr *conditionn1 = NULL;
	if(flag == 1)
	{
		conditionn1 = new notexpr(*exprn);
		(*exprn) = conditionn1;
	}
	else
	{}
}

void mathexpr::takeno(expr **exprn,int flag)
{}

void unaryexpr::takeno(expr **exprn,int flag)
{}

void binaryexpr::takeno(expr **exprn,int flag)
{}

void quantexpr::takeno(expr **exprn,int flag)
{
		expr *conditionn1 = NULL;
		if(flag ==1)
		{
			conditionn1 = new notexpr(*exprn);
			(*exprn) = conditionn1;
		}
		else
		{}
}
void funccall::takeno(expr **exprn,int flag)
{}
void isundefined::takeno(expr **exprn,int flag)
{}
void ismember::takeno(expr **exprn,int flag)
{}
void multisetcount::takeno(expr **exprn,int flag)
{}
//takeno end

const char *ste::search_decls()
{
  if (this != NULL) 
  {
    if (next != NULL && next->scope == scope)
      next->generate_decls();
    if(value-> getclass ()==decl:: Const)
    {
		cflag = 1;
	}
	if(value->getclass()==decl:: Type)
	{
		tflag = 1;
	}
	if(value->getclass ()==decl:: Var)
	{
		vflag = 1;
	}
  }
  return "ERROR!";
}


/******************************
  The main program
 ******************************/

const char *program::generate_code()
{
fprintf(codefile, "\nconst\n\n");
blankadd();
procedures->generate_decls();
fprintf(codefile, "\ntype\n\n");
procedures->generate_decls_type();
fprintf(codefile, "\nvar\n\n");
procedures->generate_decls_var();
blankred();
fprintf(codefile, "\n");
generate_ruleset();
generate_startstates();
generate_invariants();

}

