Const clientNUMS : 5;
Type 
state : enum{I, T, C, E, A, B, Q, W, R, AA, AAA};
client: 1..clientNUMS;
Var n : array [client] of state;
    x : boolean; 
	a : client;
	
	
	
ruleset ctf : client do
	rule "Try" 
	n[ctf] = I
	==> 
		begin
		if(forall p : client do p != ctf->ctf = ctf end) then
		n[ctf] := AA;
		endif;
		
	end;
end;
startstate
begin
  x := true;
end;
ruleset ii:client; jj: client do
invariant "coherence"
  ii != jj -> (n[ii] = C -> n[jj] != C);
endruleset;

