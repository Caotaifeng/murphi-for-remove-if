const

  NODE_NUM : 2;
  DATA_NUM : 2;

type

  NODE : scalarset(NODE_NUM);
  DATA : scalarset(DATA_NUM);


  CACHE_STATE : enum {CACHE_I, CACHE_S, CACHE_E};

  NODE_CMD : enum {NODE_None, NODE_Get, NODE_GetX};

  NODE_STATE : record
    ProcCmd : NODE_CMD;
    InvMarked : boolean;
    CacheState : CACHE_STATE;
    CacheData : DATA;
  end;

  DIR_STATE : record
    Pending : boolean;
    Local : boolean;
    Dirty : boolean;
    HeadVld : boolean;
    HeadPtr : NODE;
    ShrVld : boolean;
    InvSet : array [NODE] of boolean;
    ShrSet : array [NODE] of boolean;
    HomeHeadPtr : boolean;
    HomeShrSet : boolean;
    HomeInvSet : boolean;
  end;


  UNI_CMD : enum {UNI_None, UNI_Get, UNI_GetX, UNI_Put, UNI_PutX, UNI_Nak};

  UNI_MSG : record
    Cmd : UNI_CMD;
    Proc : NODE;
    HomeProc : boolean;
    Data : DATA;
  end;

  INV_CMD : enum {INV_None, INV_Inv, INV_InvAck};

  INV_MSG : record
    Cmd : INV_CMD;
  end;

  RP_CMD : enum {RP_None, RP_Replace};

  RP_MSG : record
    Cmd : RP_CMD;
  end;

  WB_CMD : enum {WB_None, WB_Wb};

  WB_MSG : record
    Cmd : WB_CMD;
    Proc : NODE;
    HomeProc : boolean;
    Data : DATA;
  end;

  SHWB_CMD : enum {SHWB_None, SHWB_ShWb, SHWB_FAck};

  SHWB_MSG : record
    Cmd : SHWB_CMD;
    Proc : NODE;
    HomeProc : boolean;
    Data : DATA;
  end;


  NAKC_CMD : enum {NAKC_None, NAKC_Nakc};

  NAKC_MSG : record
    Cmd : NAKC_CMD;
  end;


  STATE : record
    -- states variables
    Proc : array [NODE] of NODE_STATE;
    Dir : DIR_STATE;
    MemData : DATA;
    UniMsg : array [NODE] of UNI_MSG;
    InvMsg : array [NODE] of INV_MSG;
    RpMsg : array [NODE] of RP_MSG;
    WbMsg : WB_MSG;
    ShWbMsg : SHWB_MSG;
    NakcMsg : NAKC_MSG;

    -- Home variables
    HomeProc : NODE_STATE;
    HomeUniMsg : UNI_MSG;
    HomeInvMsg : INV_MSG;
    HomeRpMsg : RP_MSG;
    PendReqSrcHome : boolean;
    LastOtherInvAckHome : boolean;
    LastWrPtrHome : boolean;

    -- Auxiliary variables
    CurrData : DATA;
    PrevData : DATA;
    LastWrVld : boolean;
    LastWrPtr : NODE;
    PendReqSrc : NODE;
    PendReqCmd : UNI_CMD;
    Collecting : boolean;
    FwdCmd : UNI_CMD;
    FwdSrc : NODE;
    LastInvAck : NODE;
    LastOtherInvAck : NODE;
  end;

var

  Sta : STATE;

-------------------------------------------------------------------------------

ruleset d : DATA do
startstate "Init"
  Sta.MemData := d;
  Sta.Dir.Pending := false;
  Sta.Dir.Local := false;
  Sta.Dir.Dirty := false;
  Sta.Dir.HeadVld := false;
  Sta.Dir.ShrVld := false;
  Sta.WbMsg.Cmd := WB_None;
  Sta.ShWbMsg.Cmd := SHWB_None;
  Sta.NakcMsg.Cmd := NAKC_None;
  --
  Sta.WbMsg.HomeProc := true;
  Sta.ShWbMsg.HomeProc := true;
  Sta.Dir.HomeHeadPtr := true;
  Sta.PendReqSrcHome := true;
  Sta.LastOtherInvAckHome := true;
  Sta.LastWrPtrHome := true;

  for p : NODE do
    Sta.Proc[p].ProcCmd := NODE_None;
    Sta.Proc[p].InvMarked := false;
    Sta.Proc[p].CacheState := CACHE_I;
    Sta.Dir.ShrSet[p] := false;
    Sta.Dir.InvSet[p] := false;
    Sta.UniMsg[p].Cmd := UNI_None;
    Sta.InvMsg[p].Cmd := INV_None;
    Sta.RpMsg[p].Cmd := RP_None;

    Sta.UniMsg[p].HomeProc := true;
  end;

  Sta.HomeProc.ProcCmd := NODE_None;
  Sta.HomeProc.InvMarked := false;
  Sta.HomeProc.CacheState := CACHE_I;
  Sta.HomeProc.CacheData := d;
  Sta.Dir.HomeShrSet := false;
  Sta.Dir.HomeInvSet := false;
  Sta.HomeUniMsg.Cmd := UNI_None;
  Sta.HomeUniMsg.HomeProc := true;
  Sta.HomeUniMsg.Data := d;
  Sta.HomeInvMsg.Cmd := INV_None;
  Sta.HomeRpMsg.Cmd := RP_None;
  Sta.CurrData := d;
  Sta.PrevData := d;
  Sta.LastWrVld := false;
  Sta.Collecting := false;
  Sta.FwdCmd := UNI_None;
endstartstate;
endruleset;
-------------------------------------------------------------------------------

ruleset src : NODE; data : DATA do
rule "Store"
  Sta.Proc[src].CacheState = CACHE_E
==>
begin
  Sta.Proc[src].CacheData := data;
  Sta.CurrData := data;
  Sta.LastWrVld := true;
  Sta.LastWrPtr := src;
  Sta.LastWrPtrHome := false;
endrule;
endruleset;

ruleset data : DATA do
rule "Store_Home"
  Sta.HomeProc.CacheState = CACHE_E
==>
begin
  Sta.HomeProc.CacheData := data;
  Sta.CurrData := data;
  Sta.LastWrVld := false;
  undefine Sta.LastWrPtr;
  Sta.LastWrPtrHome := true;

endrule;
endruleset;

ruleset src : NODE do
rule "PI_Remote_Get"
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_I
==>

begin

--
  Sta.Proc[src].ProcCmd := NODE_Get;
  Sta.UniMsg[src].Cmd := UNI_Get;
  Sta.UniMsg[src].HomeProc := true;
  undefine Sta.UniMsg[src].Data;
--

endrule;
endruleset;

rule "PI_Local_Get_Get"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_I &
  Sta.Dir.Pending = false & Sta.Dir.Dirty = true
==>

begin

--
  Sta.HomeProc.ProcCmd := NODE_Get;
  Sta.Dir.Pending := true;
  Sta.HomeUniMsg.Cmd := UNI_Get;
  Sta.HomeUniMsg.HomeProc := Sta.Dir.HomeHeadPtr;
  undefine Sta.HomeUniMsg.Data;
  if (Sta.Dir.HomeHeadPtr = false) then
    Sta.FwdCmd := UNI_Get;
  end;
  Sta.PendReqSrcHome := true;
  Sta.PendReqCmd := UNI_Get;
  Sta.Collecting := false;
--

endrule;

rule "PI_Local_Get_Put"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_I &
  Sta.Dir.Pending = false & Sta.Dir.Dirty = false
==>

begin

--
  Sta.Dir.Local := true;
  Sta.HomeProc.ProcCmd := NODE_None;
  if (Sta.HomeProc.InvMarked) then
    Sta.HomeProc.InvMarked := false;
    Sta.HomeProc.CacheState := CACHE_I;
    undefine Sta.HomeProc.CacheData;
  else
    Sta.HomeProc.CacheState := CACHE_S;
    Sta.HomeProc.CacheData := Sta.MemData;
  end;
--

endrule;

ruleset src : NODE do
rule "PI_Remote_GetX"
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_I
==>

begin

--
  Sta.Proc[src].ProcCmd := NODE_GetX;
  Sta.UniMsg[src].Cmd := UNI_GetX;
  Sta.UniMsg[src].HomeProc := true;
  undefine Sta.UniMsg[src].Data;
--

endrule;
endruleset;

rule "PI_Local_GetX_GetX"
  Sta.HomeProc.ProcCmd = NODE_None &
  ( Sta.HomeProc.CacheState = CACHE_I |
    Sta.HomeProc.CacheState = CACHE_S ) &
  Sta.Dir.Pending = false & Sta.Dir.Dirty = true
==>

begin

--
  Sta.HomeProc.ProcCmd := NODE_GetX;
  Sta.Dir.Pending := true;
  Sta.HomeUniMsg.Cmd := UNI_GetX;
  Sta.HomeUniMsg.Proc := Sta.Dir.HeadPtr;
  Sta.HomeUniMsg.HomeProc := true;
  if (Sta.Dir.HomeHeadPtr = false) then
    Sta.FwdCmd := UNI_GetX;
  end;
  Sta.PendReqSrcHome := true;

  Sta.PendReqCmd := UNI_GetX;
  Sta.Collecting := false;
  undefine Sta.HomeUniMsg.Data;

--

endrule;

rule "PI_Local_GetX_PutX"
  Sta.HomeProc.ProcCmd = NODE_None &
  ( Sta.HomeProc.CacheState = CACHE_I |
    Sta.HomeProc.CacheState = CACHE_S ) &
  !Sta.Dir.Pending & !Sta.Dir.Dirty
==>

begin

--
  Sta.Dir.Local := true;
  Sta.Dir.Dirty := true;
  if (Sta.Dir.HeadVld) then
    Sta.Dir.Pending := true;
    Sta.Dir.HeadVld := false;
    undefine Sta.Dir.HeadPtr;
    Sta.Dir.ShrVld := false;
    for p : NODE do
      Sta.Dir.ShrSet[p] := false;
      if ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
             Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p ) then
        Sta.Dir.InvSet[p] := true;
        Sta.InvMsg[p].Cmd := INV_Inv;
      else
        Sta.Dir.InvSet[p] := false;
        Sta.InvMsg[p].Cmd := INV_None;
      end;
    end;
    Sta.Collecting := true;
    Sta.PrevData := Sta.CurrData;
    Sta.LastOtherInvAck := Sta.Dir.HeadPtr;
    --
    Sta.LastOtherInvAckHome := false;
    --
  end;
  Sta.HomeProc.ProcCmd := NODE_None;
  Sta.HomeProc.InvMarked := false;
  Sta.HomeProc.CacheState := CACHE_E;
  Sta.HomeProc.CacheData := Sta.MemData;
--

endrule;

ruleset dst : NODE do
rule "PI_Remote_PutX"
  -- dst != Home &
  Sta.Proc[dst].ProcCmd = NODE_None &
  Sta.Proc[dst].CacheState = CACHE_E
==>

begin

--
  Sta.Proc[dst].CacheState := CACHE_I;
  Sta.WbMsg.Cmd := WB_Wb;
  Sta.WbMsg.Proc := dst;
  --
  Sta.WbMsg.HomeProc := false;
  --
  Sta.WbMsg.Data := Sta.Proc[dst].CacheData;
  undefine Sta.Proc[dst].CacheData;

  Sta.WbMsg.HomeProc := false;

--

endrule;
endruleset;

rule "PI_Local_PutX"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_E
==>

begin

  if (Sta.Dir.Pending = true) then
    Sta.HomeProc.CacheState := CACHE_I;
    Sta.Dir.Dirty := false;
    Sta.MemData := Sta.HomeProc.CacheData;
    undefine Sta.HomeProc.CacheData;
  else
    Sta.HomeProc.CacheState := CACHE_I;
    Sta.Dir.Local := false;
    Sta.Dir.Dirty := false;
    Sta.MemData := Sta.HomeProc.CacheData;
    undefine Sta.HomeProc.CacheData;

  end;

endrule;

ruleset src : NODE do
rule "PI_Remote_Replace"
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_S
==>

begin

  Sta.Proc[src].CacheState := CACHE_I;
  Sta.RpMsg[src].Cmd := RP_Replace;
  undefine Sta.Proc[src].CacheData;


endrule;
endruleset;

rule "PI_Local_Replace"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_S
==>

begin

--
  Sta.Dir.Local := false;
  Sta.HomeProc.CacheState := CACHE_I;
  undefine Sta.HomeProc.CacheData;
--

endrule;

ruleset dst : NODE do
rule "NI_Nak"
  Sta.UniMsg[dst].Cmd = UNI_Nak
==>

begin

--
  Sta.UniMsg[dst].Cmd := UNI_None;
  Sta.Proc[dst].ProcCmd := NODE_None;
  Sta.Proc[dst].InvMarked := false;
  undefine Sta.UniMsg[dst].Proc;
  undefine Sta.UniMsg[dst].Data;
--

endrule;
endruleset;

rule "NI_Nak_Clear"
  Sta.NakcMsg.Cmd = NAKC_Nakc
==>

begin

--
  Sta.NakcMsg.Cmd := NAKC_None;
  Sta.Dir.Pending := false;
--

endrule;

ruleset src : NODE do
rule "NI_Local_Get_Nak"
  -- src != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc = true &
  Sta.RpMsg[src].Cmd != RP_Replace &
  ( Sta.Dir.Pending |
    Sta.Dir.Dirty & Sta.Dir.Local & Sta.HomeProc.CacheState != CACHE_E |
    Sta.Dir.Dirty & !Sta.Dir.Local & Sta.Dir.HeadPtr = src )
==>

begin

--
  Sta.UniMsg[src].Cmd := UNI_Nak;
  Sta.UniMsg[src].HomeProc := true;
  undefine Sta.UniMsg[src].Data;
--

endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_Get_Get"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc = true &
  Sta.RpMsg[src].Cmd != RP_Replace &
  !Sta.Dir.Pending & Sta.Dir.Dirty & !Sta.Dir.Local & Sta.Dir.HeadPtr != src
==>

begin

--
  Sta.Dir.Pending := true;
  Sta.UniMsg[src].Cmd := UNI_Get;
  Sta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  Sta.UniMsg[src].HomeProc := Sta.Dir.HomeHeadPtr;
  if (Sta.Dir.HomeHeadPtr = false) then
    Sta.FwdCmd := UNI_Get;
  end;
  Sta.PendReqSrc := src;
  Sta.PendReqSrcHome := false;
  Sta.PendReqCmd := UNI_Get;
  Sta.Collecting := false;
  undefine Sta.UniMsg[src].Data;
--

endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_Get_Put"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc = true &
  Sta.RpMsg[src].Cmd != RP_Replace &
  Sta.Dir.Pending = false &
  (Sta.Dir.Dirty -> Sta.Dir.Local & Sta.HomeProc.CacheState = CACHE_E)
==>

begin

  if (Sta.Dir.Dirty = true) then
    Sta.Dir.Dirty := false;
    Sta.Dir.HeadVld := true;
    Sta.Dir.HeadPtr := src;
    Sta.Dir.HomeHeadPtr := false;
    Sta.MemData := Sta.HomeProc.CacheData;
    Sta.HomeProc.CacheState := CACHE_S;
    Sta.UniMsg[src].Cmd := UNI_Put;
    Sta.UniMsg[src].HomeProc := true;
    Sta.UniMsg[src].Data := Sta.HomeProc.CacheData;
  else
    if (Sta.Dir.HeadVld = true) then
      Sta.Dir.ShrVld := true;
      Sta.Dir.ShrSet[src] := true;
      for p : NODE do
        Sta.Dir.InvSet[p] := (p = src) | Sta.Dir.ShrSet[p];
      end;
    else
      Sta.Dir.HeadVld := true;
      Sta.Dir.HeadPtr := src;
      Sta.Dir.HomeHeadPtr := false;
    end;
    Sta.UniMsg[src].Cmd := UNI_Put;
    Sta.UniMsg[src].HomeProc := True;
    Sta.UniMsg[src].Data := Sta.MemData;
  end;

endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_Get_Nak"
  src != dst & -- dst != Home &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState != CACHE_E
==>

begin

--
  Sta.UniMsg[src].Cmd := UNI_Nak;
  Sta.UniMsg[src].Proc := dst;
  Sta.NakcMsg.Cmd := NAKC_Nakc;
  Sta.FwdCmd := UNI_None;
  Sta.FwdSrc := src;
  undefine Sta.UniMsg[src].Data;

--

endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_Get_Put"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState = CACHE_E
==>

begin

--
  Sta.Proc[dst].CacheState := CACHE_S;
  Sta.UniMsg[src].Cmd := UNI_Put;
  Sta.UniMsg[src].Proc := dst;
  Sta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  Sta.ShWbMsg.Cmd := SHWB_ShWb;
  Sta.ShWbMsg.Proc := src;
  Sta.ShWbMsg.HomeProc := false;
  Sta.ShWbMsg.Data := Sta.Proc[dst].CacheData;
  Sta.FwdCmd := UNI_None;
  Sta.FwdSrc := src;


endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_Nak"
  -- src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc = true &
  ( Sta.Dir.Pending |
    Sta.Dir.Dirty & Sta.Dir.Local & Sta.HomeProc.CacheState != CACHE_E |
    Sta.Dir.Dirty & !Sta.Dir.Local & Sta.Dir.HeadPtr = src )
==>

begin

--
  Sta.UniMsg[src].Cmd := UNI_Nak;
  Sta.UniMsg[src].HomeProc := true;
  undefine Sta.UniMsg[src].Data;
--

endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_GetX"
  -- src != Home &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc = true &
  Sta.Dir.Pending = false & Sta.Dir.Dirty = true & Sta.Dir.Local = false & Sta.Dir.HeadPtr != src
==>

begin

--
  Sta.Dir.Pending := true;
  Sta.UniMsg[src].Cmd := UNI_GetX;
  Sta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  Sta.UniMsg[src].HomeProc := Sta.Dir.HomeHeadPtr;
  if (Sta.Dir.HomeHeadPtr = false) then
    Sta.FwdCmd := UNI_GetX;
  end;
  Sta.PendReqSrc := src;
  Sta.PendReqSrcHome := false;
  Sta.PendReqCmd := UNI_GetX;
  Sta.Collecting := false;
  undefine Sta.UniMsg[src].Data;

--

endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc = true &
  Sta.Dir.Pending = false &
  (Sta.Dir.Dirty = true -> Sta.Dir.Local & Sta.HomeProc.CacheState = CACHE_E)
==>

begin

  if (Sta.Dir.Dirty) then
    Sta.Dir.Local := false;
    Sta.Dir.Dirty := true;
    Sta.Dir.HeadVld := true;
    Sta.Dir.HeadPtr := src;
    Sta.Dir.ShrVld := false;
    for p : NODE do
      Sta.Dir.ShrSet[p] := false;
      Sta.Dir.InvSet[p] := false;
    end;
    Sta.UniMsg[src].Cmd := UNI_PutX;
    Sta.UniMsg[src].HomeProc := true;
    Sta.UniMsg[src].Data := Sta.HomeProc.CacheData;
    Sta.HomeProc.CacheState := CACHE_I;
    undefine Sta.HomeProc.CacheData;
    undefine Sta.UniMsg[src].Proc;
  elsif (Sta.Dir.HeadVld ->
         Sta.Dir.HeadPtr = src  &
         forall p : NODE do p != src -> !Sta.Dir.ShrSet[p] end) then
    Sta.Dir.Dirty := true;
    Sta.Dir.HeadVld := true;
    Sta.Dir.HeadPtr := src;
    Sta.Dir.HomeHeadPtr := false;
    Sta.Dir.ShrVld := false;
    for p : NODE do
      Sta.Dir.ShrSet[p] := false;
      Sta.Dir.InvSet[p] := false;
    endfor;
    Sta.UniMsg[src].Cmd := UNI_PutX;
    Sta.UniMsg[src].HomeProc := true;
    Sta.UniMsg[src].Data := Sta.MemData;
    Sta.HomeProc.CacheState := CACHE_I;
    undefine Sta.HomeProc.CacheData;
    if (Sta.Dir.Local) then
      Sta.HomeProc.CacheState := CACHE_I;
      undefine Sta.HomeProc.CacheData;
      if (Sta.HomeProc.ProcCmd = NODE_Get) then
        Sta.HomeProc.InvMarked := true;
      end;
    end;
    Sta.Dir.Local := false;
  else
    Sta.Dir.Pending := true;
    Sta.Dir.Dirty := true;

    for p : NODE do
      if ( p != src &
           ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
             Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p ) ) then
        Sta.Dir.InvSet[p] := true;
        Sta.InvMsg[p].Cmd := INV_Inv;
      else
        Sta.Dir.InvSet[p] := false;
        Sta.InvMsg[p].Cmd := INV_None;
      endif;
    endfor;
    --

    Sta.Dir.ShrVld := false;
    Sta.Dir.HeadVld := true;
    Sta.UniMsg[src].Cmd := UNI_PutX;
    Sta.UniMsg[src].HomeProc := true;
    Sta.UniMsg[src].Data := Sta.MemData;
    if (Sta.Dir.Local) then
      Sta.HomeProc.CacheState := CACHE_I;
      undefine Sta.HomeProc.CacheData;
      if (Sta.HomeProc.ProcCmd = NODE_Get) then
        Sta.HomeProc.InvMarked := true;
      endif;
    endif;
    Sta.Dir.Local := false;
    Sta.PendReqSrc := src;
    Sta.PendReqCmd := UNI_GetX;
    Sta.Collecting := true;
    Sta.PrevData := Sta.CurrData;
    if (Sta.Dir.HeadPtr != src) then
      Sta.LastOtherInvAck := Sta.Dir.HeadPtr;
    else
      for p : NODE do
        if (p != src & Sta.Dir.ShrSet[p]) then
          Sta.LastOtherInvAck := p;
        endif;
      endfor;
    endif;

    for p : NODE do
        Sta.Dir.ShrSet[p] := false;
    endfor;
    Sta.Dir.HeadPtr := src;
  end;
--

endrule;
endruleset;


ruleset src : NODE; dst : NODE do
rule "NI_Remote_GetX_Nak"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState != CACHE_E
==>

begin

--
  Sta.UniMsg[src].Cmd := UNI_Nak;
  Sta.UniMsg[src].Proc := dst;
  Sta.NakcMsg.Cmd := NAKC_Nakc;
  Sta.FwdCmd := UNI_None;
  Sta.FwdSrc := src;
  undefine Sta.UniMsg[src].Data;

--

endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_GetX_PutX"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst &
  Sta.Proc[dst].CacheState = CACHE_E
==>

begin

--
  Sta.Proc[dst].CacheState := CACHE_I;
  Sta.UniMsg[src].Cmd := UNI_PutX;
  Sta.UniMsg[src].Proc := dst;
  Sta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  Sta.ShWbMsg.Cmd := SHWB_FAck;
  Sta.ShWbMsg.Proc := src;
  Sta.ShWbMsg.HomeProc := false;
  undefine Sta.ShWbMsg.Data;
  Sta.FwdCmd := UNI_None;
  Sta.FwdSrc := src;
  undefine Sta.Proc[dst].CacheData;

--

endrule;
endruleset;

rule "NI_Local_Put"
  Sta.HomeUniMsg.Cmd = UNI_Put
==>

begin

--
  Sta.HomeUniMsg.Cmd := UNI_None;

  Sta.Dir.Pending := false;
  Sta.Dir.Dirty := false;
  Sta.Dir.Local := true;
  Sta.MemData := Sta.HomeUniMsg.Data;
  Sta.HomeProc.ProcCmd := NODE_None;
  if (Sta.HomeProc.InvMarked) then
    Sta.HomeProc.InvMarked := false;
    Sta.HomeProc.CacheState := CACHE_I;
    undefine Sta.HomeProc.CacheData;
  else
    Sta.HomeProc.CacheState := CACHE_S;
    Sta.HomeProc.CacheData := Sta.HomeUniMsg.Data;
  end;

  undefine Sta.HomeUniMsg.Proc;
  undefine Sta.HomeUniMsg.Data;
--

endrule;

ruleset dst : NODE do
rule "NI_Remote_Put"
  Sta.UniMsg[dst].Cmd = UNI_Put
==>

begin

--
  Sta.UniMsg[dst].Cmd := UNI_None;
  Sta.Proc[dst].ProcCmd := NODE_None;
  if (Sta.Proc[dst].InvMarked) then
    Sta.Proc[dst].InvMarked := false;
    Sta.Proc[dst].CacheState := CACHE_I;
    undefine Sta.Proc[dst].CacheData;
  else
    Sta.Proc[dst].CacheState := CACHE_S;
    Sta.Proc[dst].CacheData := Sta.UniMsg[dst].Data;
  end;
  undefine Sta.UniMsg[dst].Proc;
  undefine Sta.UniMsg[dst].Data;
--

endrule;
endruleset;

rule "NI_Local_PutXAcksDone"
  Sta.HomeUniMsg.Cmd = UNI_PutX
==>

begin

--
  Sta.HomeUniMsg.Cmd := UNI_None;
  Sta.Dir.Pending := false;
  Sta.Dir.Local := true;
  Sta.Dir.HeadVld := false;
  Sta.HomeProc.ProcCmd := NODE_None;
  Sta.HomeProc.InvMarked := false;
  Sta.HomeProc.CacheState := CACHE_E;
  Sta.HomeProc.CacheData := Sta.HomeUniMsg.Data;

  undefine Sta.HomeUniMsg.Proc;
  undefine Sta.HomeUniMsg.Data;
  undefine Sta.Dir.HomeHeadPtr;

--

endrule;

ruleset dst : NODE do
rule "NI_Remote_PutX"
  Sta.UniMsg[dst].Cmd = UNI_PutX &
  Sta.Proc[dst].ProcCmd = NODE_GetX
==>

begin

--
  Sta.UniMsg[dst].Cmd := UNI_None;
  Sta.Proc[dst].ProcCmd := NODE_None;
  Sta.Proc[dst].InvMarked := false;
  Sta.Proc[dst].CacheState := CACHE_E;
  Sta.Proc[dst].CacheData := Sta.UniMsg[dst].Data;
  undefine Sta.UniMsg[dst].Proc;
  undefine Sta.UniMsg[dst].Data;
--

endrule;
endruleset;

ruleset dst : NODE do
rule "NI_Inv"
  Sta.InvMsg[dst].Cmd = INV_Inv
==>

begin

--
  Sta.InvMsg[dst].Cmd := INV_InvAck;
  Sta.Proc[dst].CacheState := CACHE_I;
  if (Sta.Proc[dst].ProcCmd = NODE_Get) then
    Sta.Proc[dst].InvMarked := true;
  end;
  undefine Sta.Proc[dst].CacheData;

--

endrule;
endruleset;


ruleset src : NODE do
rule "NI_InvAck_exists_Home"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true & Sta.Dir.InvSet[src] = true &
  Sta.Dir.HomeInvSet = true
==>

begin

--
  Sta.InvMsg[src].Cmd := INV_None;
  Sta.LastInvAck := src;
  for p : NODE do
    if (p != src & Sta.Dir.InvSet[p]) then
      Sta.LastOtherInvAck := p;
    end;
  end;
  Sta.Dir.InvSet[src] := false;
--

endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_InvAck_exists"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true & Sta.Dir.InvSet[src] = true &
  (dst != src & Sta.Dir.InvSet[dst])
==>

begin

--
  Sta.InvMsg[src].Cmd := INV_None;
  Sta.LastInvAck := src;
  for p : NODE do
    if (p != src & Sta.Dir.InvSet[p]) then
      Sta.LastOtherInvAck := p;
    end;
  end;
  Sta.Dir.InvSet[src] := false;

--

endrule;
endruleset;

ruleset src : NODE do
rule "NI_InvAck_no_exists"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending = true & Sta.Dir.InvSet[src] &
  Sta.Dir.HomeInvSet = false &
  forall p : NODE do  (p=src | Sta.Dir.InvSet[p] = false ) end
==>

begin

--
  Sta.InvMsg[src].Cmd := INV_None;
  Sta.Dir.InvSet[src] := false;

  Sta.Dir.Pending := false;
  if (Sta.Dir.Local & !Sta.Dir.Dirty) then
    Sta.Dir.Local := false;
  end;
  Sta.Collecting := false;
  Sta.LastInvAck := src;
--

endrule;
endruleset;



rule "NI_Wb"
  Sta.WbMsg.Cmd = WB_Wb
==>

begin

--
  Sta.WbMsg.Cmd := WB_None;
  Sta.Dir.Dirty := false;
  Sta.Dir.HeadVld := false;
  Sta.MemData := Sta.WbMsg.Data;

  undefine Sta.WbMsg.Proc;
  undefine Sta.WbMsg.Data;
  undefine Sta.Dir.HeadPtr;

--

endrule;

rule "NI_FAck"
  Sta.ShWbMsg.Cmd = SHWB_FAck
==>

begin

--
  Sta.ShWbMsg.Cmd := SHWB_None;
  Sta.Dir.Pending := false;
  if (Sta.Dir.Dirty) then
    Sta.Dir.HeadPtr := Sta.ShWbMsg.Proc;
  end;

  undefine Sta.ShWbMsg.Proc;
  undefine Sta.ShWbMsg.Data;
--

endrule;

rule "NI_ShWb"
  Sta.ShWbMsg.Cmd = SHWB_ShWb
==>

begin

--
  Sta.ShWbMsg.Cmd := SHWB_None;
  Sta.Dir.Pending := false;
  Sta.Dir.Dirty := false;
  Sta.Dir.ShrVld := true;
  for p : NODE do
    Sta.Dir.InvSet[p] := (p = Sta.ShWbMsg.Proc) | Sta.Dir.ShrSet[p];
    Sta.Dir.ShrSet[p] := (p = Sta.ShWbMsg.Proc) | Sta.Dir.ShrSet[p];
  end;
  if (Sta.ShWbMsg.HomeProc | Sta.Dir.HomeShrSet) then
    Sta.Dir.HomeShrSet := true;
    Sta.Dir.HomeInvSet := true;
  else
    Sta.Dir.HomeShrSet := false;
    Sta.Dir.HomeInvSet := false;
  end;
  Sta.MemData := Sta.ShWbMsg.Data;

  undefine Sta.ShWbMsg.Proc;
  undefine Sta.ShWbMsg.Data;
--

endrule;

ruleset src : NODE do
rule "NI_Replace"
  Sta.RpMsg[src].Cmd = RP_Replace
==>

begin

--
  Sta.RpMsg[src].Cmd := RP_None;
  if (Sta.Dir.ShrVld) then
    Sta.Dir.ShrSet[src] := false;
    Sta.Dir.InvSet[src] := false;
  end;
--

endrule;
endruleset;



invariant "CacheStateProp"
  forall p : NODE do forall q : NODE do
    p != q ->
    !(Sta.Proc[p].CacheState = CACHE_E & Sta.Proc[q].CacheState = CACHE_E)
  end end;


invariant "CacheStatePropHome"
  forall p : NODE do
    !(Sta.Proc[p].CacheState = CACHE_E & Sta.HomeProc.CacheState = CACHE_E)
  end;

invariant "DataProp"
  forall p: NODE do
    (Sta.Proc[p].CacheState = CACHE_E -> Sta.Proc[p].CacheData = Sta.CurrData)
  end;

invariant "MemDataProp"
  !Sta.Dir.Dirty -> Sta.MemData = Sta.CurrData;


