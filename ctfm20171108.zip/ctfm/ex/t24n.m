Const
clientNUMS : 5;
Type
   state : enum{I,T,C,E,A,B,Q,W,R,AA,AAA};
client : 1..5;
new_type_0 : array [ client ] of state;
Var 
 n : new_type_0;
 x : boolean;
 a : client;
Ruleset  ctf : client Do
    Rule "Try1"
      n[ctf] = I &   Forall p : client Do
p != ctf -> ctf = ctf
End
    ==>
    Begin
      n[ctf] := AA;
    End;


endruleset;
Ruleset  ctf : client Do
    Rule "Try2"
      n[ctf] = I & !  Forall p : client Do
p != ctf -> ctf = ctf
End
    ==>
    Begin
          End;


endruleset;
    Startstate
    Begin
      x := true;
    End;

Ruleset  jj : client; ii : client Do
Invariant "coherence"
(ii != jj -> (n[ii] = C -> n[jj] != C))
endruleset;
