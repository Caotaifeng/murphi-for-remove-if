Type player_t : 0..1;

_type_0 : record  hasball : boolean; gotball : boolean;End; 
Var  Players : Array[ player_t ] of _type_0;
Ruleset p : player_t Do
  Alias ping : Players[p];
pong : Players[1 - p] Do 

    Rule "Pass ball"
      ping.hasball
    ==>
    Begin
      ping.hasball := false;
      pong.gotball := true;
    End;

    Rule "Keep ball"
      ping.hasball
    ==>
    Begin
          End;

    Rule "Get ball"
      ping.gotball
    ==>
    Begin
      ping.hasball := true;
      ping.gotball := false;
    End;

    Startstate
    Begin
      ping.hasball := true;
      ping.gotball := false;
      clear pong;
    End;

  End;

End;

Invariant "Only one ball in play."
  Forall p : player_t Do
(!((Players[p].hasball & Players[p].gotball)) & (Players[p].hasball | Players[p].gotball)) ->   Forall q : player_t Do
(Players[q].hasball | Players[q].gotball) -> p = q
    End
End;