Const clientNUMS : 5;
Type 
state : enum{I, T, C, E, A, B, Q,W, R, AA, AAA};
client: 1..clientNUMS;
Var n : array [client] of state;
    x : boolean; 
	a : client;
	
	
	
ruleset ctf : client do
	rule "Try" 
	n[ctf] = I -> n[ctf] = A
	==> 
		begin
		if (n[ctf] != I) then
		n[ctf] := I;
		else
		n[ctf] := T;
		if (n[ctf] != C) then
		n[ctf] := C;
		end;	
		if (n[ctf] != AA) then
   		n[ctf] := AA;
    		else
      		for p : client do
        	if (p != 2 & x) then n[ctf] := B end;
      		end;
    		end;
		end;
		n[ctf] := AA;
	end;
end;
startstate
begin
  x := true;
end;
ruleset ii:client; jj: client do
invariant "coherence"
  ii != jj -> (n[ii] = C -> n[jj] != C);
endruleset;

