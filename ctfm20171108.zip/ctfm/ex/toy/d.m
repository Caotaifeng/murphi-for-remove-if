
Const
	INITIAL_VAL: 5;
	

Type
	state : enum{I, T, C, E};
	val_t: 1..INITIAL_VAL;

Var 
       a : val_t;

	
Rule "1"
        a > 0
	==>
	Begin
       For i : val_t Do
		a := a + 1;
	End;
End;

Startstate
  Begin
   a := 0;
  End;

Invariant "Positive sum"
	INITIAL_VAL > 0;
